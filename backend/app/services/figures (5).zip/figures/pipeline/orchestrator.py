"""配图 V3 编排入口。"""

from __future__ import annotations

import logging
import time

from sqlalchemy.orm import Session

from app.models.figure import Figure, FigureStatus
from app.services.figure_render.infographic_renderer import (
    compile_diagram_spec,
    supports_infographic_template,
    validate_and_normalize,
)
from app.services.figure_render.layoutscript import generate_layout_script
from app.services.figure_render.prompt_constraints_v3 import IMAGE_API_SUBTYPES
from app.services.figures.classification.resolver import build_classification_record
from app.services.figures.schemas.dsl import DiagramDSL
from app.services.figures.intent.reconcile import reconcile_intent_with_dsl, reconcile_intent_with_text
from app.services.figures.intent.taxonomy import canonical_subtype, subtype_to_diagram_type
from app.services.figures.intent.resolve import resolve_intent_unified
from app.services.figures.pipeline.chart_run import run_chart_pipeline
from app.services.figures.intent.understand import understand_intent
from app.services.figures.pipeline.illustration_run import run_illustration_pipeline
from app.services.figures.pipeline.normalize import normalize_figure_input
from app.services.figures.pipeline.structured_run import run_structured_pipeline
from app.services.figures.pipeline.type_router import PipelineRoute, route_from_understanding
from app.services.figures.schemas.diagram import DiagramIntent, ParsedDiagram, PipelineContext, VisualPlan

logger = logging.getLogger(__name__)

def _ensure_diagram_type(intent: DiagramIntent) -> DiagramIntent:
    if not intent.diagram_type:
        intent.diagram_type = subtype_to_diagram_type(intent.diagram_subtype)
    return intent


def _trace(ctx: PipelineContext, step: str, **extra) -> None:
    ctx.pipeline_trace.append({"step": step, "ms": extra.pop("ms", 0), **extra})


def _resolve_intent(ctx: PipelineContext) -> tuple[DiagramIntent, dict]:
    t0 = time.perf_counter()
    understanding = ctx.intent_understanding or understand_intent(ctx)
    ctx.intent_understanding = understanding
    _trace(ctx, "intent_understanding", ms=int((time.perf_counter() - t0) * 1000), source="llm" if ctx.use_llm else "hint")

    intent = resolve_intent_unified(ctx, understanding)
    return _ensure_diagram_type(reconcile_intent_with_text(intent, ctx.normalized_input)), understanding


def _run_pipeline(
    ctx: PipelineContext,
    intent: DiagramIntent,
    understanding: dict,
) -> tuple[DiagramIntent, ParsedDiagram, VisualPlan | None, dict | None, list[str], dict]:
    subtype = canonical_subtype(intent.diagram_subtype)
    if subtype == "chart":
        ctx.pipeline_trace.append({"step": "type_router", "route": PipelineRoute.CHART.value})
        return run_chart_pipeline(ctx, intent, understanding)
    if subtype == "screenshot":
        ctx.pipeline_trace.append({"step": "type_router", "route": PipelineRoute.SCREENSHOT.value})
        parsed = ParsedDiagram({"title": intent.title, "render_mode": "screenshot_placeholder"}, source="v3_screenshot")
        return intent, parsed, None, None, ["screenshot_placeholder"], {"intent_understanding": understanding}
    if supports_infographic_template(subtype):
        ctx.pipeline_trace.append({"step": "type_router", "route": "infographic_template"})
        t0 = time.perf_counter()
        spec, compiler_diag = compile_diagram_spec(
            ctx.normalized_input,
            subtype=subtype,
            model=ctx.model,
            use_llm=ctx.use_llm,
        )
        validation = validate_and_normalize(spec, subtype=subtype)
        ctx.pipeline_trace.append({
            "step": "diagram_spec_compiler",
            "ms": int((time.perf_counter() - t0) * 1000),
            "source": compiler_diag.get("source"),
            "fallback": bool(compiler_diag.get("compiler_fallback")),
        })
        if not validation.get("ok"):
            parsed = ParsedDiagram(
                {
                    "title": intent.title,
                    "render_mode": "needs_clarification",
                    "diagram_subtype": subtype,
                    "diagram_spec": validation.get("spec"),
                    "compiler_messages": validation.get("messages") or [],
                },
                source="infographic_template_blocked",
            )
            flags = ["diagram_spec_needs_clarification"]
            return intent, parsed, None, None, flags, {
                "intent_understanding": understanding,
                "pipeline": "infographic_template",
                "diagram_spec": validation.get("spec"),
                "diagram_spec_source": compiler_diag.get("source"),
                "diagram_spec_compiler_fallback": bool(compiler_diag.get("compiler_fallback")),
            }
        diagram_spec = validation["spec"]
        parsed = ParsedDiagram(
            {
                "title": diagram_spec.get("title") or intent.title,
                "render_mode": "infographic_template",
                "diagram_subtype": subtype,
                "primary_type": subtype,
                "secondary_type": str(understanding.get("secondary_type") or "").strip(),
                "do_not_draw_as": str(understanding.get("do_not_draw_as") or "").strip(),
                "layout_risks": str(understanding.get("layout_risks") or "").strip(),
                "diagram_spec": diagram_spec,
                "template_id": diagram_spec.get("template_id"),
                "diagram_spec_source": compiler_diag.get("source"),
                "diagram_spec_compiler_fallback": bool(compiler_diag.get("compiler_fallback")),
                "compiler_messages": validation.get("messages") or [],
            },
            source="infographic_template",
        )
        flags = ["diagram_spec_compiler_fallback"] if compiler_diag.get("compiler_fallback") else []
        if validation.get("severity") == "warn":
            flags.append("diagram_spec_warn")
        return intent, parsed, None, None, flags, {
            "intent_understanding": understanding,
            "pipeline": "infographic_template",
            "diagram_spec": diagram_spec,
            "template_id": diagram_spec.get("template_id"),
            "diagram_spec_source": compiler_diag.get("source"),
            "diagram_spec_compiler_fallback": bool(compiler_diag.get("compiler_fallback")),
            "compiler_messages": validation.get("messages") or [],
        }
    if subtype in IMAGE_API_SUBTYPES:
        ctx.pipeline_trace.append({"step": "type_router", "route": "image_api"})
        t0 = time.perf_counter()
        secondary_type = str(understanding.get("secondary_type") or "").strip()
        do_not_draw_as = str(understanding.get("do_not_draw_as") or "").strip()
        layout_risks = str(understanding.get("layout_risks") or "").strip()
        layout_script, layout_fallback = generate_layout_script(
            ctx.normalized_input,
            subtype,
            secondary_type=secondary_type,
            do_not_draw_as=do_not_draw_as,
            layout_risks=layout_risks,
            model=ctx.model,
            use_llm=ctx.use_llm,
        )
        ctx.pipeline_trace.append({
            "step": "layout_agent",
            "ms": int((time.perf_counter() - t0) * 1000),
            "fallback": layout_fallback,
        })
        parsed = ParsedDiagram(
            {
                "title": intent.title,
                "render_mode": "image_api",
                "diagram_subtype": subtype,
                "primary_type": subtype,
                "secondary_type": secondary_type,
                "do_not_draw_as": do_not_draw_as,
                "layout_risks": layout_risks,
                "layout_script": layout_script,
                "layout_agent_fallback": layout_fallback,
            },
            source="layoutscript_image_api",
        )
        flags = ["layout_agent_fallback"] if layout_fallback else []
        return intent, parsed, None, None, flags, {
            "intent_understanding": understanding,
            "pipeline": "layoutscript_image_api",
            "primary_type": subtype,
            "secondary_type": secondary_type,
            "do_not_draw_as": do_not_draw_as,
            "layout_risks": layout_risks,
            "layout_script": layout_script,
            "layout_agent_fallback": layout_fallback,
        }

    route = route_from_understanding(understanding, subtype_hint=ctx.subtype_hint or intent.diagram_subtype)
    ctx.pipeline_trace.append({"step": "type_router", "route": route.value})

    if route == PipelineRoute.CHART:
        return run_chart_pipeline(ctx, intent, understanding)
    if route == PipelineRoute.ILLUSTRATION:
        return run_illustration_pipeline(ctx, intent, understanding)
    if route == PipelineRoute.SCREENSHOT:
        parsed = ParsedDiagram({"title": intent.title, "render_mode": "screenshot_placeholder"}, source="v3_screenshot")
        return intent, parsed, None, None, ["screenshot_placeholder"], {"intent_understanding": understanding}

    intent, parsed, visual, dsl_json, quality_flags, ir_bundle = run_structured_pipeline(
        ctx, intent, understanding=understanding,
    )
    if dsl_json:
        intent = reconcile_intent_with_dsl(intent, DiagramDSL.from_dict(dsl_json))
    return intent, parsed, visual, dsl_json, quality_flags, ir_bundle


def classify_figure_description(
    description: str,
    *,
    style_type: str | None = None,
    book_type: str = "",
    chapter_title: str = "",
    legacy_tag: str | None = None,
    user_hint: str = "",
    figure_annotation: str = "",
    model: str | None = None,
    use_llm: bool = True,
    subtype_hint: str | None = None,
) -> dict:
    normalized, layout_instructions = normalize_figure_input(
        description,
        user_hint=user_hint,
        figure_annotation=figure_annotation,
    )
    ctx = PipelineContext(
        description=description,
        normalized_input=normalized,
        layout_instructions=layout_instructions,
        book_type=book_type,
        style_type=style_type or "",
        chapter_title=chapter_title,
        user_hint=user_hint,
        legacy_tag=legacy_tag,
        subtype_hint=subtype_hint,
        model=model or "",
        use_llm=use_llm,
    )

    intent, understanding = _resolve_intent(ctx)
    intent, parsed, visual, dsl_json, quality_flags, ir_bundle = _run_pipeline(ctx, intent, understanding)
    ir_bundle = ir_bundle or {}
    ir_bundle["intent_understanding"] = understanding

    record = build_classification_record(
        ctx, intent, parsed, visual_plan=visual, dsl_json=dsl_json, ir_bundle=ir_bundle,
    )

    out = record.to_json()
    if quality_flags:
        out.setdefault("quality_flags", [])
        out["quality_flags"] = list(dict.fromkeys(list(out.get("quality_flags") or []) + quality_flags))
    if ctx.pipeline_trace:
        out["pipeline_trace"] = ctx.pipeline_trace
    return out


def apply_classification_to_figure(fig: Figure, classification: dict, db: Session) -> Figure:
    fig.image_type = classification.get("image_type")
    fig.subtype = classification.get("subtype") or classification.get("diagram_subtype")
    fig.renderer = classification.get("renderer")
    fig.classification_json = classification
    fig.prompt_spec_json = classification.get("prompt_spec")
    if classification.get("renderer") == "need_data":
        fig.status = FigureStatus.pending
    db.commit()
    db.refresh(fig)
    return fig


def classify_and_persist(
    fig: Figure,
    db: Session,
    *,
    style_type: str | None = None,
    book_type: str = "",
    chapter_title: str = "",
    legacy_tag: str | None = None,
    user_hint: str = "",
    model: str | None = None,
    use_llm: bool = True,
) -> Figure:
    desc = (fig.raw_annotation or fig.caption or "").strip()
    clf = classify_figure_description(
        desc,
        style_type=style_type,
        book_type=book_type,
        chapter_title=chapter_title,
        legacy_tag=legacy_tag,
        user_hint=user_hint,
        figure_annotation=fig.raw_annotation or "",
        model=model,
        subtype_hint=fig.subtype,
        use_llm=use_llm,
    )
    return apply_classification_to_figure(fig, clf, db)
