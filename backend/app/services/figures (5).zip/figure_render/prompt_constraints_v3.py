"""V3 LayoutScript prompt constraints for Image API figures.

The default Image API path receives a LayoutScript, not the raw user request.
Raw user text is only used by the classifier and layout planner.
"""

from __future__ import annotations

from app.services.figures.intent.taxonomy import canonical_subtype


IMAGE_API_SUBTYPES = frozenset({
    "process_flow",
    "system_architecture",
    "mechanism_diagram",
    "comparison_matrix",
    "concept_diagram",
    "infographic",
    "taxonomy_map",
    "decision_tree",
    "timeline_roadmap",
    "scene_illustration",
})

CLASSIFIER_AGENT_PROMPT = """你是图示类型分类器。

你的任务：
根据用户原始输入，判断最适合生成哪一种解释型图片。

不要生成图片。
不要改写用户内容。
不要抽取结构。
不要输出 JSON。
只输出图类判断。

用户原始输入：
{user_input}

可选图类：
process_flow：流程图、步骤图、工作流、过程说明。
system_architecture：系统架构图、模块架构、服务拓扑、RAG 架构、微服务架构、数据系统架构。
mechanism_diagram：机制原理图、算法机制、模型内部计算、矩阵、向量、变量、权重、公式关系。
comparison_matrix：对比矩阵、方案比较、维度比较、优缺点比较。
concept_diagram：概念关系图、概念之间的关联、包含、影响、依赖、映射、组成关系。
infographic：信息图，围绕一个主题组织多个模块、分类、指标、结论。
taxonomy_map：分类图、层级分类、父子归属、知识体系、模型家族。
decision_tree：决策树、条件判断路径、分支选择、分类决策。
timeline_roadmap：时间线、路线图、历史演进、阶段规划、里程碑。
scene_illustration：场景插图、概念隐喻插图、无复杂文字的书籍插画。
chart：数据图表，仅当用户明确提供数值数据且要求可视化数值关系。
screenshot：截图，用户明确要求界面截图、产品截图、系统截图且需要上传真实截图素材。

分类规则：
- 强调先后步骤、执行过程、操作顺序：process_flow
- 强调系统模块、服务、数据库、队列、外部参与者、通信、读写、依赖：system_architecture
- 强调变量、矩阵、向量、公式、状态、权重、内部作用机制：mechanism_diagram
- 强调对象之间按同一组维度比较：comparison_matrix
- 强调概念之间的包含、关联、影响、依赖、映射、组成：concept_diagram
- 围绕主题组织多个模块、分类、指标或结论：infographic
- 强调父子层级、归属、分类体系：taxonomy_map
- 强调条件判断路径和唯一结果：decision_tree
- 强调时间、年份、阶段、里程碑、演进顺序：timeline_roadmap
- 强调无复杂文字的概念隐喻插图：scene_illustration

允许输出辅图类。
辅图类只用于提醒 Layout Agent 存在局部结构，不得覆盖主图类。
辅图类不触发完整图类约束加载。

输出格式：

主图类：
辅图类：
不要画成：
分类理由：
Layout Agent 应重点处理的风险：
"""

PROCESS_FLOW_LAYOUT_CONSTRAINTS = """每个主要步骤画成清晰步骤节点。
主流程必须只有一条优先阅读路径。
按用户给出的步骤顺序连接。
主流程使用明确方向箭头。
如果步骤超过 5 个，或单行排列会导致节点过小、文字过密，使用两行或多行蛇形折返布局。
折返处使用清楚的直角或圆角连接线，不得让读者猜顺序。
分支、判断、汇合、反馈只有在用户明确提供时才画。
反馈回路弱于主流程，但必须完整可追踪。
节点内部允许少量子步骤，但必须从属于所属阶段。
不得新增用户没有提供的步骤。"""

PROCESS_FLOW_LAYOUT_NEGATIVE = """不要出现多条难以判断优先级的主路径。
不要让反馈路径比主流程更醒目。
不要使用方向不明的自由曲线或装饰性连接线。
不要让连接线穿过节点、文字或节点内部内容。
不要为了视觉平衡新增人工步骤、分支或回路。
不要把判断节点设计成整张图最大的视觉元素，除非用户明确要求。"""

SYSTEM_ARCHITECTURE_LAYOUT_CONSTRAINTS = """重点表现系统由哪些层、模块、服务、数据库、队列、缓存、外部参与者或共享基础设施组成，以及它们之间如何通信、查询、写入、返回或异步通知。
不要画成简单线性流程图。
根据内容选择上下分层、左右分区、中心共享组件、服务拓扑、双通道结构或 RAG 结构。
架构层、服务层、数据层、外部系统、共享基础设施要有清楚边界。
模块表示稳定系统责任，不表示临时动作或一次性步骤。
模块内部说明优先描述职责、能力、输入输出、接口、数据类型或管理对象。
数据库、消息队列、缓存、对象存储、向量数据库等共享资源应画成共享组件或基础设施，不要画成普通流程步骤。
重要箭头必须标注用户输入中提供的关系文字，例如 HTTP 请求、SQL 查询、异步通知、数据流向。
请求方向和返回方向必须分开表达，返回线应更轻或明确标注。
异步通信必须表现生产方、消息中介或队列、消费方。
RAG 类架构优先使用左侧文档预处理、中心向量数据库、右侧查询生成模块的结构。
允许模块内部有局部处理链，但整张图首先应被读作系统架构图。"""

SYSTEM_ARCHITECTURE_LAYOUT_NEGATIVE = """不要把系统架构图画成线性流程图。
不要用一条大箭头贯穿所有模块。
不要用无标签箭头表达含义不明显的关系。
不要把数据库、队列、缓存、对象存储、向量数据库画成主动发起业务请求的模块。
不要把异步通信简化成源服务直接指向目标服务的普通箭头。
不要画出违反架构边界的跨层直连。
不要把用户动作、函数调用、业务步骤、临时处理动作当作系统级模块。
不要把内部模块、外部系统、用户角色、基础设施和数据对象画成同一语义层级。
不要只写技术名称而不写模块职责。
不要为了构图对称添加不存在的依赖、双向箭头、跨层连接或共享关系。"""

MECHANISM_LAYOUT_CONSTRAINTS = """重点解释内部对象、变量、矩阵、向量、层、状态、权重、控制量、输入和输出之间如何作用。
不要画成普通步骤流程图。
明确区分输入、内部状态、中间变量、控制量、参数、输出和外部条件。
保留用户输入中的公式、矩阵、Q/K/V、Softmax、注意力权重、维度、变量名。
关键中间对象应保留结构形态，如矩阵、向量、层级、通道、槽位、接口。
跨模块关系应标明传递的具体对象，而不是只连接模块外框。
矩阵、向量、层级、重复单元、局部到整体对应，要用形状、对齐、括号、空间对应或公式关系表现。
控制、门控、加权、路由、归一化、聚合、更新等关系要靠近它作用的对象。
如果存在正向流、反向流、更新流或控制流，必须区分线型、方向或位置。
不得省略理解机制所必需的中间变量。"""

MECHANISM_LAYOUT_NEGATIVE = """不要把机制图画成普通步骤流程图。
不要只展示对象名称而不展示来源、作用对象和去向。
不要把生成、匹配、归一化、控制、聚合、输出、梯度流、参数更新画成同一种普通箭头。
不要省略使机制成立的关键中间状态。
不要让局部解释与整体结构、公式或符号不一致。
不要把控制量画成内容量。
不要把重复堆叠结构画成一次性线性步骤。
不要只连接系统边界而不连接真实发生作用的具体接口。"""

COMPARISON_MATRIX_LAYOUT_CONSTRAINTS = """使用稳定的行列矩阵结构。
比较对象和比较维度必须固定在清楚的轴上。
所有对象使用同一组维度比较。
同一维度下，各比较对象采用相同信息结构。
对应单元格的信息层级和表达形式要一致。
对应结论必须对齐，便于横向或纵向比较。
比较关系优先通过对齐建立，不通过连接线建立。
如果内容较多，优先分组维度或增加单元格空间，不要压缩成小字。"""

COMPARISON_MATRIX_LAYOUT_NEGATIVE = """不要在同一图中切换比较轴定义。
不要比较不同语义层级的对象。
不要一侧展示原因、另一侧展示结果。
不要一侧展示优势、另一侧展示限制。
不要混用不相关评价标准。
不要用大量箭头建立比较关系。
不要把同一组比较对象拆到多个独立空间让读者来回对照。"""

CONCEPT_DIAGRAM_LAYOUT_CONSTRAINTS = """重点表达概念之间的包含、关联、影响、依赖、映射或组成关系。
不要表达时间顺序、任务执行或数据流，除非用户明确提供。
核心概念必须真正组织周围关系，不得只是装饰性中心节点。
同级概念保持相近视觉等级。
不同类别可用轻量分组边界区分。
关系类型不宜过多，关系标签必须使用用户输入中的原始文字。
关系方向必须遵循统一规则。
语义清晰优先于视觉对称。"""

CONCEPT_DIAGRAM_LAYOUT_NEGATIVE = """不要把概念关系图画成流程图。
不要用空间位置暗示不存在的先后顺序。
不要混用多个抽象层级的关系类型。
不要让所有节点视觉平级但语义不平级。
不要添加不能组织关系的装饰性中心节点。
不要绘制过多跨组连接导致层级失效。"""

INFOGRAPHIC_LAYOUT_CONSTRAINTS = """围绕一个主题组织信息。
先建立主题范围，再展示分类、模块、指标或结论。
如果模块超过 3 个，必须增加分组层，例如主题 → 分类 → 模块。
每个模块对应一个独立认知单元。
模块之间至少要有清楚的组织关系：分类、组成、对比、映射、影响、依赖或汇聚。
如果有总结层，必须表现总结来自哪些上层模块。
如果有机制或变化过程，必须说明它映射到什么影响或结果。
支持非线性阅读：先总览，再看分类，再读模块。"""

INFOGRAPHIC_LAYOUT_NEGATIVE = """不要生成一堆彼此无关的卡片。
不要让模块内部完整但模块之间断裂。
不要让关系线数量超过模块数量，导致读者先看线而不是模块。
不要把分类关系误画成流程。
不要把因果关系误画成归属关系。
不要让总结层独立悬浮，无法看出来自哪些模块。"""

TAXONOMY_LAYOUT_CONSTRAINTS = """分类、归属、父子层级是主要结构。
根节点、一级分类、二级分类和成员必须层级清楚。
同一父节点下的成员应靠近并对齐。
类内距离必须小于类间距离。
连接线默认表示属于，不要画成流程箭头或因果箭头。
同一层级节点尽量位于同一视觉基线。
如果用户给出多个层级，必须完整保留每一层。
如果存在多父归属，必须明确标注为共享或交叉分类，否则保持树状结构。"""

TAXONOMY_LAYOUT_NEGATIVE = """不要把分类图画成流程顺序。
不要把归属关系画成依赖或影响。
不要让一个同级分类无语义原因地视觉上压倒其他分类。
不要让类内间距大于类间间距。
不要添加过多跨层连接破坏分类体系。
不要让一个成员连接多个父节点而不说明共享或交叉分类关系。"""

DECISION_TREE_LAYOUT_CONSTRAINTS = """清楚区分判断节点和结果节点。
判断节点表示条件或问题。
结果节点表示最终选择、分类、建议或动作。
每条路径必须从根节点开始，经由分支条件到达唯一结果。
分支标签必须靠近分叉点，例如 是、否、高、低、内部、外部。
路径长度可以不同，逻辑真实优先于视觉对称。
根节点必须定义正在决定什么。"""

DECISION_TREE_LAYOUT_NEGATIVE = """不要出现结果到结果的链条。
不要让一个节点拥有多个父节点。
不要使用跨层捷径绕过中间判断。
不要用颜色或空间接近替代明确父子连接。
不要把叶子结果重新连接成网络。
不要插入伪问题或伪结果来平衡布局。"""

TIMELINE_LAYOUT_CONSTRAINTS = """时间轴必须是一级主结构，贯穿画面。
每个时间点、阶段或里程碑都必须明确锚定在时间轴上。
时间标签和事件标题要分层显示。
时间用于定位，事件标题是主体信息。
如果是历史演进，按时间顺序从左到右排列。
如果实际时间间隔重要，反映相对间距；如果重点是阶段推进，使用等距节点，不要混用两套尺度逻辑。
重要转折点可以适度强化。
节点内容应说明该时间点发生了什么变化或影响。"""

TIMELINE_LAYOUT_NEGATIVE = """不要做成一堆卡片加装饰线。
不要让时间轴和内容相距太远导致对应不清。
不要在空间顺序上违反时间顺序。
不要把事件节点写成对象百科。
不要在同一图中混用真实时间间距和等距阶段逻辑。
不要给每个节点都加不必要的箭头。"""

SCENE_LAYOUT_CONSTRAINTS = """生成克制、干净、适合书籍正文的概念插图布局说明。
只表达一个核心概念或关系，不讲多个故事。
默认不出现任何可见文字，除非用户明确要求。
可以使用人物、物体、空间、连接、流动、选择或转化作为隐喻。
画面应有单一主视觉路径。
辅助结构可以存在，但必须弱化。"""

SCENE_LAYOUT_NEGATIVE = """不要出现大段文字说明。
不要出现标签框。
不要出现 UI 截图、代码、数据面板、仪表盘元素。
不要出现图标堆积。
不要做成信息图、PPT 示意图、产品宣传图、网站 Hero Banner 或科幻概念艺术。
不要出现多个视觉中心同时竞争注意力。
不要使用高密度纹理或写实摄影风格。"""

LAYOUT_TYPE_MODULES: dict[str, dict[str, str]] = {
    "process_flow": {"constraints": PROCESS_FLOW_LAYOUT_CONSTRAINTS, "negative": PROCESS_FLOW_LAYOUT_NEGATIVE},
    "system_architecture": {"constraints": SYSTEM_ARCHITECTURE_LAYOUT_CONSTRAINTS, "negative": SYSTEM_ARCHITECTURE_LAYOUT_NEGATIVE},
    "mechanism_diagram": {"constraints": MECHANISM_LAYOUT_CONSTRAINTS, "negative": MECHANISM_LAYOUT_NEGATIVE},
    "comparison_matrix": {"constraints": COMPARISON_MATRIX_LAYOUT_CONSTRAINTS, "negative": COMPARISON_MATRIX_LAYOUT_NEGATIVE},
    "concept_diagram": {"constraints": CONCEPT_DIAGRAM_LAYOUT_CONSTRAINTS, "negative": CONCEPT_DIAGRAM_LAYOUT_NEGATIVE},
    "infographic": {"constraints": INFOGRAPHIC_LAYOUT_CONSTRAINTS, "negative": INFOGRAPHIC_LAYOUT_NEGATIVE},
    "taxonomy_map": {"constraints": TAXONOMY_LAYOUT_CONSTRAINTS, "negative": TAXONOMY_LAYOUT_NEGATIVE},
    "decision_tree": {"constraints": DECISION_TREE_LAYOUT_CONSTRAINTS, "negative": DECISION_TREE_LAYOUT_NEGATIVE},
    "timeline_roadmap": {"constraints": TIMELINE_LAYOUT_CONSTRAINTS, "negative": TIMELINE_LAYOUT_NEGATIVE},
    "scene_illustration": {"constraints": SCENE_LAYOUT_CONSTRAINTS, "negative": SCENE_LAYOUT_NEGATIVE},
}

IMAGE_TYPE_RENDER_BLOCKS: dict[str, str] = {
    "process_flow": "画成清晰步骤流程图；步骤节点完整、顺序明确；长流程使用蛇形折返；主路径最清楚，反馈或返回线更轻。",
    "system_architecture": "画成系统架构图；层、模块、外部对象、共享基础设施边界清楚；箭头表达通信、查询、写入、返回或异步通知。",
    "mechanism_diagram": "画成机制原理图；保留变量、公式、矩阵、向量、权重、状态和输入输出之间的具体作用关系。",
    "comparison_matrix": "画成对比矩阵；固定行列轴，同一维度下信息结构一致，不使用流程箭头。",
    "concept_diagram": "画成概念关系图；核心概念、同级概念、分组和关系标签清晰，不能误读为流程。",
    "infographic": "画成信息图；围绕一个主题组织模块、分类、指标或结论，模块之间有明确组织关系。",
    "taxonomy_map": "画成分类图；根节点、分类层级、成员归属清晰，连接线表示属于而不是流程。",
    "decision_tree": "画成决策树；判断节点、分支标签和结果节点清楚，每条路径到达唯一结果。",
    "timeline_roadmap": "画成时间线或路线图；时间轴贯穿画面，所有节点锚定在时间轴上，顺序不可错乱。",
    "scene_illustration": "画成概念场景插图；默认少字或无字，使用克制隐喻表达核心概念，不做信息图或 UI 截图。",
}

STYLE_BLOCK = """生成一张适合书籍正文或课程讲义使用的清晰解释型图示。
整体参考高质量教育图、技术讲解图、书籍插图风格。
不要生成网页截图、PPT 模板、海报或装饰插画。

使用：
- 浅色或白色背景
- 深色高可读文字
- 轻量线条
- 圆角卡片或清晰分区
- 少量低饱和强调色
- 统一字体层级
- 统一边框样式
- 统一线条粗细
- 统一图标风格
- 充足留白
- 清楚安全边距

视觉上应干净、克制、专业、结构明确。
图标可以用于辅助识别，但尺寸和视觉重量必须低于主要文字。
颜色只用于辅助分组、强调或层级，不得依赖颜色单独表达逻辑。"""

NEGATIVE_BLOCK = """不要生成黑底高对比图、霓虹科技风、赛博朋克风、3D 渲染、摄影写实、厚重阴影、复杂渐变、纹理背景、网页首屏、仪表盘 UI、PPT 模板或宣传海报。
不要生成潦草手绘、黑白线稿草图、低完成度示意图。
不要裁切任何文字、节点、箭头或图例。
不要让连接线穿过文字或节点。
不要添加 LayoutScript 未提供的标题、英文标签、英文说明、编号、术语或注释。
不要遗漏 LayoutScript 明确要求的步骤、模块、类别、时间点、关系和箭头标签。
不要把中文翻译成英文，也不要把英文翻译成中文。"""

STRUCTURE_FIDELITY_BLOCK = """1. 图片中的所有节点、模块、分组、时间点、公式、箭头标签和注释，必须来自 LayoutScript 的可见文字白名单。
2. 不得新增任何不在白名单中的可见文字。
3. 不得翻译、改写、扩写、缩写或替换任何标题、节点名、标签、注释、术语或公式。
4. 如果文本是中文，保持中文；如果是英文，保持英文；如果中英文混合，保持原始混合形式。
5. 不得自行新增英文标签、英文标题、英文缩写或英文说明。
6. 所有模块、步骤、类别、时间点、关系和箭头必须完整出现，不得遗漏、合并、改名或替换。
7. 箭头方向、主次关系、反馈回路、返回线、异步线、共享组件和局部处理链必须按照 LayoutScript 表达。
8. 不得为了视觉对称改变 LayoutScript 中的顺序、层级、关系或含义。"""

TEXT_RENDERING_BLOCK = """1. 所有可见文字必须清晰、完整、水平、可读。
2. 中文必须是规范中文字符，不得出现伪字、乱码、形似中文但不可读的字符。
3. 英文、数字、公式、缩写必须逐字准确。
4. 长文本必须自动换行，不得重叠、挤压或裁切。
5. 如果内容较多，优先扩大布局、增加留白、分组或换行，不要缩小文字到难以阅读。
6. 主要标题、节点名、模块名应明显可读。
7. 图标只作为辅助，不得替代文字。"""


def layout_modules_for_subtype(subtype: str) -> dict[str, str]:
    st = canonical_subtype(subtype)
    return LAYOUT_TYPE_MODULES.get(st, LAYOUT_TYPE_MODULES["concept_diagram"])


def image_type_render_block(subtype: str) -> str:
    st = canonical_subtype(subtype)
    return IMAGE_TYPE_RENDER_BLOCKS.get(st, IMAGE_TYPE_RENDER_BLOCKS["concept_diagram"])


def build_layout_agent_prompt(
    user_input: str,
    primary_type: str,
    *,
    secondary_type: str = "",
    do_not_draw_as: str = "",
    layout_risks: str = "",
) -> str:
    st = canonical_subtype(primary_type)
    module = layout_modules_for_subtype(st)
    return f"""你是图示布局规划 Agent。

你的任务：
把用户原始输入转化为 LayoutScript。

LayoutScript 是给 image API 使用的自然语言版式说明书。
它用于固定图片中的文字、模块、区域、主结构、连接关系、复杂关系和禁止简化项。

不要生成图片。
不要输出 JSON。
不要输出 SVG。
不要输出 Mermaid。
不要把复杂关系压缩成 nodes / edges / groups 表格。
不要重新创作用户内容。
不要总结成新的术语。
不要翻译用户提供的文字。
不要新增用户未提供的标题、节点名、标签、注释、英文缩写或术语。

输入：
- 用户原始输入：
{user_input}

- 主图类：{st}
- 辅图类：{secondary_type or "无"}
- 不要画成：{do_not_draw_as or "无"}
- Layout 风险：{layout_risks or "无"}

- 当前主图类布局约束：
{module["constraints"]}

- 当前主图类布局负面约束：
{module["negative"]}

最高原则：
只按当前主图类进行布局。
不要应用其他图类的完整规则。
辅图类只用于处理局部结构，不得改变主图类。
不要把用户内容归纳成抽象关系类型。
不要输出 depends_on、causes、belongs_to 之类的通用关系建模。
只描述这条关系在图中如何呈现：
谁放在哪里，谁连向谁，箭头是什么方向，标签是什么，线型强弱如何，是否属于主路径、返回路径、反馈路径、异步路径、归属关系或辅助关系。

输出格式：

【图类确认】
主图类：
辅图类：
这张图首先应该被读作：
不要画成：

【可见文字白名单】
图片中只能出现以下文字。
必须逐字复制，不得改写、翻译、扩写、缩写、替换或新增。

标题：
- ...

分组标题：
- ...

节点 / 模块文字：
- ...

箭头 / 关系标签：
- ...

注释 / 公式 / 时间点：
- ...

如果某一类为空，写“无”。

【整体版式】
说明画布方向、主要区域、阅读顺序、主结构、空间分组。

【区域与模块摆放】
逐条说明每个区域、模块、节点、分组应该放在哪里。
说明主模块、辅助模块、外部对象、共享组件、注释区域的相对位置。

【连接关系画法】
逐条说明连接线如何画。
每条关系说明：
- 从哪里连到哪里
- 箭头方向
- 是否是主路径
- 是否是返回线、反馈线、异步线、归属线、影响线、对应线
- 标签使用哪段原文
- 是否使用较轻线条或虚线
- 是否需要汇合、分叉、回路、双通道、共享访问

【复杂关系保真】
列出本图中最容易被画错、漏掉或简化的关系。

【布局禁忌】
写出本图绝对不要出现的结构误读。
必须结合当前主图类布局负面约束。

【应用的当前图类约束】
复述你本次实际应用了哪些当前图类布局约束。
只允许来自当前主图类，不要列出其他图类规则。

最终输出：
只输出 LayoutScript。
不要输出解释。
不要输出 JSON。
不要输出 SVG。
不要输出 Mermaid。
""".strip()


def build_layoutscript_image_prompt(layout_script: str, subtype: str) -> str:
    st = canonical_subtype(subtype)
    return f"""请根据下面的 LayoutScript 生成图片。

LayoutScript 是唯一结构依据。
不要回看或推断其他内容。
不得新增、删除、改写任何 LayoutScript 中的文字、节点、关系或布局。

【LayoutScript】
{layout_script.strip()}

【结构保真要求】
{STRUCTURE_FIDELITY_BLOCK}

【文字渲染要求】
{TEXT_RENDERING_BLOCK}

【视觉风格要求】
{STYLE_BLOCK}

【图类渲染约束】
{image_type_render_block(st)}

【生成优先级】
1. 文字准确、完整、可读
2. LayoutScript 中的结构、顺序、层级、关系准确
3. 图类语义正确
4. 布局清楚且不裁切
5. 风格统一、美观、适合书籍正文
6. 图标、装饰、细节

当发生冲突时，牺牲装饰、复杂背景和图标，不能牺牲文字、结构和关系。

【通用负面约束】
{NEGATIVE_BLOCK}
""".strip()


def build_direct_fallback_prompt(user_input: str, subtype: str) -> str:
    st = canonical_subtype(subtype)
    module = layout_modules_for_subtype(st)
    return f"""{str(user_input or "").strip()}

请严格根据上面的内容生成图片。不要把内容改写成 JSON，不要自行补充未提供的信息。

【文字语言要求】
图片中所有可见文字必须严格使用用户原始输入中提供的文字。
不得翻译、改写、扩写或替换任何标题、节点名、标签、注释或术语。
如果原始文本是中文，保持中文；如果是英文，保持英文；如果中英文混合，保持原始混合形式。
不得自行新增未提供的英文标签、英文标题、英文缩写或英文说明。
不得把中文术语翻译成英文，也不得把英文术语翻译成中文。

【公共图示约束】
生成一张适合书籍正文或课程讲义使用的清晰解释型图示。
整体使用浅色或白色背景，深色高可读文字，轻量线条，少量低饱和强调色。
画面应像专业教育图、技术讲解图或书籍插图，而不是黑白草图、网页截图、海报或装饰插画。
优先保证信息准确、结构清楚、文字可读。
所有主要节点、模块、步骤、类别、时间点必须完整出现，不得遗漏、合并、改名或替换。
图片四周必须保留安全边距，任何文字、节点、箭头、图例不得被裁切。
如果内容较多，优先扩大布局、换行、分组或折行排列，不要缩小文字到难以阅读。

【当前图类约束】
{module["constraints"]}

【图类渲染约束】
{image_type_render_block(st)}

【负面约束】
{module["negative"]}
{NEGATIVE_BLOCK}
""".strip()


def build_v3_image_prompt(user_input: str, subtype: str) -> str:
    """Compatibility helper for direct fallback prompts."""
    return build_direct_fallback_prompt(user_input, subtype)
