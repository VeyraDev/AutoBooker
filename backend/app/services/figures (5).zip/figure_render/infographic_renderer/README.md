# Infographic Renderer

This package implements the deterministic infographic route referenced by
`infographic_renderer_mvp`.

Pipeline:

```text
user request
-> DiagramSpec compiler
-> validator / normalizer
-> template SVG renderer
-> PNG export
```

Key constraints:

- The Image API is not used for main text, cards, connectors, tables, or module
  layout.
- The legacy GraphIR / generic nodes-edges renderer is not reused.
- LLM output is a `DiagramSpec` only; it must not contain coordinates, SVG, CSS,
  or canvas instructions.
- Fuzzy input returns `needs_clarification` and is blocked before rendering.
- The public figure asset remains PNG-first; the temporary SVG used for export is
  deleted after PNG generation, so `svg_url` stays empty for this route.

Implemented templates:

- `horizontal_stage_cards`
- `snake_cards`
- `grouped_infographic`
- `vertical_layers`
- `rag_three_column`
- `comparison_matrix`
- `decision_cards`
- `horizontal_timeline`
- `taxonomy_tree`
- `hub_spoke_concept`
- `mechanism_mapping`

Primary entry points:

- `compile_diagram_spec()`
- `validate_and_normalize()`
- `render_infographic_spec()`
