"""Grammar parser 执行器：LLM 优先 + 质量门禁 + 重试，禁止规则兜底漏入生产路径。"""

from __future__ import annotations

import logging
from typing import Any

from app.services.figures.parse.registry import parse_diagram_fallback
from app.services.figures.pipeline.grammar_bridge import grammar_spec_usable
from app.services.figures.schemas.diagram import DiagramIntent, ParsedDiagram, PipelineContext
from app.services.figures.validate.grammar_quality import (
    is_llm_parser_source,
    is_rules_parser_source,
    validate_grammar_output,
)

logger = logging.getLogger(__name__)

MAX_LLM_GRAMMAR_ATTEMPTS = 3


def run_grammar_parser(
    ctx: PipelineContext,
    intent: DiagramIntent,
) -> tuple[ParsedDiagram, list[str], dict[str, Any]]:
    """
    返回 (parsed, quality_issues, meta)。
    use_llm=True 时仅接受 llm_* source 且通过 validate_grammar_output。
    """
    meta: dict[str, Any] = {"attempts": []}
    all_issues: list[str] = []
    parsed = ParsedDiagram({}, source="none")
    critique = ""

    attempts = MAX_LLM_GRAMMAR_ATTEMPTS if ctx.use_llm else 1
    for attempt in range(attempts):
        ctx.parser_attempt = attempt  # type: ignore[attr-defined]
        ctx.parser_critique = critique  # type: ignore[attr-defined]

        parsed = parse_diagram_fallback(ctx, intent)
        attempt_info = {
            "attempt": attempt + 1,
            "source": parsed.source,
            "usable": grammar_spec_usable(parsed.parsed_spec or {}, intent),
        }

        if ctx.use_llm:
            if is_rules_parser_source(parsed.source):
                issue = f"attempt_{attempt + 1}:rules_source_rejected"
                all_issues.append(issue)
                attempt_info["issues"] = [issue]
                meta["attempts"].append(attempt_info)
                critique = "必须使用 LLM 解析并输出完整层级 JSON，不得使用规则切分"
                continue
            if not is_llm_parser_source(parsed.source):
                issue = f"attempt_{attempt + 1}:non_llm_source:{parsed.source}"
                all_issues.append(issue)
                attempt_info["issues"] = [issue]
                meta["attempts"].append(attempt_info)
                critique = "输出源无效，请重新生成合法 JSON"
                continue

        q_issues = validate_grammar_output(
            parsed.parsed_spec or {},
            intent.diagram_subtype,
            ctx.normalized_input,
            parser_source=parsed.source,
        )
        if q_issues:
            all_issues.extend(q_issues)
            attempt_info["issues"] = q_issues
            meta["attempts"].append(attempt_info)
            critique = "；".join(q_issues)
            logger.info("grammar quality failed attempt %s: %s", attempt + 1, q_issues)
            continue

        if not grammar_spec_usable(parsed.parsed_spec or {}, intent):
            issue = "grammar_spec_unusable"
            all_issues.append(issue)
            attempt_info["issues"] = [issue]
            meta["attempts"].append(attempt_info)
            critique = "JSON 字段不完整，请补全 nodes/edges 或类型必需字段"
            continue

        attempt_info["passed"] = True
        meta["attempts"].append(attempt_info)
        meta["passed_attempt"] = attempt + 1
        return parsed, [], meta

    meta["passed_attempt"] = 0
    meta["exhausted"] = True
    return parsed, list(dict.fromkeys(all_issues)), meta
