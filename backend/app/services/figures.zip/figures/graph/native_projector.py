"""Native Structure → GraphIR 类型化投影。"""

from __future__ import annotations

import re
from typing import Any

from app.services.figures.graph.schema import GraphEdge, GraphIR, GraphNode
from app.services.figures.intent.taxonomy import canonical_subtype
from app.services.figures.schemas.diagram import DiagramIntent
from app.services.figures.schemas.dsl import slug_id
from app.services.figures.semantic.schema import SemanticIR


def project_native_to_graph(ir: SemanticIR, intent: DiagramIntent) -> GraphIR | None:
    native = ir.native_structure or {}
    ntype = ir.native_type()
    if not ntype:
        return None

    projectors = {
        "comparison_matrix": _project_comparison,
        "comparison": _project_comparison,
        "timeline": _project_timeline,
        "timeline_roadmap": _project_timeline,
        "taxonomy": _project_taxonomy,
        "taxonomy_map": _project_taxonomy,
        "process_flow": _project_flow,
        "flowchart": _project_flow,
        "pipeline": _project_flow,
        "shared_architecture": _project_architecture,
        "architecture": _project_architecture,
        "system_architecture": _project_architecture,
        "mechanism": _project_mechanism,
        "mechanism_diagram": _project_mechanism,
        "decision_tree": _project_decision,
        "decision_flow": _project_decision,
        "concept": _project_concept,
        "concept_diagram": _project_concept,
    }
    fn = projectors.get(ntype)
    if not fn:
        return None
    graph = fn(native, ir, intent)
    if graph:
        hints = list(ir.layout_hints)
        subtype = canonical_subtype(intent.diagram_subtype)
        if subtype == "taxonomy_map" and "tree_tb" not in hints:
            hints.append("tree_tb")
        if subtype == "system_architecture" and "layered_architecture" not in hints:
            hints.append("layered_architecture")
        graph.layout_constraints = {"hints": hints}
        graph.style_hints = list(ir.style_hints)
    return graph


def _project_comparison(native: dict, ir: SemanticIR, intent: DiagramIntent) -> GraphIR:
    subjects = [str(x) for x in (native.get("subjects") or native.get("columns") or [])]
    dimensions = [str(x) for x in (native.get("dimensions") or [])]
    nodes = [GraphNode(id="matrix", label=ir.title or "对比", kind="module", shape="rounded")]
    edges: list[GraphEdge] = []
    for i, dim in enumerate(dimensions):
        did = f"d{i}"
        nodes.append(GraphNode(id=did, label=dim, kind="module", shape="box"))
        edges.append(GraphEdge(source="matrix", target=did, label=""))
    for j, subj in enumerate(subjects):
        cid = f"c{j}"
        nodes.append(GraphNode(id=cid, label=subj, kind="tag", shape="tag"))
        if dimensions:
            edges.append(GraphEdge(source=f"d{min(j, len(dimensions) - 1)}", target=cid, label=""))
    return GraphIR(
        diagram_type="comparison",
        title=ir.title or intent.title or "对比",
        nodes=nodes,
        edges=edges,
    )


def _project_timeline(native: dict, ir: SemanticIR, intent: DiagramIntent) -> GraphIR:
    milestones = native.get("milestones") or native.get("events") or []
    nodes: list[GraphNode] = []
    edges: list[GraphEdge] = []
    for i, m in enumerate(milestones):
        if not isinstance(m, dict):
            continue
        label = f"{m.get('time', '')} {m.get('label', '')}".strip()
        nid = f"e{i}"
        nodes.append(GraphNode(id=nid, label=label or f"节点{i + 1}", kind="process", shape="rounded"))
        if i > 0:
            edges.append(GraphEdge(source=f"e{i - 1}", target=nid, label=""))
    return GraphIR(diagram_type="timeline", title=ir.title or intent.title or "时间线", nodes=nodes, edges=edges)


def _project_taxonomy(native: dict, ir: SemanticIR, intent: DiagramIntent) -> GraphIR:
    root = str(native.get("root") or ir.title or "根")
    children = native.get("children") or []
    nodes = [GraphNode(id="root", label=root, kind="module", shape="rounded")]
    edges: list[GraphEdge] = []

    def walk(parent_id: str, items: list, *, prefix: str, level: int) -> None:
        for i, child in enumerate(items):
            if not isinstance(child, dict):
                continue
            cid = f"{prefix}{i}"
            nodes.append(GraphNode(id=cid, label=str(child.get("label") or f"分支{i + 1}"), kind="module", shape="box", group=parent_id))
            edges.append(GraphEdge(source=parent_id, target=cid, label=""))
            walk(cid, child.get("children") or [], prefix=f"{cid}_", level=level + 1)

    walk("root", children, prefix="c", level=1)
    return GraphIR(diagram_type="taxonomy", title=ir.title or intent.title or root, nodes=nodes, edges=edges)


def _project_flow(native: dict, ir: SemanticIR, intent: DiagramIntent) -> GraphIR:
    steps = native.get("steps") or []
    nodes: list[GraphNode] = []
    id_map: dict[str, str] = {}
    for i, step in enumerate(steps):
        if not isinstance(step, dict):
            continue
        sid = str(step.get("id") or f"s{i}")
        label = str(step.get("label") or f"步骤{i + 1}")
        raw_kind = str(step.get("kind") or "step").lower()
        if raw_kind == "decision" or re.search(r"是否|判断", label):
            kind = "decision"
        else:
            kind = "process"
        level = int(step.get("level", i)) if step.get("level") is not None else i
        column = int(step.get("column", 0)) if step.get("column") is not None else 0
        nodes.append(
            GraphNode(
                id=sid,
                label=label,
                kind=kind,
                shape="diamond" if kind == "decision" else "rounded",
                layout_constraints={"level": level, "column": column, "parallel": raw_kind == "parallel"},
            )
        )
        id_map[sid] = sid
    edges: list[GraphEdge] = []
    for edge in list(native.get("edges") or []) + list(native.get("feedback") or []):
        if not isinstance(edge, dict):
            continue
        src = str(edge.get("from") or "")
        tgt = str(edge.get("to") or "")
        if src in id_map and tgt in id_map:
            label = str(edge.get("label") or "")
            is_feedback = edge in (native.get("feedback") or []) or label in {"不达标", "返回", "重试", "未达标"}
            edges.append(
                GraphEdge(
                    source=src,
                    target=tgt,
                    label=label,
                    edge_type="return" if is_feedback else "sync",
                    style="dashed" if is_feedback else "solid",
                )
            )
    if not edges and len(nodes) >= 2:
        for i in range(len(nodes) - 1):
            edges.append(GraphEdge(source=nodes[i].id, target=nodes[i + 1].id, label=""))
    hints = list(ir.layout_hints)
    if any(isinstance(s, dict) and str(s.get("kind") or "").lower() == "parallel" for s in steps):
        if "parallel_merge" not in hints:
            hints.append("parallel_merge")
    if any(e.edge_type == "return" for e in edges) and "TB_Decision" not in hints:
        hints.append("TB_Decision")
    return GraphIR(
        diagram_type="flowchart",
        title=ir.title or intent.title or "流程",
        nodes=nodes,
        edges=edges,
        layout_constraints={"hints": hints},
        style_hints=list(ir.style_hints),
    )


def _project_architecture(native: dict, ir: SemanticIR, intent: DiagramIntent) -> GraphIR:
    components = [str(c) for c in (native.get("components") or [])]
    groups_raw = native.get("groups") or ir.groups or []
    nodes: list[GraphNode] = []
    comp_to_id: dict[str, str] = {}
    for i, comp in enumerate(components):
        nid = slug_id(comp) or f"m{i}"
        comp_to_id[comp] = nid
        group = ""
        for g in groups_raw:
            if isinstance(g, dict) and comp in [str(m) for m in (g.get("members") or [])]:
                group = str(g.get("label") or g.get("id") or "")
        nodes.append(GraphNode(id=nid, label=comp, kind="service", group=group, shape="box"))
    edges: list[GraphEdge] = []
    for inter in native.get("interactions") or []:
        if not isinstance(inter, dict):
            continue
        src = comp_to_id.get(str(inter.get("from") or ""), str(inter.get("from") or ""))
        tgt = comp_to_id.get(str(inter.get("to") or ""), str(inter.get("to") or ""))
        if src and tgt:
            edges.append(GraphEdge(source=src, target=tgt, label=str(inter.get("label") or "")))
    groups = [dict(g) for g in groups_raw if isinstance(g, dict)]
    return GraphIR(
        diagram_type="architecture",
        title=ir.title or intent.title or "架构",
        nodes=nodes,
        edges=edges,
        groups=groups,
    )


def _project_mechanism(native: dict, ir: SemanticIR, intent: DiagramIntent) -> GraphIR:
    nodes: list[GraphNode] = []
    edges: list[GraphEdge] = []
    prev = ""
    for i, inp in enumerate(native.get("inputs") or []):
        nid = f"in{i}"
        nodes.append(GraphNode(id=nid, label=str(inp), kind="process"))
        if prev:
            edges.append(GraphEdge(source=prev, target=nid, label=""))
        prev = nid
    for j, step in enumerate(native.get("steps") or []):
        label = step.get("label") if isinstance(step, dict) else str(step)
        nid = f"step{j}"
        nodes.append(GraphNode(id=nid, label=str(label), kind="process"))
        if prev:
            edges.append(GraphEdge(source=prev, target=nid, label=""))
        prev = nid
    for k, out in enumerate(native.get("outputs") or []):
        nid = f"out{k}"
        nodes.append(GraphNode(id=nid, label=str(out), kind="process"))
        if prev:
            edges.append(GraphEdge(source=prev, target=nid, label=""))
    return GraphIR(diagram_type="flowchart", title=ir.title or intent.title or "机制", nodes=nodes, edges=edges)


def _project_decision(native: dict, ir: SemanticIR, intent: DiagramIntent) -> GraphIR:
    root = str(native.get("root") or ir.title or "起点")
    nodes = [GraphNode(id="root", label=root, kind="start", shape="rounded")]
    edges: list[GraphEdge] = []
    for i, br in enumerate(native.get("branches") or []):
        if not isinstance(br, dict):
            continue
        cond = str(br.get("condition") or f"判断{i + 1}")
        cid = f"d{i}"
        nodes.append(GraphNode(id=cid, label=cond, kind="decision", shape="diamond"))
        edges.append(GraphEdge(source="root", target=cid, label=""))
        for key, suffix in (("yes", "y"), ("no", "n")):
            val = br.get(key)
            if val:
                oid = f"{cid}_{suffix}"
                nodes.append(GraphNode(id=oid, label=str(val), kind="process"))
                edges.append(GraphEdge(source=cid, target=oid, label=key))
    return GraphIR(diagram_type="decision_flow", title=ir.title or intent.title or "决策", nodes=nodes, edges=edges)


def _project_concept(native: dict, ir: SemanticIR, intent: DiagramIntent) -> GraphIR:
    concepts = [str(c) for c in (native.get("concepts") or [])]
    nodes = [GraphNode(id=slug_id(c) or f"c{i}", label=c, kind="module") for i, c in enumerate(concepts)]
    edges: list[GraphEdge] = []
    for rel in native.get("relations") or ir.relations or []:
        if not isinstance(rel, dict):
            continue
        src = str(rel.get("from") or "")
        tgt = str(rel.get("to") or "")
        name_to_id = {n.label: n.id for n in nodes}
        s = name_to_id.get(src, src)
        t = name_to_id.get(tgt, tgt)
        if s and t:
            edges.append(GraphEdge(source=s, target=t, label=str(rel.get("label") or "")))
    return GraphIR(diagram_type="taxonomy", title=ir.title or intent.title or "概念图", nodes=nodes, edges=edges)
