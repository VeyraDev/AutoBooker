"""流程图规则：并行分支、汇合、反馈回环（semantic / grammar 共用）。"""

from __future__ import annotations

import re
from typing import Any

_PARALLEL_RE = re.compile(r"并行|两支|两个.{0,6}分支|分叉|汇合")
_FEEDBACK_RE = re.compile(r"不达标|未达标|返回|重试|回路|反馈")
_PREP_RE = re.compile(r"数据准备|准备数据|预处理")
_TRAIN_RE = re.compile(r"训练")


def _short(text: Any, limit: int = 22) -> str:
    raw = re.sub(r"\s+", " ", str(text or "").strip()).strip(" ：:，,。")
    return raw[:limit].strip(" ：:，,。")


def _clean_stage_label(text: str) -> str:
    label = _short(text, 22)
    label = re.sub(r"^(?:从|经过|最终|最后|然后|接着|再到|汇合后|汇合后进行|进行)", "", label).strip()
    label = re.sub(r"(?:两个|两条|多个)?并行分支$", "", label).strip()
    return _short(label.strip(" ：:，,。"), 12)


def infer_parallel_flow_from_text(text: str) -> dict[str, Any] | None:
    """从描述抽取标准并行+汇合+反馈 process_flow native 结构。"""
    if not _PARALLEL_RE.search(text):
        return None
    branch_match = re.search(
        r"(?:包含|包括|有)?([^，,。；;]+?)、([^，,。；;]+?)(?:两个|两条|多个)?并行分支",
        text,
    )
    merge_match = re.search(r"汇合后(?:进行)?([^，,。；;]+)", text)
    eval_match = re.search(r"(?:最后|最终)([^，,。；;]+)", text)
    feedback_match = re.search(
        r"若([^，,。；;]+?)则返回([^，,。；;]+?)(?:步骤|阶段|环节)?(?:，|,|。|$)",
        text,
    )
    if not branch_match or not merge_match:
        return None

    left = _clean_stage_label(branch_match.group(1))
    right = _clean_stage_label(branch_match.group(2))
    merge = _clean_stage_label(merge_match.group(1))
    eval_label = _clean_stage_label(eval_match.group(1)) if eval_match else "评估"
    condition = _clean_stage_label(feedback_match.group(1)) if feedback_match else "是否达标"
    if condition == "不达标":
        condition = "是否达标"
    if condition and not condition.startswith("是否"):
        condition = "是否" + condition

    return_target = _clean_stage_label(feedback_match.group(2)) if feedback_match else left
    steps = [
        {"id": "s0", "label": left, "kind": "parallel", "level": 0, "column": 0},
        {"id": "s1", "label": right, "kind": "parallel", "level": 0, "column": 1},
        {"id": "s2", "label": merge, "kind": "step", "level": 1, "column": 0},
        {"id": "s3", "label": eval_label, "kind": "step", "level": 2, "column": 0},
        {"id": "s4", "label": condition or "是否达标", "kind": "decision", "level": 3, "column": 0},
    ]
    feedback_target = "s0"
    for step in steps:
        if step["label"] == return_target or return_target in step["label"] or step["label"] in return_target:
            feedback_target = step["id"]
            break

    edges = [
        {"from": "s0", "to": "s2", "label": ""},
        {"from": "s1", "to": "s2", "label": ""},
        {"from": "s2", "to": "s3", "label": ""},
        {"from": "s3", "to": "s4", "label": ""},
    ]
    feedback = [{"from": "s4", "to": feedback_target, "label": "不达标"}]
    if re.search(r"(?:达标|通过)(?:后|则)?(?:结束|完成|输出)|否则结束", text):
        steps.append({"id": "s5", "label": "结束", "kind": "output", "level": 4, "column": 1})
        edges.append({"from": "s4", "to": "s5", "label": "达标"})

    return {
        "type": "process_flow",
        "steps": steps,
        "edges": edges,
        "feedback": feedback,
    }


def process_flow_structure_issues(native: dict[str, Any], text: str) -> list[str]:
    """检查 process_flow native / grammar spec 结构问题。"""
    issues: list[str] = []
    steps = [s for s in (native.get("steps") or native.get("stages") or []) if isinstance(s, dict)]
    if len(steps) < 2:
        issues.append("flow_missing_steps")
        return issues

    if _PARALLEL_RE.search(text):
        parallel_steps = [s for s in steps if str(s.get("kind") or "").lower() in {"parallel", "branch"}]
        cols = {int(s.get("column", 0)) for s in steps if "column" in s}
        if len(parallel_steps) < 2 and len(cols) < 2:
            issues.append("flow_missing_parallel_branches")

    if _FEEDBACK_RE.search(text):
        feedback = native.get("feedback") or []
        has_return = bool(feedback) or any(
            isinstance(e, dict) and str(e.get("label") or "") in {"不达标", "返回", "重试", "未达标"}
            for e in (native.get("edges") or [])
        )
        if not has_return:
            issues.append("flow_missing_feedback_loop")

    labels = [str(s.get("label") or "") for s in steps]
    if _PREP_RE.search(text) and labels:
        prep_idx = next((i for i, lb in enumerate(labels) if _PREP_RE.search(lb)), None)
        train_idx = next((i for i, lb in enumerate(labels) if _TRAIN_RE.search(lb)), None)
        if prep_idx is not None and train_idx is not None and prep_idx > train_idx:
            issues.append("flow_step_order_wrong")

    return issues


def needs_process_flow_repair(native: dict[str, Any], text: str) -> bool:
    return bool(process_flow_structure_issues(native, text))


def repair_process_flow_native(native: dict[str, Any], text: str) -> dict[str, Any]:
    """用规则修复或重建 process_flow native_structure。"""
    inferred = infer_parallel_flow_from_text(text)
    if inferred:
        return dict(inferred)
    return dict(native)


def build_default_flow_edges(steps: list[dict[str, Any]], feedback: list[dict[str, Any]] | None = None) -> list[dict[str, str]]:
    if len(steps) >= 5 and steps[0].get("kind") == "parallel" and steps[1].get("kind") == "parallel":
        edges = [
            {"from": steps[0]["id"], "to": steps[2]["id"], "label": ""},
            {"from": steps[1]["id"], "to": steps[2]["id"], "label": ""},
            {"from": steps[2]["id"], "to": steps[3]["id"], "label": ""},
            {"from": steps[3]["id"], "to": steps[4]["id"], "label": ""},
        ]
        fb = feedback or [{"from": steps[4]["id"], "to": steps[0]["id"], "label": "不达标"}]
        edges.extend(e for e in fb if e not in edges)
        return edges
    return [{"from": steps[i]["id"], "to": steps[i + 1]["id"], "label": ""} for i in range(len(steps) - 1)]
