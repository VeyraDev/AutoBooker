"""布局策略选择与应用。"""

from __future__ import annotations

from app.services.figures.graph.metrics import compute_graph_metrics
from app.services.figures.graph.schema import GraphIR
from app.services.figures.layout.canvas import center_content_in_canvas, fit_content_to_canvas
from app.services.figures.layout.collision import resolve_collisions
from app.services.figures.layout.edge_router import route_edges
from app.services.figures.layout.fanout import layout_fanout
from app.services.figures.layout.flow_branch import has_flow_layout_hints, layout_flow_branch
from app.services.figures.layout.grid import layout_grid
from app.services.figures.layout.layered import layout_layered
from app.services.figures.layout.linear import layout_linear
from app.services.figures.layout.policies import (
    clamp_canvas_to_policy,
    get_layout_policy,
    select_strategy_for_subtype,
)
from app.services.figures.layout.radial import layout_radial
from app.services.figures.layout.schema import LayoutResult, NodePosition
from app.services.figures.layout.snake import layout_snake
from app.services.figures.layout.tree import layout_tree_tb
from app.services.figures.intent.taxonomy import canonical_subtype, diagram_type_to_subtype
from app.services.figures.schemas.dsl import DiagramDSL


def select_strategy(
    graph: GraphIR,
    metrics: dict | None = None,
    *,
    subtype: str = "",
) -> str:
    m = metrics or compute_graph_metrics(graph)
    hints = [str(x) for x in (graph.layout_constraints.get("hints") or [])]
    st = subtype or getattr(graph, "diagram_subtype", "") or graph.diagram_type or ""
    return select_strategy_for_subtype(
        subtype=st,
        metrics=m,
        graph_diagram_type=graph.diagram_type or "",
        layout_hints=hints,
    )


def compute_layout(graph: GraphIR, *, subtype: str = "") -> LayoutResult:
    metrics = compute_graph_metrics(graph)
    st = subtype or getattr(graph, "diagram_subtype", "") or graph.diagram_type or ""
    strategy = select_strategy(graph, metrics, subtype=st)
    policy = get_layout_policy(st)

    if has_flow_layout_hints(graph):
        layout = layout_flow_branch(graph)
        strategy = layout.strategy
    elif strategy == "fanout":
        in_deg: dict[str, int] = {}
        for e in graph.edges:
            in_deg[e.target] = in_deg.get(e.target, 0) + 1
        roots = [n.id for n in graph.nodes if in_deg.get(n.id, 0) == 0]
        # 单根树形图必须以 root 为 hub，不能用出度≥3 的中间节点（否则兄弟子树会被压扁到底行）
        if len(roots) == 1:
            hub = roots[0]
        else:
            hub = (metrics.get("hub_nodes") or [None])[0] or (graph.nodes[0].id if graph.nodes else "")
        layout = layout_fanout(graph, hub)
    elif strategy == "snake":
        layout = layout_snake(graph)
    elif strategy == "LR":
        layout = layout_linear(graph)
    elif strategy == "grid":
        layout = layout_grid(graph)
    elif strategy == "radial":
        layout = layout_radial(graph)
    elif strategy == "TB_Decision":
        layout = layout_layered(graph)
        layout.direction = "TB"
    elif strategy == "layered" and (
        canonical_subtype(st) in {"taxonomy_map", "concept_diagram"}
        and int(metrics.get("max_depth") or 0) >= 2
    ):
        layout = layout_tree_tb(graph)
    else:
        layout = layout_layered(graph)

    # 统一节点尺寸基线
    for pos in layout.node_positions.values():
        if pos.width <= 0:
            pos.width = policy.node_width
        if pos.height <= 0:
            pos.height = policy.node_height

    resolve_collisions(layout)
    fit_content_to_canvas(layout)
    route_edges(layout, graph.edges, direction=layout.direction, strategy=strategy)
    clamp_canvas_to_policy(layout, st)
    center_content_in_canvas(layout)
    layout.strategy = strategy
    return layout


def _dsl_layout_subtype(dsl: DiagramDSL, subtype: str = "") -> str:
    if subtype:
        return subtype
    return diagram_type_to_subtype(dsl.diagram_type or "flowchart")


def apply_layout_to_dsl(dsl: DiagramDSL, layout: LayoutResult, *, subtype: str = "") -> DiagramDSL:
    st = _dsl_layout_subtype(dsl, subtype)
    dir_map = {
        "LR": "LR",
        "snake": "LR",
        "layered": "TB",
        "TB_Decision": "TB",
        "flow_branch": "TB",
        "fanout": "TB",
        "grid": "GRID",
        "radial": "RADIAL",
    }
    dsl.layout = {
        "direction": dir_map.get(layout.strategy, layout.direction),
        "mode": layout.strategy,
        "canvas": dict(layout.canvas),
        "node_positions": {k: v.to_dict() for k, v in layout.node_positions.items()},
        "edge_routes": [e.to_dict() for e in layout.edge_routes],
        "aspect_ratio": layout.canvas.get("aspect_ratio"),
    }
    gap_y = policy_node_gap_y(dsl, subtype=st)
    gap_x = policy_node_gap_x(dsl, subtype=st)
    for node in dsl.nodes:
        pos = layout.node_positions.get(node.id)
        if pos:
            node.level = int(pos.y // max(gap_y, 1))
            node.column = int(pos.x // max(gap_x, 1))
    return dsl


def policy_node_gap_y(dsl: DiagramDSL, *, subtype: str = "") -> float:
    return get_layout_policy(_dsl_layout_subtype(dsl, subtype)).node_gap_y


def policy_node_gap_x(dsl: DiagramDSL, *, subtype: str = "") -> float:
    return get_layout_policy(_dsl_layout_subtype(dsl, subtype)).node_gap_x
