"""Intent Understanding 层 — 仅 LLM 产出候选与 goal。"""

from __future__ import annotations

import logging
from typing import Any

from app.config import settings
from app.llm.client import LLMClient
from app.services.figures.intent.taxonomy import canonical_subtype
from app.services.figures.prompts import format_prompt
from app.services.figures.schemas.diagram import DiagramIntent, PipelineContext
from app.utils.json_llm import parse_llm_json

logger = logging.getLogger(__name__)

_GOAL_MAP = {
    "workflow": "show_workflow",
    "architecture": "show_system_architecture",
    "comparison": "show_comparison",
    "timeline": "show_timeline",
    "taxonomy": "show_taxonomy",
    "illustration": "illustrate_scene",
    "data": "show_data",
    "chart": "show_data",
    "decision": "show_decision",
    "organization": "show_taxonomy",
    "matrix": "show_comparison",
    "knowledge": "show_taxonomy",
}


def understand_intent(ctx: PipelineContext, intent: DiagramIntent | None = None) -> dict[str, Any]:
    """输出 goal / candidate_diagrams / constraints / visual_preferences。"""
    llm = _call_intent_understanding_llm(ctx)
    if llm:
        llm.setdefault("candidate_diagrams", llm.get("candidate_diagrams") or [])
        llm.setdefault("constraints", [])
        llm.setdefault("visual_preferences", list(ctx.layout_instructions or []))
        llm.setdefault("missing_info", [])
        if intent:
            llm.setdefault("title", intent.title)
        return llm

    base = intent or DiagramIntent("knowledge", "concept_diagram", 0.5, "no_llm", ctx.normalized_input[:80])
    goal = _GOAL_MAP.get(base.diagram_family, "show_workflow")
    return {
        "goal": goal,
        "domain": "general",
        "user_task": "generate_diagram",
        "candidate_diagrams": [
            {
                "type": canonical_subtype(base.diagram_subtype),
                "score": float(base.confidence),
                "reason": "no_llm_fallback",
            }
        ],
        "constraints": [],
        "visual_preferences": list(ctx.layout_instructions or []),
        "missing_info": [],
        "confidence": float(base.confidence),
        "title": base.title or "",
    }


def _call_intent_understanding_llm(ctx: PipelineContext) -> dict[str, Any] | None:
    model = (ctx.model or settings.intent_model).strip()
    if not ctx.use_llm or not model or not ctx.normalized_input.strip():
        return None
    try:
        prompt = format_prompt("intent_understanding", text=ctx.normalized_input[:2500])
    except OSError:
        return None
    try:
        out = LLMClient().chat_completion(
            [{"role": "system", "content": "只输出合法 JSON。"}, {"role": "user", "content": prompt}],
            model=model,
            max_tokens=800,
            temperature=0.0,
        )
        data = parse_llm_json(out)
    except Exception as e:
        logger.warning("intent understanding LLM failed: %s", e)
        return None
    return data if isinstance(data, dict) else None
