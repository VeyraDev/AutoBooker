"""数据图专用管线 — 不经过 Graph/Layout，直接解析 chart spec。"""

from __future__ import annotations

from typing import Any

from app.services.figures.parse.chart_data import parse_chart_data, parse_chart_data_rules
from app.services.figures.schemas.diagram import DiagramIntent, ParsedDiagram, PipelineContext, VisualPlan


def run_chart_pipeline(
    ctx: PipelineContext,
    intent: DiagramIntent,
) -> tuple[DiagramIntent, ParsedDiagram, VisualPlan | None, dict, list[str], dict[str, Any]]:
    quality_flags: list[str] = []
    ir_bundle: dict[str, Any] = {"intent_understanding": ctx.intent_understanding or {}}

    intent = DiagramIntent(
        "data",
        "chart",
        max(intent.confidence, 0.85),
        intent.source + "+chart_pipeline",
        intent.title,
        diagram_type="chart",
        reason=intent.reason or "数据图专用管线",
        fallback_allowed=intent.fallback_allowed,
    )

    parsed = parse_chart_data(ctx, intent)
    if not (parsed.parsed_spec.get("values") or parsed.parsed_spec.get("series")):
        rule_parsed = parse_chart_data_rules(ctx, intent)
        if rule_parsed.parsed_spec.get("values"):
            parsed = rule_parsed
            quality_flags.append("chart_data_rule_extracted")

    spec = dict(parsed.parsed_spec)
    spec["diagram_subtype"] = "chart"
    spec["render_mode"] = "structured_chart"
    spec["layout_strategy"] = "chart"
    parsed = ParsedDiagram(spec, parsed.source)

    visual = VisualPlan(
        layout="chart",
        style="data visualization; clean axes; publication aspect ratio 4:3",
        visual_description=ctx.normalized_input[:400],
        must_include=["坐标轴", "数据标签", "图例（多系列时）"],
        must_avoid=["装饰性插画", "伪 3D", "无坐标轴示意图"],
    )

    if not spec.get("values") and not spec.get("series"):
        quality_flags.append("chart_missing_numeric_data")

    return intent, parsed, visual, spec, quality_flags, ir_bundle
