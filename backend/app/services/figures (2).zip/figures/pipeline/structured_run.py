"""新结构化管线：Intent → Semantic → Knowledge → Constraints → Graph → Layout。"""

from __future__ import annotations

import logging
import time
from typing import Any

from app.services.figures.constraints.resolver import resolve_constraints
from app.services.figures.dsl.to_parsed_spec import dsl_to_parsed_spec
from app.services.figures.graph.builder import build_graph
from app.services.figures.graph.metrics import compute_graph_metrics
from app.services.figures.catalog.type_catalog import get_type_spec
from app.services.figures.intent.taxonomy import canonical_subtype, subtype_to_diagram_type
from app.services.figures.intent.understand import understand_intent
from app.services.figures.pipeline.grammar_bridge import (
    build_graph_from_grammar_spec,
    grammar_spec_usable,
    grammar_uses_graph_layout,
)
from app.services.figures.knowledge.registry import complete_knowledge
from app.services.figures.layout.selector import apply_layout_to_dsl, compute_layout
from app.services.figures.intent.reconcile import reconcile_intent_with_dsl
from app.services.figures.plan.style_planner import apply_style_hints
from app.services.figures.plan.visual_planner import build_structured_visual_plan
from app.services.figures.schemas.diagram import DiagramIntent, ParsedDiagram, PipelineContext, VisualPlan
from app.services.figures.semantic.extractor import extract_semantic_ir
from app.services.figures.semantic.native_bridge import native_to_grammar_spec, should_render_native_as_grammar_spec
from app.services.figures.validate.dsl_validator import validate_and_repair
from app.services.figures.critic.structural import run_structural_critic
from app.services.figures.validate.semantic_validator import combined_semantic_quality
from app.services.figures.pipeline.grammar_runner import run_grammar_parser
from app.services.figures.quality import semantic_coverage_report
from app.services.figures.validate.grammar_quality import is_llm_parser_source

logger = logging.getLogger(__name__)


def run_structured_pipeline(
    ctx: PipelineContext,
    intent: DiagramIntent,
) -> tuple[DiagramIntent, ParsedDiagram, VisualPlan | None, dict, list[str], dict[str, Any]]:
    """
    返回 intent, parsed, visual, dsl_json, quality_flags, ir_bundle。
    ir_bundle 含 semantic_ir / graph_ir / layout_result 供 classification_json。
    """
    quality_flags: list[str] = []
    ir_bundle: dict[str, Any] = {}

    understanding = ctx.intent_understanding or understand_intent(ctx, intent)
    ctx.intent_understanding = understanding
    ir_bundle["intent_understanding"] = understanding

    subtype = canonical_subtype(intent.diagram_subtype)
    # 语义主路径：Native IR → Critic → Repair → Graph（非 grammar 优先、非单图打补丁）
    if ctx.use_llm and grammar_uses_graph_layout(subtype):
        sem_out = _finalize_semantic_native(
            ctx, intent, understanding, quality_flags, ir_bundle,
            source_label="semantic_native_primary",
        )
        if sem_out:
            return sem_out
        quality_flags.append("semantic_native_failed_try_grammar")

    # grammar parser 作为语义失败后的结构化补全（LLM + 质量门禁 + 重试）
    grammar_parsed, grammar_issues, grammar_meta = run_grammar_parser(ctx, intent)
    ir_bundle["grammar_runner"] = grammar_meta
    if grammar_issues:
        quality_flags.extend(grammar_issues[:8])
        quality_flags.append("grammar_quality_failed")

    grammar_ok = (
        not grammar_issues
        and grammar_spec_usable(grammar_parsed.parsed_spec, intent)
        and (
            not ctx.use_llm
            or is_llm_parser_source(grammar_parsed.source)
            or grammar_parsed.source == "rules_flow_repair"
        )
    )
    if grammar_ok:
        if grammar_uses_graph_layout(intent.diagram_subtype or ""):
            return _finalize_from_grammar_parser(
                ctx, intent, grammar_parsed, quality_flags, ir_bundle,
            )
        return _finalize_grammar_spec_direct(
            ctx, intent, grammar_parsed, quality_flags, ir_bundle,
        )

    rule_out = _finalize_rule_flow_fallback(
        ctx, intent, understanding, quality_flags, ir_bundle,
    )
    if rule_out:
        return rule_out

    if ctx.use_llm:
        logger.warning(
            "grammar LLM exhausted for %s, issues=%s",
            intent.diagram_subtype,
            grammar_issues[:5],
        )
        quality_flags.append("grammar_llm_exhausted")
        return _finalize_grammar_failure(ctx, intent, grammar_parsed, quality_flags, ir_bundle)

    logger.info("grammar unusable for %s (no llm), rules-only blocked", subtype)
    quality_flags.append("grammar_rules_failed")
    return _finalize_grammar_failure(ctx, intent, grammar_parsed, quality_flags, ir_bundle)


def _finalize_semantic_native(
    ctx: PipelineContext,
    intent: DiagramIntent,
    understanding: dict[str, Any],
    quality_flags: list[str],
    ir_bundle: dict[str, Any],
    *,
    source_label: str,
) -> tuple[DiagramIntent, ParsedDiagram, VisualPlan | None, dict, list[str], dict[str, Any]] | None:
    """Semantic Native IR → Graph → Layout；失败返回 None。"""
    if not grammar_uses_graph_layout(intent.diagram_subtype or ""):
        return None

    t0 = time.perf_counter()
    semantic_ir, sem_source = extract_semantic_ir(ctx, intent, understanding=understanding)
    ctx.pipeline_trace.append({"step": "semantic_ir", "ms": int((time.perf_counter() - t0) * 1000), "source": sem_source})
    if not semantic_ir:
        return None

    return _finalize_semantic_ir_direct(
        ctx, intent, understanding, semantic_ir, sem_source,
        quality_flags, ir_bundle, source_label=source_label,
    )


def _finalize_semantic_ir_direct(
    ctx: PipelineContext,
    intent: DiagramIntent,
    understanding: dict[str, Any],
    semantic_ir,
    sem_source: str,
    quality_flags: list[str],
    ir_bundle: dict[str, Any],
    *,
    source_label: str,
) -> tuple[DiagramIntent, ParsedDiagram, VisualPlan | None, dict, list[str], dict[str, Any]]:
    ir_bundle["semantic_ir"] = semantic_ir.to_dict()
    ir_bundle["semantic_source"] = sem_source
    ir_bundle["semantic_native_type"] = semantic_ir.native_type()
    for trace in reversed(ctx.pipeline_trace):
        if trace.get("step") == "semantic_critic":
            ir_bundle["semantic_critic"] = trace
            break
    semantic_quality = combined_semantic_quality(
        ctx.normalized_input,
        ir_bundle["semantic_ir"],
        diagram_type=intent.diagram_type or "flowchart",
        token_coverage_fn=semantic_coverage_report,
    )
    ir_bundle["semantic_quality"] = semantic_quality
    if semantic_quality["score"] < 0.35:
        quality_flags.append("semantic_coverage_low")
    elif semantic_quality["score"] < 0.55:
        quality_flags.append("semantic_coverage_partial")

    domain = str(understanding.get("domain") or semantic_ir.domain or "")
    before_knowledge = semantic_ir.to_dict()
    semantic_ir, knowledge_meta = complete_knowledge(semantic_ir, domain=domain, ctx=ctx)
    if knowledge_meta.get("completed"):
        quality_flags.append("knowledge_completed")
        ir_bundle["knowledge_completion"] = knowledge_meta
        ir_bundle["knowledge_diff"] = {
            "before_objects": len(before_knowledge.get("objects") or []),
            "after_objects": len(semantic_ir.objects),
            "added": knowledge_meta.get("added", []),
        }
    semantic_ir, constraint_issues = resolve_constraints(semantic_ir)
    if constraint_issues:
        quality_flags.extend(constraint_issues[:5])

    if should_render_native_as_grammar_spec(semantic_ir, intent):
        native_spec = native_to_grammar_spec(semantic_ir, intent)
        if native_spec and grammar_spec_usable(native_spec, intent):
            ir_bundle["semantic_native_bridge"] = "grammar_spec"
            native_parsed = ParsedDiagram(native_spec, source=f"{sem_source}_native_bridge")
            return _finalize_from_grammar_parser(
                ctx, intent, native_parsed, quality_flags, ir_bundle,
            )

    graph_ir = build_graph(semantic_ir, intent)
    ir_bundle["graph_ir"] = graph_ir.to_dict()
    ir_bundle["graph_metrics"] = compute_graph_metrics(graph_ir)

    layout_result = compute_layout(graph_ir, subtype=intent.diagram_subtype or "")
    ir_bundle["layout_result"] = layout_result.to_dict()

    dsl = graph_ir.to_dsl(
        layout_direction=layout_result.direction,
        layout_mode=layout_result.strategy,
    )
    dsl = apply_layout_to_dsl(dsl, layout_result, subtype=intent.diagram_subtype or "")
    dsl = apply_style_hints(dsl, semantic_ir.style_hints, graph_ir.style_hints)
    intent = reconcile_intent_with_dsl(intent, dsl)
    dsl.diagram_type = intent.diagram_type or dsl.diagram_type
    dsl.confidence = intent.confidence
    dsl.fallback_allowed = intent.fallback_allowed
    if sem_source not in {"semantic_native_llm", "semantic_native_repaired"}:
        dsl.notes.append(sem_source)

    dsl, validation = validate_and_repair(dsl, source_text=ctx.normalized_input)
    if validation.repaired:
        quality_flags.append("dsl_repaired")
    for issue in validation.issues:
        if issue.severity == "warning":
            quality_flags.append(issue.code)

    visual = build_structured_visual_plan(dsl)
    parsed_spec = dsl_to_parsed_spec(dsl)
    parsed_spec["quality_flags"] = list(dict.fromkeys(list(parsed_spec.get("quality_flags") or []) + quality_flags))
    parsed_spec["layout_result"] = layout_result.to_dict()
    parsed_spec["layout_strategy"] = layout_result.strategy
    dsl_dict = dsl.to_dict()
    critic = run_structural_critic(
        semantic_ir=ir_bundle.get("semantic_ir"),
        dsl_json=dsl_dict,
        parsed_spec=parsed_spec,
        source_text=ctx.normalized_input,
    )
    ir_bundle["structural_critic"] = critic
    if critic.get("status") == "failed":
        quality_flags.append("structural_critic_failed")
    elif critic.get("warnings"):
        quality_flags.extend(critic.get("warnings") or [])

    parsed = ParsedDiagram(parsed_spec, source=source_label)
    return intent, parsed, visual, dsl_dict, quality_flags, ir_bundle


def _finalize_rule_flow_fallback(
    ctx: PipelineContext,
    intent: DiagramIntent,
    understanding: dict[str, Any],
    quality_flags: list[str],
    ir_bundle: dict[str, Any],
) -> tuple[DiagramIntent, ParsedDiagram, VisualPlan | None, dict, list[str], dict[str, Any]] | None:
    """Semantic/Grammar 均失败时，用规则控制流兜底（避免空 nodes）。"""
    from app.services.figures.parse.pipeline import _rule_stages, _title as pipeline_title, _to_graph
    from app.services.figures.semantic.flow_semantic import infer_any_flow_from_text
    from app.services.figures.semantic.schema import SemanticIR

    subtype = canonical_subtype(intent.diagram_subtype)
    if subtype != "process_flow":
        return None

    from app.services.figures.semantic.flow_semantic import flow_semantic_critic, repair_process_flow_native

    native = infer_any_flow_from_text(ctx.normalized_input)
    if native and flow_semantic_critic(native, ctx.normalized_input):
        native = repair_process_flow_native(native, ctx.normalized_input)
    if native and native.get("nodes") and not flow_semantic_critic(native, ctx.normalized_input):
        quality_flags.append("rule_control_flow_fallback")
        ir = SemanticIR(
            diagram_type=intent.diagram_type or "flowchart",
            title=intent.title or ctx.normalized_input[:24] or "流程图",
            native_structure=native,
        )
        ctx.pipeline_trace.append({"step": "rule_flow_fallback", "mode": "control_flow"})
        return _finalize_semantic_ir_direct(
            ctx, intent, understanding, ir, "rule_control_flow",
            quality_flags, ir_bundle, source_label="rule_control_flow",
        )

    stages = _rule_stages(ctx.normalized_input)
    if len(stages) >= 2:
        spec = _to_graph(pipeline_title(intent, ctx.normalized_input), stages, [])
        quality_flags.append("rule_grammar_flow_fallback")
        ctx.pipeline_trace.append({"step": "rule_flow_fallback", "mode": "grammar_stages"})
        return _finalize_from_grammar_parser(
            ctx, intent, ParsedDiagram(spec, "rules_pipeline"), quality_flags, ir_bundle,
        )
    return None


def _finalize_from_grammar_parser(
    ctx: PipelineContext,
    intent: DiagramIntent,
    grammar_parsed: ParsedDiagram,
    quality_flags: list[str],
    ir_bundle: dict[str, Any],
) -> tuple[DiagramIntent, ParsedDiagram, VisualPlan | None, dict, list[str], dict[str, Any]]:
    """grammar parser → Graph → Layout → DSL（结构化主路径）。"""
    spec = dict(grammar_parsed.parsed_spec or {})
    graph_ir = build_graph_from_grammar_spec(spec, intent)
    subtype = canonical_subtype(intent.diagram_subtype)
    ir_bundle["grammar_parser"] = {
        "source": grammar_parsed.source,
        "subtype": subtype,
        "parser": (get_type_spec(subtype).parser if get_type_spec(subtype) else ""),
    }
    ir_bundle["graph_ir"] = graph_ir.to_dict()
    ir_bundle["graph_metrics"] = compute_graph_metrics(graph_ir)
    ctx.pipeline_trace.append({"step": "grammar_parser", "source": grammar_parsed.source, "subtype": subtype})

    layout_result = compute_layout(graph_ir, subtype=subtype)
    ir_bundle["layout_result"] = layout_result.to_dict()

    dsl = graph_ir.to_dsl(
        layout_direction=layout_result.direction,
        layout_mode=layout_result.strategy,
    )
    dsl = apply_layout_to_dsl(dsl, layout_result, subtype=subtype)
    dsl.diagram_type = intent.diagram_type or dsl.diagram_type
    intent = reconcile_intent_with_dsl(intent, dsl, lock_subtype=True)
    dsl.confidence = intent.confidence
    dsl.fallback_allowed = intent.fallback_allowed
    dsl.notes.append(grammar_parsed.source)

    dsl, validation = validate_and_repair(dsl, source_text=ctx.normalized_input)
    if validation.repaired:
        quality_flags.append("dsl_repaired")

    visual = build_structured_visual_plan(dsl)
    parsed_spec = dsl_to_parsed_spec(dsl)
    for key in (
        "root", "children", "layers", "stages", "events", "blocks",
        "columns", "dimensions", "connections", "strengths", "weaknesses",
        "opportunities", "threats", "size", "window",
    ):
        if spec.get(key) is not None:
            parsed_spec[key] = spec.get(key)
    parsed_spec["diagram_subtype"] = subtype
    parsed_spec["quality_flags"] = list(dict.fromkeys(list(parsed_spec.get("quality_flags") or []) + quality_flags))
    parsed_spec["layout_result"] = layout_result.to_dict()
    parsed_spec["layout_strategy"] = layout_result.strategy
    dsl_dict = dsl.to_dict()
    critic = run_structural_critic(
        semantic_ir=ir_bundle.get("semantic_ir"),
        dsl_json=dsl_dict,
        parsed_spec=parsed_spec,
        source_text=ctx.normalized_input,
    )
    ir_bundle["structural_critic"] = critic
    if critic.get("status") == "failed":
        quality_flags.append("structural_critic_failed")
    elif critic.get("warnings"):
        quality_flags.extend(critic.get("warnings") or [])

    parsed = ParsedDiagram(parsed_spec, source=f"grammar_{grammar_parsed.source}")
    return intent, parsed, visual, dsl_dict, quality_flags, ir_bundle


def _finalize_grammar_failure(
    ctx: PipelineContext,
    intent: DiagramIntent,
    grammar_parsed: ParsedDiagram,
    quality_flags: list[str],
    ir_bundle: dict[str, Any],
) -> tuple[DiagramIntent, ParsedDiagram, VisualPlan | None, dict, list[str], dict[str, Any]]:
    """LLM grammar 未通过质量门禁：不渲染规则兜底结果。"""
    from app.services.figures.dsl.defaults import default_dsl_for_type

    subtype = canonical_subtype(intent.diagram_subtype)
    dt = subtype_to_diagram_type(subtype)
    dsl = default_dsl_for_type(dt, title=intent.title or "示意图")
    dsl.diagram_type = dt
    dsl.notes.append("grammar_llm_quality_gate_failed")
    parsed_spec = {
        "title": intent.title or "示意图",
        "diagram_subtype": subtype,
        "diagram_type": dt,
        "quality_flags": list(dict.fromkeys(quality_flags)),
        "grammar_blocked": True,
        "nodes": [],
        "edges": [],
    }
    ir_bundle["grammar_blocked"] = True
    ctx.pipeline_trace.append({"step": "grammar_blocked", "subtype": subtype, "source": grammar_parsed.source})
    parsed = ParsedDiagram(parsed_spec, source="grammar_quality_blocked")
    return intent, parsed, None, dsl.to_dict(), quality_flags, ir_bundle


def _finalize_grammar_spec_direct(
    ctx: PipelineContext,
    intent: DiagramIntent,
    grammar_parsed: ParsedDiagram,
    quality_flags: list[str],
    ir_bundle: dict[str, Any],
) -> tuple[DiagramIntent, ParsedDiagram, VisualPlan | None, dict, list[str], dict[str, Any]]:
    """SWOT / 注意力矩阵等专用 renderer 类型：保留 grammar spec，不经 Graph 扁平化。"""
    from app.services.figures.dsl.defaults import default_dsl_for_type

    spec = dict(grammar_parsed.parsed_spec or {})
    subtype = canonical_subtype(intent.diagram_subtype)
    ir_bundle["grammar_parser"] = {
        "source": grammar_parsed.source,
        "subtype": subtype,
        "parser": (get_type_spec(subtype).parser if get_type_spec(subtype) else ""),
        "graph_layout": False,
    }
    ctx.pipeline_trace.append({"step": "grammar_parser", "source": grammar_parsed.source, "subtype": subtype, "graph_layout": False})

    dt = subtype_to_diagram_type(subtype)
    dsl = default_dsl_for_type(dt, title=str(spec.get("title") or intent.title or "示意图"))
    dsl.diagram_type = dt
    dsl.confidence = intent.confidence
    dsl.fallback_allowed = intent.fallback_allowed
    dsl.notes.append(grammar_parsed.source)

    parsed_spec = dict(spec)
    parsed_spec["diagram_subtype"] = subtype
    parsed_spec["diagram_type"] = dt
    parsed_spec["quality_flags"] = list(dict.fromkeys(quality_flags))
    dsl_dict = dsl.to_dict()
    visual = build_structured_visual_plan(dsl)
    parsed = ParsedDiagram(parsed_spec, source=f"grammar_{grammar_parsed.source}")
    return intent, parsed, visual, dsl_dict, quality_flags, ir_bundle

