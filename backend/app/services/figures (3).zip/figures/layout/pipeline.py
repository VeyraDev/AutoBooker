"""Layout 五段管线：Planner → Solver → Edge Router → Label Placer → Canvas Fitter。"""

from __future__ import annotations

from app.services.figures.compiler.projector import native_ir_to_graph
from app.services.figures.graph.metrics import compute_graph_metrics
from app.services.figures.graph.schema import GraphIR
from app.services.figures.intent.taxonomy import canonical_subtype
from app.services.figures.layout.canvas_fitter import finalize_canvas, pre_route_fit
from app.services.figures.layout.edge_router import route_edges
from app.services.figures.layout.label_placer import place_labels
from app.services.figures.layout.planner import plan_layout
from app.services.figures.layout.schema import LayoutResult
from app.services.figures.layout.solver import solve_layout
from app.services.figures.native.base import NativeIR
from app.services.figures.schemas.diagram import DiagramIntent


def run_layout_pipeline(
    native: NativeIR,
    intent: DiagramIntent,
) -> tuple[LayoutResult, dict]:
    graph = native_ir_to_graph(native, intent)
    return run_layout_pipeline_on_graph(graph, subtype=canonical_subtype(intent.diagram_subtype or native.diagram_type))


def run_layout_pipeline_on_graph(
    graph: GraphIR,
    *,
    subtype: str = "",
) -> tuple[LayoutResult, dict]:
    meta: dict = {"layout_stages": []}
    meta["graph_metrics"] = compute_graph_metrics(graph)
    st = subtype or getattr(graph, "diagram_subtype", "") or graph.diagram_type or ""

    plan = plan_layout(graph, subtype=st)
    meta["layout_plan"] = plan
    meta["layout_stages"].append("planner")

    layout = solve_layout(graph, plan, subtype=st)
    meta["layout_stages"].append("solver")

    pre_route_fit(layout)
    route_edges(layout, graph.edges, direction=layout.direction, strategy=str(layout.strategy))
    meta["layout_stages"].append("edge_router")

    layout = place_labels(graph, layout)
    meta["layout_stages"].append("label_placer")

    layout = finalize_canvas(layout, subtype=st)
    meta["layout_stages"].append("canvas_fitter")

    return layout, meta
