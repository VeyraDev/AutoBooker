"""Layout Planner：选策略 + Graph 投影已完成。"""

from __future__ import annotations

from app.services.figures.graph.metrics import compute_graph_metrics
from app.services.figures.graph.schema import GraphIR
from app.services.figures.layout.selector import select_strategy


def plan_layout(graph: GraphIR, *, subtype: str = "") -> dict:
    metrics = compute_graph_metrics(graph)
    strategy = select_strategy(graph, metrics, subtype=subtype)
    return {
        "strategy": strategy,
        "metrics": metrics,
        "subtype": subtype,
        "hints": list((graph.layout_constraints or {}).get("hints") or []),
    }
