"""TaxonomyCompiler。"""

from __future__ import annotations

from app.services.figures.brief.schema import VisualBrief
from app.services.figures.compiler.base import DiagramCompiler
from app.services.figures.native.base import NativeIR
from app.services.figures.schemas.diagram import DiagramIntent


class TaxonomyCompiler(DiagramCompiler):
    def compile(self, brief: VisualBrief, intent: DiagramIntent) -> NativeIR:
        content = dict(brief.content_brief or {})
        children = content.get("children") or []
        normalized = []
        for c in children:
            if isinstance(c, dict):
                normalized.append({"label": c.get("name") or c.get("label"), "children": c.get("children") or []})
            elif isinstance(c, str):
                normalized.append({"label": c, "children": []})
        ir = {
            "type": "taxonomy",
            "root": str(content.get("root") or brief.title or "根"),
            "children": normalized,
        }
        return NativeIR(diagram_type="taxonomy", title=brief.title or intent.title or "分类", structure=ir)
