"""ComparisonCompiler — 内容 IR only。"""

from __future__ import annotations

from app.services.figures.brief.schema import VisualBrief
from app.services.figures.compiler.base import DiagramCompiler
from app.services.figures.native.base import NativeIR
from app.services.figures.schemas.diagram import DiagramIntent


class ComparisonCompiler(DiagramCompiler):
    def compile(self, brief: VisualBrief, intent: DiagramIntent) -> NativeIR:
        content = dict(brief.content_brief or {})
        ir = {
            "type": "comparison_matrix",
            "subjects": list(content.get("subjects") or []),
            "dimensions": [
                d.get("name") if isinstance(d, dict) else str(d)
                for d in (content.get("dimensions") or [])
            ],
            "cells": list(content.get("cells") or []),
            "comparison_goal": str(content.get("comparison_goal") or ""),
        }
        return NativeIR(diagram_type="comparison", title=brief.title or intent.title or "对比", structure=ir)
