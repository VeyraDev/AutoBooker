"""Relationship / Concept map Compiler。"""

from __future__ import annotations

from app.services.figures.brief.schema import VisualBrief
from app.services.figures.compiler.base import DiagramCompiler
from app.services.figures.native.base import NativeIR
from app.services.figures.schemas.diagram import DiagramIntent


class RelationshipCompiler(DiagramCompiler):
    def compile(self, brief: VisualBrief, intent: DiagramIntent) -> NativeIR:
        content = dict(brief.content_brief or {})
        concepts = [
            c.get("name") if isinstance(c, dict) else str(c)
            for c in (content.get("concepts") or [])
        ]
        ir = {
            "type": "concept",
            "center": str(content.get("center") or brief.title or ""),
            "concepts": concepts,
            "relations": list(content.get("relations") or []),
        }
        return NativeIR(diagram_type="concept", title=brief.title or intent.title or "概念图", structure=ir)
