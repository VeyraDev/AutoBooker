"""MechanismCompiler。"""

from __future__ import annotations

from app.services.figures.brief.schema import VisualBrief
from app.services.figures.compiler.base import DiagramCompiler
from app.services.figures.native.base import NativeIR
from app.services.figures.native.mechanism import empty_mechanism_ir
from app.services.figures.schemas.diagram import DiagramIntent


class MechanismCompiler(DiagramCompiler):
    def compile(self, brief: VisualBrief, intent: DiagramIntent) -> NativeIR:
        content = dict(brief.content_brief or {})
        ir = empty_mechanism_ir()
        ir["actors"] = list(content.get("actors") or [])
        ir["states"] = list(content.get("states") or [])
        ir["transfers"] = list(content.get("transfers") or [])
        ir["feedbacks"] = list(content.get("feedbacks") or [])
        ir["notations"] = list(content.get("notations") or [])
        if not ir["transfers"]:
            ir["transfers"] = _transfers_from_flow(content)
        for t in ir["transfers"]:
            if isinstance(t, dict):
                effect = str(t.get("effect") or "")
                link = {"from": t.get("from"), "to": t.get("to"), "polarity": "neutral"}
                if effect == "feedback":
                    ir["feedbacks"].append({"from": t.get("from"), "to": t.get("to"), "meaning": t.get("what")})
                if effect in {"activate", "inhibit"}:
                    link["polarity"] = "positive" if effect == "activate" else "negative"
                    ir["causal_links"].append(link)
        for fb in ir["feedbacks"]:
            if isinstance(fb, dict):
                ir["positive_feedbacks"].append(fb)
        return NativeIR(diagram_type="mechanism", title=brief.title or intent.title or "机制图", structure=ir)


def _transfers_from_flow(content: dict) -> list[dict]:
    labels: list[str] = []
    for item in content.get("main_flow") or content.get("steps") or []:
        if isinstance(item, str) and item.strip():
            labels.append(item.strip()[:16])
        elif isinstance(item, dict):
            label = str(item.get("label") or item.get("name") or "").strip()
            if label:
                labels.append(label[:16])
    transfers: list[dict] = []
    for i in range(len(labels) - 1):
        transfers.append({
            "from": labels[i],
            "to": labels[i + 1],
            "what": "",
            "effect": "transform",
        })
    return transfers
