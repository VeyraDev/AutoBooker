"""ArchitectureCompiler。"""

from __future__ import annotations

from typing import Any

from app.services.figures.brief.schema import VisualBrief
from app.services.figures.compiler.base import DiagramCompiler
from app.services.figures.native.architecture import empty_architecture_ir
from app.services.figures.native.base import NativeIR
from app.services.figures.schemas.diagram import DiagramIntent


class ArchitectureCompiler(DiagramCompiler):
    def compile(self, brief: VisualBrief, intent: DiagramIntent) -> NativeIR:
        content = dict(brief.content_brief or {})
        ir = empty_architecture_ir()
        ir["components"] = [str(c.get("name") if isinstance(c, dict) else c) for c in (content.get("components") or [])]
        ir["containers"] = list(content.get("containers") or [])
        ir["interactions"] = list(content.get("interactions") or [])
        ir["shared_resources"] = list(content.get("shared_resources") or [])
        ir["architecture_pattern"] = str(content.get("architecture_pattern") or "layered")
        ir["pipeline_stages"] = list(content.get("pipeline_stages") or [])
        if ir["architecture_pattern"] == "pipeline_architecture" and ir["pipeline_stages"]:
            ir["groups"] = [
                {"label": str(stage.get("name") or f"阶段{i+1}"), "members": list(stage.get("components") or [])}
                for i, stage in enumerate(ir["pipeline_stages"])
                if isinstance(stage, dict)
            ]
        return NativeIR(diagram_type="shared_architecture", title=brief.title or intent.title or "架构图", structure=ir)
