"""DecisionCompiler。"""

from __future__ import annotations

from app.services.figures.brief.schema import VisualBrief
from app.services.figures.compiler.base import DiagramCompiler
from app.services.figures.native.base import NativeIR
from app.services.figures.schemas.diagram import DiagramIntent


class DecisionCompiler(DiagramCompiler):
    def compile(self, brief: VisualBrief, intent: DiagramIntent) -> NativeIR:
        content = dict(brief.content_brief or {})
        ir = {
            "type": "decision_tree",
            "root": str(content.get("root_decision") or brief.title or "起点"),
            "branches": list(content.get("decisions") or []),
            "outcomes": list(content.get("outcomes") or []),
        }
        return NativeIR(diagram_type="decision_tree", title=brief.title or intent.title or "决策树", structure=ir)
