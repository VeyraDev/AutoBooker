"""TimelineCompiler。"""

from __future__ import annotations

from app.services.figures.brief.schema import VisualBrief
from app.services.figures.compiler.base import DiagramCompiler
from app.services.figures.native.base import NativeIR
from app.services.figures.schemas.diagram import DiagramIntent


class TimelineCompiler(DiagramCompiler):
    def compile(self, brief: VisualBrief, intent: DiagramIntent) -> NativeIR:
        content = dict(brief.content_brief or {})
        ir = {
            "type": "timeline",
            "milestones": list(content.get("milestones") or []),
            "time_granularity": content.get("time_granularity"),
            "sequence_type": content.get("sequence_type"),
        }
        return NativeIR(diagram_type="timeline", title=brief.title or intent.title or "时间线", structure=ir)
