"""V3 Structured Path：Visual Brief → Compiler → Layout 五段 → Design → DSL。"""

from __future__ import annotations

import logging
import time
from typing import Any

from app.services.figures.brief.schema import VisualBrief
from app.services.figures.brief.visual import extract_visual_brief, repair_visual_brief
from app.services.figures.compiler.registry import compile_brief
from app.services.figures.critic.structural import run_structural_critic
from app.services.figures.design.planner import plan_design
from app.services.figures.dsl.to_parsed_spec import dsl_to_parsed_spec
from app.services.figures.intent.reconcile import reconcile_intent_with_dsl
from app.services.figures.intent.taxonomy import canonical_subtype, subtype_to_diagram_type
from app.services.figures.layout.pipeline import run_layout_pipeline
from app.services.figures.layout.selector import apply_layout_to_dsl
from app.services.figures.plan.style_planner import apply_style_hints
from app.services.figures.plan.visual_planner import build_structured_visual_plan
from app.services.figures.schemas.diagram import DiagramIntent, ParsedDiagram, PipelineContext, VisualPlan
from app.services.figures.validate.dsl_validator import validate_and_repair

logger = logging.getLogger(__name__)


def run_structured_pipeline(
    ctx: PipelineContext,
    intent: DiagramIntent,
    understanding: dict[str, Any] | None = None,
) -> tuple[DiagramIntent, ParsedDiagram, VisualPlan | None, dict, list[str], dict[str, Any]]:
    quality_flags: list[str] = []
    ir_bundle: dict[str, Any] = {"pipeline": "v3_structured"}
    understanding = understanding or ctx.intent_understanding or {}

    t0 = time.perf_counter()
    brief = extract_visual_brief(ctx, understanding)
    ctx.pipeline_trace.append({"step": "visual_brief", "ms": int((time.perf_counter() - t0) * 1000)})
    ir_bundle["visual_brief"] = brief.to_dict()

    issues = brief.validate_minimal()
    if issues:
        repaired = repair_visual_brief(ctx, brief, issues)
        if repaired:
            brief = repaired
            quality_flags.append("brief_repaired")
            ir_bundle["visual_brief"] = brief.to_dict()

    subtype = _map_diagram_type_to_subtype(brief.diagram_type, intent)
    intent.diagram_subtype = subtype
    intent.diagram_type = subtype_to_diagram_type(subtype)
    if brief.title:
        intent.title = brief.title

    t0 = time.perf_counter()
    native = compile_brief(brief, intent)
    ir_bundle["native_ir"] = native.to_dict()
    ctx.pipeline_trace.append({"step": "compiler", "ms": int((time.perf_counter() - t0) * 1000), "type": native.native_type()})

    t0 = time.perf_counter()
    layout, layout_meta = run_layout_pipeline(native, intent)
    ir_bundle["layout_result"] = layout.to_dict()
    ir_bundle["layout_meta"] = layout_meta
    ctx.pipeline_trace.append({"step": "layout_pipeline", "ms": int((time.perf_counter() - t0) * 1000)})

    design_spec = plan_design(native, layout, brief)
    ir_bundle["design_spec"] = design_spec.to_dict()

    from app.services.figures.compiler.projector import native_ir_to_graph

    graph = native_ir_to_graph(native, intent)
    dsl = graph.to_dsl(layout_direction=layout.direction, layout_mode=layout.strategy)
    dsl = apply_layout_to_dsl(dsl, layout, subtype=subtype)
    hints = brief.visual_brief or {}
    style_hints = {
        "theme": design_spec.theme,
        "component_variant": design_spec.component_variant,
        "container_style": design_spec.container_style,
        "arrow_style": design_spec.arrow_style,
        "style_intent": hints.get("style_intent"),
    }
    dsl = apply_style_hints(dsl, style_hints, graph.style_hints)
    dsl.diagram_type = intent.diagram_type or dsl.diagram_type
    dsl.notes.append("v3_structured")
    intent = reconcile_intent_with_dsl(intent, dsl)

    dsl, validation = validate_and_repair(dsl, source_text=ctx.normalized_input)
    if validation.repaired:
        quality_flags.append("dsl_repaired")
    for issue in validation.issues:
        if issue.severity == "warning":
            quality_flags.append(issue.code)

    visual = build_structured_visual_plan(dsl)
    parsed_spec = dsl_to_parsed_spec(dsl)
    parsed_spec["diagram_subtype"] = subtype
    if native.native_type() in {"infographic", "chapter_summary"}:
        _attach_infographic_fields(parsed_spec, native, brief)
    parsed_spec["design_spec"] = design_spec.to_dict()
    parsed_spec["quality_flags"] = list(dict.fromkeys(quality_flags))
    parsed_spec["layout_result"] = layout.to_dict()
    parsed_spec["layout_strategy"] = layout.strategy
    if not parsed_spec.get("nodes"):
        quality_flags.append("compiler_minimal_graph")
        _ensure_minimal_nodes(parsed_spec, brief)

    dsl_dict = dsl.to_dict()
    critic = run_structural_critic(
        semantic_ir=ir_bundle.get("native_ir"),
        dsl_json=dsl_dict,
        parsed_spec=parsed_spec,
        source_text=ctx.normalized_input,
    )
    ir_bundle["structural_critic"] = critic
    if critic.get("warnings"):
        quality_flags.extend(critic.get("warnings") or [])

    warnings = _run_brief_critic(brief, native, quality_flags)
    ir_bundle["critic_warnings"] = warnings

    parsed = ParsedDiagram(parsed_spec, source="v3_structured")
    return intent, parsed, visual, dsl_dict, quality_flags, ir_bundle


def _map_diagram_type_to_subtype(dtype: str, intent: DiagramIntent) -> str:
    raw = canonical_subtype(dtype or intent.diagram_subtype or "process_flow")
    mapping = {
        "flow": "process_flow",
        "flowchart": "process_flow",
        "concept_map": "concept_diagram",
        "relationship_map": "concept_diagram",
        "org_chart": "taxonomy_map",
        "shared_architecture": "system_architecture",
        "architecture": "system_architecture",
        "comparison": "comparison_matrix",
        "timeline": "timeline_roadmap",
        "decision": "decision_tree",
    }
    return mapping.get(raw, raw)


def _attach_infographic_fields(parsed_spec: dict, native, brief: VisualBrief) -> None:
    blocks = list((native.structure or {}).get("blocks") or [])
    if blocks:
        parsed_spec["blocks"] = blocks
    parsed_spec["diagram_subtype"] = "infographic"
    parsed_spec["structure_summary"] = parsed_spec.get("structure_summary") or f"{len(blocks)} 个信息块"
    if not parsed_spec.get("nodes") and blocks:
        _ensure_infographic_graph(parsed_spec, brief.title or native.title, blocks)


def _ensure_infographic_graph(parsed_spec: dict, title: str, blocks: list[dict]) -> None:
    nodes = [{"id": "summary", "label": (title or "信息图")[:16], "shape": "rounded"}]
    edges: list[dict] = []
    for i, block in enumerate(blocks):
        if not isinstance(block, dict):
            continue
        bid = f"b{i}"
        nodes.append({"id": bid, "label": str(block.get("label") or f"块{i + 1}")[:16], "shape": "box"})
        edges.append({"from": "summary", "to": bid, "label": ""})
        for j, item in enumerate(block.get("items") or []):
            iid = f"b{i}_{j}"
            nodes.append({"id": iid, "label": str(item)[:16], "shape": "tag"})
            edges.append({"from": bid, "to": iid, "label": ""})
    parsed_spec["nodes"] = nodes
    parsed_spec["edges"] = edges


def _ensure_minimal_nodes(parsed_spec: dict, brief: VisualBrief) -> None:
    title = brief.title or "步骤"
    parsed_spec["nodes"] = [
        {"id": "n0", "label": title[:16], "shape": "rounded"},
        {"id": "n1", "label": "完成", "shape": "rounded"},
    ]
    parsed_spec["edges"] = [{"from": "n0", "to": "n1", "label": ""}]


def _run_brief_critic(brief: VisualBrief, native, quality_flags: list[str]) -> list[str]:
    warnings = list(quality_flags)
    if not brief.content_brief:
        warnings.append("brief_sparse_content")
    if native and not native.structure:
        warnings.append("native_ir_empty")
    return warnings
