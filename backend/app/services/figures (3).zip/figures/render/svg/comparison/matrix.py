"""Comparison matrix 模板 SVG。"""

from __future__ import annotations

from typing import Any

from app.services.figures.design.render_context import RenderContext
from app.services.figures.design.typography import estimate_text_width
from app.services.figures.render.svg.primitives import rect
from app.services.figures.render.svg.text import multiline_text


def render_comparison_matrix(
    spec: dict[str, Any],
    ctx: RenderContext,
    *,
    title: str = "",
) -> list[str]:
    tokens = ctx.tokens
    subjects = list(spec.get("columns") or spec.get("subjects") or [])
    dimensions = list(spec.get("dimensions") or [])
    cells = spec.get("cells") or []

    if not subjects:
        subjects = [str(n.get("label") or n.get("id")) for n in (spec.get("nodes") or [])[:4] if isinstance(n, dict)]
    if not dimensions:
        dimensions = ["维度1", "维度2", "维度3"]

    col_w = 140.0
    row_h = 44.0
    header_h = 48.0
    label_w = 120.0
    pad = 48.0
    w = pad * 2 + label_w + col_w * max(1, len(subjects))
    h = pad * 2 + header_h + row_h * max(1, len(dimensions)) + (32 if title else 0)

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{w:.0f}" height="{h:.0f}" viewBox="0 0 {w:.0f} {h:.0f}">',
        f'<rect width="100%" height="100%" fill="{tokens.background}"/>',
    ]
    if title:
        parts.append(multiline_text(w / 2, pad - 8, title, fill=tokens.text, max_width=w - 80, font_size=16, max_lines=2))

    ox, oy = pad + label_w, pad + (32 if title else 0)
    for j, subj in enumerate(subjects):
        cx = ox + j * col_w + col_w / 2
        parts.append(rect(ox + j * col_w, oy, col_w - 4, header_h, fill=tokens.primary, stroke=tokens.border, rx=6))
        parts.append(multiline_text(cx, oy + header_h / 2, str(subj), fill="#FFFFFF", max_width=col_w - 12, font_size=12, max_lines=2))

    cell_map: dict[tuple[str, str], str] = {}
    for cell in cells:
        if not isinstance(cell, dict):
            continue
        subj = str(cell.get("subject") or cell.get("column") or "")
        dim = str(cell.get("dimension") or cell.get("row") or "")
        val = str(cell.get("value") or cell.get("text") or "—")
        if subj and dim:
            cell_map[(dim, subj)] = val

    for i, dim in enumerate(dimensions):
        y = oy + header_h + i * row_h
        parts.append(rect(pad, y, label_w - 8, row_h - 4, fill=tokens.card, stroke=tokens.border, rx=4))
        parts.append(multiline_text(pad + label_w / 2 - 4, y + row_h / 2 - 2, str(dim), fill=tokens.text, max_width=label_w - 16, font_size=11, max_lines=2))
        for j, subj in enumerate(subjects):
            val = cell_map.get((str(dim), str(subj)), "—")
            cx = ox + j * col_w + col_w / 2
            parts.append(rect(ox + j * col_w, y, col_w - 4, row_h - 4, fill=tokens.card, stroke=tokens.border, rx=4))
            parts.append(multiline_text(cx, y + row_h / 2 - 2, val, fill=tokens.muted, max_width=col_w - 12, font_size=11, max_lines=2))

    parts.append("</svg>")
    return parts
