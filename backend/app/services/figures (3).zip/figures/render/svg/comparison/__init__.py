"""Comparison 四模板分派。"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from app.services.figures.design.render_context import RenderContext, build_render_context
from app.services.figures.render.svg.comparison.cards import render_comparison_cards
from app.services.figures.render.svg.comparison.matrix import render_comparison_matrix
from app.services.figures.render.svg.comparison.pros_cons import render_comparison_pros_cons
from app.services.figures.render.svg.comparison.scoreboard import render_comparison_scoreboard
from app.services.figures.render.svg.export_png import export_png_from_svg


def render_comparison_svg(
    spec: dict[str, Any],
    out_path: Path,
    *,
    title: str = "",
    design_spec: dict[str, Any] | None = None,
) -> tuple[str, Path]:
    ctx = build_render_context(design_spec or spec.get("design_spec"))
    template = ctx.comparison_template or "matrix"
    renderers = {
        "matrix": render_comparison_matrix,
        "cards": render_comparison_cards,
        "pros_cons": render_comparison_pros_cons,
        "scoreboard": render_comparison_scoreboard,
    }
    fn = renderers.get(template, render_comparison_matrix)
    parts = fn(spec, ctx, title=title or str(spec.get("title") or ""))
    svg_content = "\n".join(parts)
    svg_path = out_path.with_suffix(".svg")
    png_path = out_path.with_suffix(".png")
    svg_path.parent.mkdir(parents=True, exist_ok=True)
    svg_path.write_text(svg_content, encoding="utf-8")
    export_png_from_svg(svg_path, png_path)
    return "image/svg+xml", svg_path if svg_path.is_file() else png_path
