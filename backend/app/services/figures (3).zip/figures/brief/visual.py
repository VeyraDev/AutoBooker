"""Visual Brief LLM 抽取。"""

from __future__ import annotations

import json
import logging
from typing import Any

from app.config import settings
from app.llm.client import LLMClient
from app.services.figures.brief.context import build_context, format_intent_result
from app.services.figures.brief.schema import VisualBrief
from app.services.figures.prompts import format_prompt
from app.services.figures.schemas.diagram import PipelineContext
from app.utils.json_llm import parse_llm_json

logger = logging.getLogger(__name__)


def extract_visual_brief(
    ctx: PipelineContext,
    understanding: dict[str, Any],
) -> VisualBrief:
    model = (ctx.model or settings.intent_model).strip()
    if ctx.use_llm and model and ctx.normalized_input.strip():
        data = _call_visual_brief_llm(ctx, understanding, model)
        if data:
            return VisualBrief.from_dict(data)
    return _minimal_brief(ctx, understanding)


def repair_visual_brief(
    ctx: PipelineContext,
    brief: VisualBrief,
    errors: list[str],
) -> VisualBrief | None:
    model = (ctx.model or settings.intent_model).strip()
    if not ctx.use_llm or not model or not errors:
        return None
    try:
        prompt = format_prompt(
            "brief_repair",
            text=ctx.normalized_input[:3500],
            broken_brief=json.dumps(brief.to_dict(), ensure_ascii=False)[:6000],
            errors="\n".join(errors[:12]),
        )
    except OSError:
        return None
    try:
        out = LLMClient().chat_completion(
            [{"role": "system", "content": "只输出合法 JSON。"}, {"role": "user", "content": prompt}],
            model=model,
            max_tokens=2400,
            temperature=0.0,
        )
        data = parse_llm_json(out)
    except Exception as e:
        logger.warning("brief repair failed: %s", e)
        return None
    return VisualBrief.from_dict(data) if isinstance(data, dict) else None


def _call_visual_brief_llm(
    ctx: PipelineContext,
    understanding: dict[str, Any],
    model: str,
) -> dict[str, Any] | None:
    try:
        prompt = format_prompt(
            "visual_brief",
            text=ctx.normalized_input[:3500],
            intent_result=format_intent_result(understanding),
            context=build_context(ctx),
        )
    except OSError:
        return None
    try:
        out = LLMClient().chat_completion(
            [{"role": "system", "content": "只输出合法 JSON。"}, {"role": "user", "content": prompt}],
            model=model,
            max_tokens=2800,
            temperature=0.0,
        )
        data = parse_llm_json(out)
    except Exception as e:
        logger.warning("visual brief LLM failed: %s", e)
        return None
    return data if isinstance(data, dict) else None


def _minimal_brief(ctx: PipelineContext, understanding: dict[str, Any]) -> VisualBrief:
    from app.services.figures.intent.taxonomy import canonical_subtype

    candidates = understanding.get("diagram_candidates") or understanding.get("candidate_diagrams") or []
    dtype = ""
    inferred = _infer_diagram_type_from_text(ctx.normalized_input)
    if ctx.subtype_hint:
        dtype = canonical_subtype(ctx.subtype_hint)
    elif inferred != "process_flow":
        dtype = inferred
    elif candidates and isinstance(candidates[0], dict):
        dtype = str(candidates[0].get("type") or "")
    if not dtype:
        dtype = inferred or "process_flow"
    title = str(understanding.get("title") or ctx.normalized_input[:24] or "示意图")
    content = _minimal_content_brief(dtype, ctx.normalized_input, title)
    return VisualBrief(
        diagram_type=dtype or "process_flow",
        title=title,
        content_brief=content,
        visual_brief={"density": "medium", "reading_order": "top_to_bottom", "style_intent": "modern_saas"},
    )


def _infer_diagram_type_from_text(text: str) -> str:
    t = (text or "").lower()
    if any(k in t for k in ("泳道", "swimlane", "lane")):
        return "swimlane"
    if any(k in t for k in ("对比", "比较", "vs", "优劣")):
        return "comparison_matrix"
    if any(k in t for k in ("架构", "微服务", "rag", "部署")):
        return "system_architecture"
    if any(k in t for k in ("时间线", "里程碑", "roadmap")):
        return "timeline_roadmap"
    if any(k in t for k in ("信息图", "信息块", "章节总结", "核心要点", "图标化")):
        return "infographic"
    if any(k in t for k in ("分类", "思维导图", "taxonomy", "层级")):
        return "taxonomy_map"
    if any(k in t for k in ("机制", "原理", "注意力", "transformer")):
        return "mechanism_diagram"
    return "process_flow"


def _minimal_content_brief(dtype: str, text: str, title: str) -> dict[str, Any]:
    import re

    from app.services.figures.intent.taxonomy import canonical_subtype as _canon

    st = _canon(dtype)
    steps = [
        {"label": p.strip()[:16]}
        for p in re.split(r"→|->|、|，|,|；|;", text)
        if p.strip() and len(p.strip()) <= 20
    ][:12]
    if st == "swimlane":
        lanes = re.findall(r"(\w+)\s*lane", text, flags=re.I)
        if not lanes:
            lanes = ["用户", "系统", "后台"]
        return {
            "lanes": [{"label": lane, "items": steps[i::max(1, len(lanes))]} for i, lane in enumerate(lanes)],
            "main_flow": steps,
        }
    if st in {"comparison_matrix", "comparison"}:
        subjects = re.findall(r"[\u4e00-\u9fffA-Za-z0-9+]+", text)
        dims = re.findall(r"(吞吐|延迟|显存|成本|速度|复杂度|效果)", text)
        return {
            "subjects": subjects[:6] or ["方案A", "方案B"],
            "dimensions": [{"name": d} for d in dims] or [{"name": "维度1"}, {"name": "维度2"}],
            "comparison_goal": "compare",
        }
    if st in {"infographic", "chapter_summary"}:
        labels = [s["label"] for s in steps]
        if not labels:
            labels = _split_infographic_labels(text)
        return {"blocks": [{"label": lb, "items": []} for lb in labels[:6]] or [{"label": "要点", "items": []}]}
    if st in {"system_architecture", "shared_architecture"}:
        modules = [s["label"] for s in steps] or [title[:12]]
        return {"components": modules, "interactions": []}
    if steps:
        return {"main_flow": steps}
    return {"main_flow": [{"label": title[:16]}]}


def _split_infographic_labels(text: str) -> list[str]:
    import re

    cleaned = re.sub(r"[\"“”]", "", text or "")
    m = re.search(r"(?:展示|包含|包括|核心要点|关键概念)[:：]\s*([^。；;]+)", cleaned)
    raw = m.group(1) if m else cleaned
    raw = re.split(r"(?:，|,|；|;)?\s*(?:用|以|通过)?(?:图标|卡片|分栏|展示|呈现|白底|配色)", raw, 1)[0]
    parts = re.split(r"[、,，/]|和|与", raw)
    out: list[str] = []
    for part in parts:
        label = re.sub(r"\s+", " ", part.strip())[:18]
        if label and label not in out:
            out.append(label)
    return out[:6]
