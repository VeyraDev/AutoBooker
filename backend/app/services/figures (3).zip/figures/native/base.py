"""Native IR 容器。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class NativeIR:
    diagram_type: str
    title: str
    structure: dict[str, Any] = field(default_factory=dict)

    def native_type(self) -> str:
        return str(self.structure.get("type") or self.diagram_type or "")

    def to_dict(self) -> dict[str, Any]:
        return {
            "diagram_type": self.diagram_type,
            "title": self.title,
            "native_structure": self.structure,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NativeIR:
        structure = dict(data.get("native_structure") or data.get("structure") or data)
        dtype = str(data.get("diagram_type") or structure.get("type") or "flow")
        title = str(data.get("title") or structure.get("title") or "示意图")
        if "type" not in structure:
            structure["type"] = dtype
        return cls(diagram_type=dtype, title=title, structure=structure)
