"""Compile natural-language figure requests into DiagramSpec."""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from app.config import settings
from app.llm.client import LLMClient
from app.services.figures.render.html_template.schema import (
    STYLE_PROFILE,
    TEMPLATE_IDS,
    limits_as_json,
)
from app.services.figures.intent.taxonomy import canonical_subtype

logger = logging.getLogger(__name__)

LLM_SPEC_SYSTEM_PROMPT = f"""你是 DiagramSpec Compiler。
你的任务是把用户的中文/中英文图示需求转换为可渲染的 DiagramSpec JSON。

核心规则：
1. 只输出 JSON，不要输出 Markdown、解释或代码块。
2. template_id 必须来自模板枚举，不能自创模板。
3. 用户显式布局要求优先；没有显式要求时，根据内容结构、节点数量、文字密度选择模板。
4. 你不输出坐标，不输出 CSS，不输出 SVG。
5. 控制文字密度：标题短，bullet 每条不超过 26 个中文字符；每个模块 2-3 条 bullet。
6. 内容过载时不要硬塞：选择 grouped_infographic，或输出 needs_clarification。
7. 不要添加与主题无关的“开始/结束/反馈”等模板语义。

模板枚举与容量：
{json.dumps(limits_as_json(), ensure_ascii=False, indent=2)}

通用字段：
chart_type, template_id, title, subtitle, language, style_profile, note。

可用 template_id：
{", ".join(TEMPLATE_IDS)}

需要追问时输出：
{{"needs_clarification": true, "questions": ["问题1", "问题2"], "reason": "为什么不能直接画"}}
"""

_PUNCT_RE = re.compile(r"[。.!！?？]\s*")


def compile_diagram_spec(
    user_prompt: str,
    *,
    subtype: str = "",
    model: str = "",
    use_llm: bool = True,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Return ``(DiagramSpec, diagnostics)``.

    The LLM compiler is preferred when available. A heuristic compiler is kept as
    a deterministic fallback so the rendering path remains usable in tests and
    in offline/dev setups.
    """
    st = canonical_subtype(subtype)
    text = str(user_prompt or "").strip()
    if use_llm and text:
        llm_model = (model or settings.intent_model).strip()
        if llm_model and llm_model.lower() != "dummy":
            spec = _compile_with_llm(text, st, llm_model)
            if spec:
                return spec, {"source": "llm", "compiler_fallback": False}
    return compile_prompt_heuristic(text, subtype=st), {"source": "heuristic", "compiler_fallback": True}


def _compile_with_llm(user_prompt: str, subtype: str, model: str) -> dict[str, Any] | None:
    prompt = f"""主图类：{subtype or "未指定"}

用户需求：
{user_prompt[:4000]}

请输出 DiagramSpec JSON。"""
    try:
        raw = LLMClient().chat_completion(
            [{"role": "system", "content": LLM_SPEC_SYSTEM_PROMPT}, {"role": "user", "content": prompt}],
            model=model,
            max_tokens=2400,
            temperature=0.0,
        )
        return _parse_json_object(raw)
    except Exception as exc:
        logger.warning("DiagramSpec compiler LLM failed: %s", exc)
        return None


def _parse_json_object(raw: str) -> dict[str, Any] | None:
    text = (raw or "").strip()
    if not text:
        return None
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text).strip()
        text = re.sub(r"```$", "", text).strip()
    match = re.search(r"\{.*\}", text, flags=re.S)
    if match:
        text = match.group(0)
    try:
        data = json.loads(text)
    except Exception:
        return None
    return data if isinstance(data, dict) else None


def compile_prompt_heuristic(prompt: str, *, subtype: str = "") -> dict[str, Any]:
    text = prompt.strip()
    if not _has_enough_structure(text):
        return {
            "needs_clarification": True,
            "questions": [
                "请选择图类：流程、架构、对比、时间线、决策树、分类、概念关系或信息图。",
                "请给出 3-8 个模块、阶段、维度、类别或明确它们之间的关系。",
            ],
            "reason": "输入缺少可排版结构。",
        }

    st = canonical_subtype(subtype)
    if st == "timeline_roadmap" or _contains_any(text, ["时间线", "演进", "路线图", "年份"]) or re.search(r"\b(19|20)\d{2}\b", text):
        return _compile_timeline(text)
    if st == "comparison_matrix" or _contains_any(text, ["对比", "比较", "维度", "vs", "VS"]):
        return _compile_comparison(text)
    if st == "decision_tree" or _contains_any(text, ["决策树", "主要需求", "分支", "选择"]):
        return _compile_decision(text)
    if st == "taxonomy_map" or _contains_any(text, ["分类", "根节点", "一级分为", "分为", "下有"]):
        return _compile_taxonomy(text)
    if st == "system_architecture" or _contains_any(text, ["架构", "前端", "后端", "数据库", "服务", "RAG", "向量数据库", "网关", "消息队列"]):
        return _compile_architecture(text)
    if st == "mechanism_diagram" or _contains_any(text, ["机制", "原理", "矩阵", "向量", "Softmax", "注意力", "公式"]):
        return _compile_mechanism(text)
    if st == "concept_diagram" or _contains_any(text, ["关系", "关联", "影响", "依赖", "映射", "组成"]):
        return _compile_concept(text)
    if st == "process_flow" or _contains_any(text, ["流程", "pipeline", "阶段", "步骤", "依次", "经过", "箭头"]):
        return _compile_flow(text)
    return _compile_infographic(text)


def _has_enough_structure(text: str) -> bool:
    if len(text) < 8:
        return False
    return _contains_any(
        text,
        [
            "包含",
            "分为",
            "下有",
            "对比",
            "流程",
            "架构",
            "时间线",
            "决策",
            "步骤",
            "阶段",
            "→",
            "->",
            "、",
        ],
    )


def _contains_any(text: str, words: list[str]) -> bool:
    lower = text.lower()
    return any(w.lower() in lower for w in words)


def _between(text: str, start: str, end_pattern: str = r"[。.]|，每|，用|，箭头|，从|$") -> str:
    idx = text.find(start)
    if idx < 0:
        return ""
    sub = text[idx + len(start) :]
    match = re.search(end_pattern, sub)
    return sub[: match.start()].strip() if match else sub.strip()


def _split_list(value: str) -> list[str]:
    text = str(value or "")
    text = text.replace("→", "、").replace("->", "、").replace("=>", "、")
    text = re.sub(r"[，,；;]", "、", text)
    out: list[str] = []
    for item in text.split("、"):
        clean = item.strip().strip("：:。.")
        clean = re.sub(r"^(和|以及|并|最后|最终|先|再|然后)", "", clean).strip()
        clean = re.sub(r"(共\d+个步骤|每个步骤.*|用方框表示|箭头连接)$", "", clean).strip()
        if clean:
            out.append(clean)
    return list(dict.fromkeys(out))


def _title_from_prompt(text: str, fallback: str) -> str:
    head = _PUNCT_RE.split(text, maxsplit=1)[0]
    head = re.split(r"[，,；;：:]", head, maxsplit=1)[0].strip()
    head = re.sub(r"^(请|生成|绘制|画一张|一张)", "", head).strip(" ：:，,。")
    return head[:32] if head else fallback


def _bullets_for(name: str, count: int = 3) -> list[str]:
    table = {
        "数据准备": ["收集训练数据", "清洗与去重", "标注与格式化"],
        "模型选择": ["选择基础模型", "确认参数规模", "匹配任务场景"],
        "训练": ["加载训练样本", "更新模型参数", "保存检查点"],
        "评估指标": ["检查准确率", "观察损失变化", "决定是否迭代"],
        "填写表单": ["输入账号信息", "提交注册表单"],
        "邮件验证": ["接收验证邮件", "确认邮箱地址"],
        "完善资料": ["补充个人信息", "设置基础资料"],
        "完成注册": ["创建账号", "进入可用状态"],
        "用户提问": ["接收自然语言问题"],
        "问题向量化": ["转换为向量表示"],
        "向量数据库检索": ["召回相似片段"],
        "召回文档片段": ["得到候选上下文"],
        "拼接上下文": ["组合问题和片段"],
        "LLM生成回答": ["生成最终回答"],
        "返回用户": ["输出回答结果"],
    }
    return table.get(name, ["明确输入与目标", "完成核心处理", "输出阶段结果"])[:count]


def _stage(title: str, i: int, total: int) -> dict[str, Any]:
    return {
        "title": title,
        "icon": "step",
        "bullets": _bullets_for(title, 3),
        "io": [f"输入：{'原始信息' if i == 0 else '上一步结果'}", f"输出：{'最终结果' if i == total - 1 else '阶段产物'}"],
        "connector": "进入\n下一步" if i < total - 1 else "",
    }


def _extract_flow_items(text: str) -> list[str]:
    if "→" in text or "->" in text:
        tail = re.split(r"[：:]", text, maxsplit=1)[-1]
        return _split_list(tail)

    match = re.search(r"从(.+?)开始[，,]?\s*经过(.+?)[，,]?\s*最终(.+?)(?:[，,。.]|$)", text)
    if match:
        first = match.group(1).strip()
        middle = _split_list(match.group(2))
        last = match.group(3).strip()
        return [first, *middle, last]

    list_text = _between(text, "依次为") or _between(text, "步骤依次为") or _between(text, "包含") or _between(text, "包括")
    items = _split_list(list_text)
    if len(items) >= 2:
        return items

    known = [
        "数据准备",
        "模型选择",
        "训练",
        "评估指标",
        "用户提问",
        "问题向量化",
        "向量数据库检索",
        "召回文档片段",
        "拼接上下文",
        "LLM生成回答",
        "返回用户",
        "填写表单",
        "邮件验证",
        "完善资料",
        "完成注册",
    ]
    found = [item for item in known if item in text]
    return found


def _compile_flow(text: str) -> dict[str, Any]:
    items = _extract_flow_items(text)
    if len(items) < 2:
        items = ["输入", "处理", "输出"]
    title = _title_from_prompt(text, "流程示意图")
    template_id = "horizontal_stage_cards" if len(items) <= 4 else "snake_cards"
    stages = [_stage(name, i, len(items)) for i, name in enumerate(items)]
    if template_id == "horizontal_stage_cards":
        note = ""
        if _contains_any(text, ["并行", "汇合", "返回", "不达标"]):
            note = "包含并行、汇合或反馈关系时，主路径保持清楚，反馈线弱化显示。"
        return {
            "chart_type": "process_flow",
            "template_id": template_id,
            "title": title,
            "subtitle": "按步骤顺序阅读",
            "language": "zh-CN",
            "style_profile": STYLE_PROFILE,
            "stages": stages,
            "note": note,
        }
    return {
        "chart_type": "process_flow",
        "template_id": template_id,
        "title": title,
        "subtitle": "两行蛇形流程，避免长流程横向裁切",
        "language": "zh-CN",
        "style_profile": STYLE_PROFILE,
        "steps": [{"title": s["title"], "icon": s["icon"], "items": s["bullets"]} for s in stages],
    }


def _compile_architecture(text: str) -> dict[str, Any]:
    if "RAG" in text.upper() and _contains_any(text, ["文档预处理", "查询模块", "向量数据库"]):
        return {
            "chart_type": "system_architecture",
            "template_id": "rag_three_column",
            "title": _title_from_prompt(text, "RAG 系统完整架构"),
            "language": "zh-CN",
            "style_profile": STYLE_PROFILE,
            "left": {
                "title": "文档预处理模块",
                "subtitle": "知识入库",
                "modules": [
                    {"title": "解析", "desc": "文本提取"},
                    {"title": "分块", "desc": "切分片段"},
                    {"title": "嵌入", "desc": "向量化"},
                ],
            },
            "center": {"title": "向量数据库", "desc": "向量索引 / 片段存储"},
            "right": {
                "title": "查询模块",
                "subtitle": "在线问答",
                "modules": [
                    {"title": "向量检索", "desc": "召回相关片段"},
                    {"title": "重排序", "desc": "筛选高相关内容"},
                    {"title": "LLM生成", "desc": "结合上下文生成回答"},
                ],
            },
            "note": "共享基础设施供两侧使用。",
        }
    if _contains_any(text, ["React", "FastAPI", "PostgreSQL"]):
        return {
            "chart_type": "system_architecture",
            "template_id": "vertical_layers",
            "title": "Web应用三层架构图",
            "language": "zh-CN",
            "style_profile": STYLE_PROFILE,
            "layers": [
                {"label": "前端层", "title": "React应用", "desc": "负责用户界面展示与交互，发送 HTTP 请求。"},
                {"label": "后端服务层", "title": "FastAPI后端服务", "desc": "处理业务逻辑，提供 API 接口。"},
                {"label": "数据层", "title": "PostgreSQL数据库", "desc": "存储和管理应用数据，响应 SQL 查询。"},
            ],
            "connections": ["HTTP请求", "SQL查询"],
        }
    if _contains_any(text, ["API网关", "消息队列", "用户服务", "订单服务", "支付服务"]):
        return {
            "chart_type": "system_architecture",
            "template_id": "vertical_layers",
            "title": "微服务架构图",
            "language": "zh-CN",
            "style_profile": STYLE_PROFILE,
            "layers": [
                {"label": "接入层", "title": "API网关", "desc": "统一入口，连接用户服务、订单服务和支付服务。"},
                {"label": "业务服务层", "title": "用户服务 / 订单服务 / 支付服务", "desc": "按业务领域拆分，订单服务产生异步通知。"},
                {"label": "异步通信层", "title": "消息队列", "desc": "承接订单服务消息，异步通知支付服务。"},
            ],
            "connections": ["同步调用", "异步通知"],
        }
    return {
        "chart_type": "system_architecture",
        "template_id": "vertical_layers",
        "title": _title_from_prompt(text, "系统架构图"),
        "language": "zh-CN",
        "style_profile": STYLE_PROFILE,
        "layers": [
            {"label": "接入层", "title": "入口模块", "desc": "接收外部请求并转发。"},
            {"label": "服务层", "title": "核心服务", "desc": "处理业务逻辑并协调子模块。"},
            {"label": "数据层", "title": "数据存储", "desc": "存储业务数据和中间结果。"},
        ],
    }


def _compile_comparison(text: str) -> dict[str, Any]:
    columns = ["方案 A", "方案 B"]
    vs_match = re.search(r"(.+?)\s+(?:vs|VS|对比|比较)\s+(.+?)(?:[，,。.]|$)", text)
    if "LoRA" in text:
        columns = ["LoRA 微调", "全量微调"]
    elif vs_match:
        columns = [vs_match.group(1).strip()[-16:], vs_match.group(2).strip()[:16]]
    dims = _split_list(_between(text, "维度包括") or _between(text, "对比维度包括"))
    if len(dims) < 2:
        dims = ["资源消耗", "训练速度", "效果上限", "适用场景"]
    return {
        "chart_type": "comparison",
        "template_id": "comparison_matrix",
        "title": _title_from_prompt(text, f"{columns[0]}与{columns[1]}对比"),
        "language": "zh-CN",
        "style_profile": STYLE_PROFILE,
        "columns": columns[:2],
        "dimensions": [
            {
                "title": dim,
                "desc": _dimension_desc(dim),
                "left": {"tag": "优势" if i != 2 else "中等", "score": 4 if i != 2 else 3, "bullets": _comparison_bullets(columns[0], dim)},
                "right": {"tag": "限制" if i != 2 else "优势", "score": 2 if i != 2 else 5, "bullets": _comparison_bullets(columns[1], dim)},
            }
            for i, dim in enumerate(dims[:4])
        ],
    }


def _dimension_desc(dim: str) -> str:
    if "显存" in dim or "资源" in dim:
        return "训练或运行所需资源"
    if "速度" in dim:
        return "完成处理所需时间"
    if "效果" in dim:
        return "最终效果与能力上限"
    if "场景" in dim:
        return "更适合的使用环境"
    return "关键评价维度"


def _comparison_bullets(subject: str, dim: str) -> list[str]:
    if "LoRA" in subject:
        table = {
            "资源消耗": ["只训练少量参数", "显存占用较低"],
            "显存需求": ["只训练少量参数", "显存占用较低"],
            "训练速度": ["迭代速度较快", "实验成本较低"],
            "效果上限": ["受低秩适配限制", "常规任务表现稳定"],
            "适用场景": ["资源受限", "快速试验"],
        }
    else:
        table = {
            "资源消耗": ["训练全部参数", "硬件成本较高"],
            "显存需求": ["训练全部参数", "显存占用较高"],
            "训练速度": ["计算量较大", "训练周期较长"],
            "效果上限": ["可更新全部参数", "效果上限更高"],
            "适用场景": ["追求最佳性能", "数据和资源充足"],
        }
    return table.get(dim, ["差异明显", "需结合场景判断"])


def _compile_decision(text: str) -> dict[str, Any]:
    matches = re.findall(r"([^，。；;：:]+?)→选择\s*([A-Za-z0-9\-_\u4e00-\u9fa5]+)", text)
    branches = [{"condition": c.strip(), "choice": v.strip()} for c, v in matches]
    if len(branches) < 2:
        branches = [
            {"condition": "最大化推理性能", "choice": "vLLM"},
            {"condition": "构建复杂工作流", "choice": "LangChain"},
            {"condition": "快速开发应用", "choice": "Hermes"},
        ]
    return {
        "chart_type": "decision_tree",
        "template_id": "decision_cards",
        "title": _title_from_prompt(text, "决策树图"),
        "language": "zh-CN",
        "style_profile": STYLE_PROFILE,
        "root": {"title": "你的主要需求是什么？"},
        "branches": [
            {"condition": b["condition"], "title": "选择 " + b["choice"], "bullets": _bullets_for(b["choice"], 3)}
            for b in branches[:3]
        ],
    }


def _compile_timeline(text: str) -> dict[str, Any]:
    pairs = [{"year": y, "title": title.strip()} for y, title in re.findall(r"((?:19|20)\d{2})年?([^，。；;\n]+)", text)]
    if len(pairs) < 3:
        pairs = [
            {"year": "2017", "title": "Attention Is All You Need"},
            {"year": "2018", "title": "BERT"},
            {"year": "2020", "title": "GPT-3"},
            {"year": "2022", "title": "ChatGPT"},
            {"year": "2023", "title": "GPT-4"},
            {"year": "2024", "title": "多模态大模型普及"},
        ]
    return {
        "chart_type": "timeline",
        "template_id": "horizontal_timeline",
        "title": _title_from_prompt(text, "技术演进时间线"),
        "language": "zh-CN",
        "style_profile": STYLE_PROFILE,
        "events": [{"year": p["year"], "title": p["title"], "bullets": _timeline_bullets(p["title"])} for p in pairs[:7]],
    }


def _timeline_bullets(title: str) -> list[str]:
    if "Attention" in title:
        return ["提出 Transformer 架构", "完全基于注意力机制", "奠定后续大模型基础"]
    if "BERT" in title:
        return ["基于 Transformer 编码器", "双向预训练语言模型", "开启预训练模型时代"]
    if "GPT-3" in title:
        return ["自回归语言模型", "参数规模提升", "展现通用生成能力"]
    if "ChatGPT" in title:
        return ["对话式交互普及", "指令微调与人类反馈", "用户应用快速扩散"]
    if "GPT-4" in title:
        return ["更强推理能力", "支持更长上下文", "多模态能力提升"]
    return ["能力持续演进", "应用场景扩展", "推动生态发展"]


def _compile_taxonomy(text: str) -> dict[str, Any]:
    if "大语言模型" in text:
        root = "大语言模型"
        groups = [
            {"title": "开源模型", "items": ["LLaMA", "Mistral", "Qwen"]},
            {"title": "闭源模型", "items": ["GPT-4", "Claude", "Gemini"]},
        ]
    elif "AI技术栈" in text or "AI 技术栈" in text:
        root = "AI技术栈分类"
        groups = [
            {"title": "感知", "items": ["图像识别", "语音识别"]},
            {"title": "认知", "items": ["自然语言处理", "知识推理"]},
            {"title": "行动", "items": ["机器人控制", "决策优化"]},
        ]
    else:
        root_match = re.search(r"根节点为[“\"']?([^”\"'，,。]+)", text)
        root = root_match.group(1).strip() if root_match else _title_from_prompt(text, "分类图")
        items = _split_list(_between(text, "分为") or _between(text, "一级分为"))
        groups = [{"title": item, "items": []} for item in items[:4]] if items else []
    return {
        "chart_type": "taxonomy",
        "template_id": "taxonomy_tree",
        "title": _title_from_prompt(text, root),
        "language": "zh-CN",
        "style_profile": STYLE_PROFILE,
        "root": root,
        "groups": groups or [{"title": "类别 A", "items": ["成员 1"]}, {"title": "类别 B", "items": ["成员 2"]}],
    }


def _compile_concept(text: str) -> dict[str, Any]:
    items = _split_list(_between(text, "包含") or _between(text, "包括") or _between(text, "关系"))
    if len(items) < 3:
        items = ["核心概念", "影响因素", "依赖条件", "结果表现"]
    return {
        "chart_type": "concept",
        "template_id": "hub_spoke_concept",
        "title": _title_from_prompt(text, "概念关系图"),
        "language": "zh-CN",
        "style_profile": STYLE_PROFILE,
        "center": {"title": _title_from_prompt(text, "核心概念"), "desc": "核心组织对象"},
        "items": [{"title": item, "desc": "与中心概念相关"} for item in items[:8]],
    }


def _compile_mechanism(text: str) -> dict[str, Any]:
    terms = [x for x in ["输入", "Q", "K", "V", "Softmax", "注意力权重", "输出", "矩阵", "向量"] if x in text]
    if len(terms) < 3:
        terms = _split_list(_between(text, "包含") or text)[:5]
    if len(terms) < 3:
        terms = ["输入", "内部计算", "输出"]
    return {
        "chart_type": "mechanism",
        "template_id": "mechanism_mapping",
        "title": _title_from_prompt(text, "机制原理图"),
        "language": "zh-CN",
        "style_profile": STYLE_PROFILE,
        "sections": [{"title": term, "desc": "保留原始术语并说明作用位置"} for term in terms[:6]],
        "formula": "按用户原文保留公式或变量关系" if _contains_any(text, ["=", "Softmax", "矩阵", "向量"]) else "",
    }


def _compile_infographic(text: str) -> dict[str, Any]:
    items = _split_list(_between(text, "包含") or _between(text, "要点") or _between(text, "包括"))
    if len(items) < 3:
        items = ["角色设定", "思维链", "输出格式", "少样本学习", "迭代优化"]
    return {
        "chart_type": "infographic",
        "template_id": "grouped_infographic",
        "title": _title_from_prompt(text, "信息图"),
        "subtitle": "围绕主题组织多个认知模块",
        "language": "zh-CN",
        "style_profile": STYLE_PROFILE,
        "cards": [
            {
                "title": item,
                "summary": _bullets_for(item, 1)[0],
                "items": _bullets_for(item, 3)[1:] or ["关键要点", "应用说明"],
                "tags": [f"要点 {i + 1}"],
            }
            for i, item in enumerate(items[:8])
        ],
    }
