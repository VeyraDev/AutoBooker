"""Validator and normalizer for DiagramSpec."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from app.services.figures.render.html_template.schema import (
    STYLE_PROFILE,
    TEMPLATE_LIMITS,
    default_template_for_subtype,
)


def _truncate(text: Any, max_chars: int) -> str:
    s = str(text or "").strip()
    return s if len(s) <= max_chars else s[: max_chars - 1].rstrip() + "…"


def _walk(obj: Any, fn, path: str = "", parent: Any = None, key: Any = None) -> None:
    fn(obj, path, parent, key)
    if isinstance(obj, list):
        for i, value in enumerate(obj):
            _walk(value, fn, f"{path}[{i}]", obj, i)
    elif isinstance(obj, dict):
        for child_key, value in list(obj.items()):
            _walk(value, fn, f"{path}.{child_key}" if path else str(child_key), obj, child_key)


def _ensure_ids(spec: dict[str, Any], repairs: list[str]) -> None:
    for field in ("stages", "steps", "cards", "layers", "branches", "events", "dimensions", "groups", "items", "sections"):
        arr = spec.get(field)
        if not isinstance(arr, list):
            continue
        for i, item in enumerate(arr):
            if isinstance(item, dict) and not item.get("id"):
                item["id"] = f"{field}-{i}"
    repairs.append("补全组件 id。")


def _normalize_text_density(spec: dict[str, Any], repairs: list[str]) -> None:
    if spec.get("title"):
        old = str(spec["title"])
        spec["title"] = _truncate(old, 32)
        if spec["title"] != old:
            repairs.append("压缩过长 title。")
    if spec.get("subtitle"):
        spec["subtitle"] = _truncate(spec["subtitle"], 56)
    if spec.get("note"):
        spec["note"] = _truncate(spec["note"], 96)

    def trim_strings(value: Any, path: str, parent: Any, key: Any) -> None:
        if not isinstance(value, str) or parent is None:
            return
        limit = 28 if str(path).endswith((".title", ".label", ".condition", ".year")) else 48
        trimmed = _truncate(value, limit)
        if trimmed != value:
            parent[key] = trimmed
            repairs.append(f"压缩长文本 {path}。")

    _walk(spec, trim_strings)

    def limit_lists(value: Any, path: str, parent: Any, key: Any) -> None:
        if not isinstance(value, list) or key not in {"bullets", "items", "io"}:
            return
        if len(value) > 3:
            parent[key] = value[:3]
            repairs.append(f"限制 {path} 为最多 3 条。")

    _walk(spec, limit_lists)


def _fallback_horizontal(spec: dict[str, Any], repairs: list[str]) -> None:
    stages = spec.get("stages")
    if not isinstance(stages, list) or len(stages) <= TEMPLATE_LIMITS["horizontal_stage_cards"].max:
        return
    if len(stages) <= TEMPLATE_LIMITS["snake_cards"].max:
        spec["template_id"] = "snake_cards"
        spec["chart_type"] = "process_flow"
        spec["steps"] = [
            {
                "id": item.get("id") if isinstance(item, dict) else None,
                "title": item.get("title", "") if isinstance(item, dict) else str(item),
                "icon": item.get("icon", "step") if isinstance(item, dict) else "step",
                "items": (item.get("bullets") or item.get("items") or []) if isinstance(item, dict) else [],
            }
            for item in stages
        ]
        spec.pop("stages", None)
        repairs.append("horizontal_stage_cards 超容量，切换为 snake_cards。")
    else:
        spec["template_id"] = "grouped_infographic"
        spec["chart_type"] = "infographic"
        spec["cards"] = [
            {
                "id": item.get("id") if isinstance(item, dict) else None,
                "title": item.get("title", "") if isinstance(item, dict) else str(item),
                "summary": ((item.get("bullets") or item.get("items") or [""])[0]) if isinstance(item, dict) else "",
                "items": ((item.get("bullets") or item.get("items") or [])[1:4]) if isinstance(item, dict) else [],
                "tags": [f"模块 {i + 1}"],
            }
            for i, item in enumerate(stages[:8])
        ]
        spec.pop("stages", None)
        repairs.append("horizontal_stage_cards 严重超容量，切换为 grouped_infographic。")


def _fallback_snake(spec: dict[str, Any], repairs: list[str]) -> None:
    steps = spec.get("steps")
    if not isinstance(steps, list) or len(steps) <= TEMPLATE_LIMITS["snake_cards"].max:
        return
    spec["template_id"] = "grouped_infographic"
    spec["chart_type"] = "infographic"
    spec["cards"] = [
        {
            "id": item.get("id") if isinstance(item, dict) else None,
            "title": item.get("title", "") if isinstance(item, dict) else str(item),
            "summary": ((item.get("items") or [""])[0]) if isinstance(item, dict) else "",
            "items": ((item.get("items") or [])[1:4]) if isinstance(item, dict) else [],
            "tags": [f"模块 {i + 1}"],
        }
        for i, item in enumerate(steps[:8])
    ]
    spec.pop("steps", None)
    repairs.append("snake_cards 超容量，切换为 grouped_infographic。")


def _limit_template_arrays(spec: dict[str, Any], messages: list[str], repairs: list[str]) -> None:
    template_id = str(spec.get("template_id") or "")
    limit = TEMPLATE_LIMITS.get(template_id)
    if not limit or not limit.field:
        return
    arr = spec.get(limit.field)
    if arr is None:
        spec[limit.field] = []
        arr = spec[limit.field]
    if not isinstance(arr, list):
        messages.append(f"{limit.field} 必须是数组。")
        spec[limit.field] = []
        return
    if limit.max and len(arr) > limit.max:
        spec[limit.field] = arr[: limit.max]
        repairs.append(f"裁剪 {limit.field} 到模板容量 {limit.max}。")
    if limit.min and len(spec[limit.field]) < limit.min:
        messages.append(f"{template_id}: {limit.field} 数量偏少，建议补充信息。")


def validate_and_normalize(input_spec: dict[str, Any], *, subtype: str = "") -> dict[str, Any]:
    messages: list[str] = []
    repairs: list[str] = []

    if not isinstance(input_spec, dict):
        return {"ok": False, "severity": "err", "messages": ["DiagramSpec 不是对象。"], "spec": input_spec}
    if input_spec.get("needs_clarification"):
        return {
            "ok": False,
            "severity": "warn",
            "messages": ["需要追问：", *(input_spec.get("questions") or []), input_spec.get("reason") or ""],
            "spec": input_spec,
        }

    spec = deepcopy(input_spec)
    spec["language"] = spec.get("language") or "zh-CN"
    spec["style_profile"] = spec.get("style_profile") or STYLE_PROFILE
    spec["title"] = spec.get("title") or "未命名图示"
    if not spec.get("template_id") or spec.get("template_id") not in TEMPLATE_LIMITS:
        spec["template_id"] = default_template_for_subtype(subtype)
        repairs.append("按 subtype 补全 template_id。")
    if not spec.get("chart_type"):
        spec["chart_type"] = TEMPLATE_LIMITS[spec["template_id"]].chart_type

    _normalize_text_density(spec, repairs)
    _fallback_horizontal(spec, repairs)
    _fallback_snake(spec, repairs)
    _limit_template_arrays(spec, messages, repairs)
    _ensure_ids(spec, repairs)

    severity = "warn" if messages else "ok"
    return {
        "ok": True,
        "severity": severity,
        "messages": (messages or ["通过：模板合法，可渲染。"]) + [f"修复：{x}" for x in repairs],
        "spec": spec,
    }
