"""SemanticExtractor — 统一语义抽取输出 DiagramDSL。"""

from __future__ import annotations

import re
from typing import Any

from app.services.figures.dsl import build_dsl_from_parsed, default_dsl_for_type
from app.services.figures.dsl.to_parsed_spec import dsl_to_parsed_spec
from app.services.figures.intent.taxonomy import subtype_to_diagram_type
from app.services.figures.parse.hygiene import clean_label, visual_width
from app.services.figures.parse.registry import parse_diagram
from app.services.figures.schemas.diagram import DiagramIntent, PipelineContext
from app.services.figures.schemas.dsl import DiagramDSL, DiagramEdge, DiagramGroup, DiagramNode, slug_id

_ANNOTATION_RE = re.compile(
    r"连接前|连接后|连接所有|通过消息|异步通知|同步通知|"
    r"共[一二两三四五六七八九十\d]+个|"
    r"前[一二两三四五六七八九十\d]+个|"
    r"后[一二两三四五六七八九十\d]+个|"
    r"包含[一二两三四五六七八九十\d]+|"
    r"有[一二两三四五六七八九十\d]+个|"
    r"五个模块|四个服务|三个服务|两个服务|用箭头|箭头连接"
)

_RELATION_RE = re.compile(
    r"(.+?)(?:连接|调用|依赖|写入|读取|通过)(?:前|后|所有)?(?:\s*(\d+))?个?(?:服务|模块)?(.+)"
)


def extract_semantics(ctx: PipelineContext, intent: DiagramIntent) -> DiagramDSL:
    """统一入口：parse → DSL → sanitize。"""
    parsed = parse_diagram(ctx, intent)
    dt = intent.diagram_type or subtype_to_diagram_type(intent.diagram_subtype)
    dsl = build_dsl_from_parsed(intent, parsed, diagram_type=dt)
    dsl = sanitize_dsl(dsl, ctx.normalized_input)
    if not dsl.nodes and intent.fallback_allowed:
        dsl = default_dsl_for_type(dt, title=intent.title or dsl.title)
        dsl.confidence = max(0.5, intent.confidence - 0.1)
        dsl.notes.append("fallback_placeholder")
    return dsl


def sanitize_dsl(dsl: DiagramDSL, source_text: str = "") -> DiagramDSL:
    """说明句不当节点、指代展开、边补全。"""
    clean_nodes: list[DiagramNode] = []
    notes = list(dsl.notes)
    id_remap: dict[str, str] = {}

    for node in dsl.nodes:
        label = node.label.strip()
        if _is_annotation_label(label):
            expanded = _expand_relation_sentence(label, dsl, source_text)
            if expanded:
                dsl.edges.extend(expanded)
                notes.append(label)
                id_remap[node.id] = ""
                continue
            cleaned, _ = clean_label(label, max_units=12)
            if not cleaned or _is_annotation_label(cleaned):
                notes.append(label)
                id_remap[node.id] = ""
                continue
            node = DiagramNode(
                id=node.id,
                label=cleaned,
                type=node.type,
                group=node.group,
                description=node.description,
                icon=node.icon,
                importance=node.importance,
            )
        if visual_width(label) > 18 and not node.type == "decision":
            parts = re.split(r"[→->、,，；;]", label)
            if len(parts) > 1:
                notes.append(label)
                id_remap[node.id] = ""
                for i, part in enumerate(parts):
                    part = part.strip()
                    if part:
                        nid = slug_id(part)
                        clean_nodes.append(DiagramNode(id=nid, label=part, type="process", group=node.group))
                        if i > 0:
                            dsl.edges.append(DiagramEdge(source=slug_id(parts[i - 1].strip()), target=nid))
                continue
        clean_nodes.append(node)

    dsl.nodes = [n for n in clean_nodes if n.label]
    dsl.notes = notes

    if id_remap:
        new_edges: list[DiagramEdge] = []
        for edge in dsl.edges:
            src = id_remap.get(edge.source, edge.source)
            tgt = id_remap.get(edge.target, edge.target)
            if src and tgt:
                new_edges.append(DiagramEdge(source=src, target=tgt, label=edge.label, type=edge.type))
        dsl.edges = new_edges

    dsl.edges = _dedupe_edges(dsl.edges)
    _ensure_sequential_edges(dsl)
    _ensure_groups_from_nodes(dsl)
    return dsl


def dsl_to_render_spec(dsl: DiagramDSL) -> dict[str, Any]:
    """DSL 转 renderer 可用的 parsed_spec。"""
    return dsl_to_parsed_spec(dsl)


def _is_annotation_label(label: str) -> bool:
    return bool(_ANNOTATION_RE.search(str(label or "")))


def _expand_relation_sentence(label: str, dsl: DiagramDSL, source_text: str) -> list[DiagramEdge]:
    """解析关系句为边，如 API网关连接前三个服务。"""
    edges: list[DiagramEdge] = []
    text = label + " " + source_text

    gateway_match = re.search(r"(API网关|网关|gateway)", text, re.I)
    services = re.findall(r"(用户服务|订单服务|支付服务|库存服务|消息队列|数据库|[\u4e00-\u9fff]{2,6}服务)", text)
    if gateway_match and services:
        gw_id = _ensure_node(dsl, gateway_match.group(1))
        target_services = services
        if "前三个" in text or "前3个" in text:
            target_services = services[:3]
        elif "前两个" in text or "前2个" in text:
            target_services = services[:2]
        for svc in target_services:
            if svc != gateway_match.group(1):
                sid = _ensure_node(dsl, svc)
                edges.append(DiagramEdge(source=gw_id, target=sid, type="sync"))
        return edges

    notify_match = re.search(r"(.+?)通过(.+?)(?:异步)?通知(.+)", text)
    if notify_match:
        src = _ensure_node(dsl, notify_match.group(1).strip())
        via = _ensure_node(dsl, notify_match.group(2).strip())
        tgt = _ensure_node(dsl, notify_match.group(3).strip())
        edges.append(DiagramEdge(source=src, target=via, type="async"))
        edges.append(DiagramEdge(source=via, target=tgt, type="async"))
        return edges

    return edges


def _ensure_node(dsl: DiagramDSL, label: str) -> str:
    for n in dsl.nodes:
        if n.label == label:
            return n.id
    nid = slug_id(label)
    dsl.nodes.append(DiagramNode(id=nid, label=label, type="service"))
    return nid


def _dedupe_edges(edges: list[DiagramEdge]) -> list[DiagramEdge]:
    seen: set[tuple[str, str, str]] = set()
    out: list[DiagramEdge] = []
    for e in edges:
        key = (e.source, e.target, e.label)
        if key not in seen and e.source and e.target and e.source != e.target:
            seen.add(key)
            out.append(e)
    return out


def _ensure_sequential_edges(dsl: DiagramDSL) -> None:
    if dsl.edges or len(dsl.nodes) < 2:
        return
    if dsl.diagram_type not in {"flowchart", "dataflow", "timeline", "sequence"}:
        return
    ordered = dsl.nodes
    for i in range(len(ordered) - 1):
        dsl.edges.append(DiagramEdge(source=ordered[i].id, target=ordered[i + 1].id))


def _ensure_groups_from_nodes(dsl: DiagramDSL) -> None:
    grouped: dict[str, list[str]] = {}
    for n in dsl.nodes:
        if n.group:
            grouped.setdefault(n.group, []).append(n.id)
    existing = {g.label for g in dsl.groups}
    for label, nids in grouped.items():
        if label not in existing:
            dsl.groups.append(DiagramGroup(id=slug_id(label, "layer"), label=label, type="layer", nodes=nids))
