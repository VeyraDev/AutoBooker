"""DiagramDSL → parsed_spec 反向兼容。"""

from __future__ import annotations

from typing import Any

from app.services.figures.schemas.dsl import DiagramDSL


def dsl_to_parsed_spec(dsl: DiagramDSL) -> dict[str, Any]:
    """将 DSL 转回 renderer 可消费的 parsed_spec。"""
    dt = dsl.diagram_type
    base: dict[str, Any] = {
        "title": dsl.title,
        "layout": str(dsl.layout.get("direction") or "TB"),
        "diagram_type": dt,
        "notes": list(dsl.notes),
    }

    if dt == "architecture" and dsl.groups:
        base["layers"] = [
            {"label": g.label, "modules": [_label_for(dsl, nid) for nid in g.nodes]}
            for g in dsl.groups
        ]
        base["connections"] = [
            {"from": _label_for(dsl, e.source), "to": _label_for(dsl, e.target), "label": e.label}
            for e in dsl.edges
        ]
        return base

    if dt == "timeline":
        base["events"] = [
            {"label": n.label, "time": ""}
            for n in dsl.nodes
        ]
        return base

    if dt in {"taxonomy", "hierarchy"}:
        root = dsl.nodes[0] if dsl.nodes else None
        base["root"] = root.label if root else dsl.title
        base["children"] = [
            {"label": n.label}
            for n in dsl.nodes[1:]
        ]
        return base

    if dt == "comparison":
        base["columns"] = [n.label for n in dsl.nodes]
        return base

    if dt in {"flowchart", "decision_flow", "dataflow", "sequence"} or dsl.nodes:
        base["nodes"] = [
            {
                "id": n.id,
                "label": n.label,
                "type": n.type,
                "group": n.group,
                "icon": n.icon,
            }
            for n in dsl.nodes
        ]
        base["edges"] = [
            {
                "from": e.source,
                "to": e.target,
                "source": e.source,
                "target": e.target,
                "label": e.label,
                "type": e.type,
            }
            for e in dsl.edges
        ]
        if dt in {"flowchart", "decision_flow"}:
            base["stages"] = [{"label": n.label, "id": n.id, "type": n.type} for n in dsl.nodes]
        return base

    return base


def _label_for(dsl: DiagramDSL, node_id: str) -> str:
    for n in dsl.nodes:
        if n.id == node_id:
            return n.label
    return node_id
