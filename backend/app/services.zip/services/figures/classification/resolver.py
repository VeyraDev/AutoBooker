"""parsed_spec + intent → ClassificationRecord。"""

from __future__ import annotations

import re

from app.services.figure_render.renderer_rules import has_numeric_data_signal, style_profile_for_book
from app.services.figures.intent.taxonomy import (
    RENDERER_ILLUSTRATION,
    RENDERER_NEED_DATA,
    RENDERER_UPLOAD,
    SUBTYPE_TO_LEGACY_IMAGE_TYPE,
    canonical_subtype,
    resolve_renderer_key,
)
from app.services.figures.schemas.diagram import (
    ClassificationRecord,
    DiagramIntent,
    ParsedDiagram,
    PipelineContext,
    VisualPlan,
)

_LONG_PUNCT_RE = re.compile(r"[，,。；;：:、\n]")


def _visual_len(text: str) -> float:
    total = 0.0
    for ch in str(text or ""):
        if "\u4e00" <= ch <= "\u9fff":
            total += 1.0
        elif ch.isspace():
            total += 0.35
        else:
            total += 0.55
    return total


def _shorten_title(raw: str, *, fallback: str = "示意图") -> str:
    """Keep figure titles short enough to be rendered inside book diagrams."""
    text = re.sub(r"\s+", " ", str(raw or "").strip())
    text = re.sub(r"^(图\s*\d+\s*[-–—]\s*\d+\s*[:：]\s*)", "", text)
    text = re.sub(r"^(请|生成|绘制|画一张|一张)", "", text).strip(" ：:，,。")
    if not text:
        return fallback
    first = _LONG_PUNCT_RE.split(text, 1)[0].strip(" ：:，,。")
    if first and _visual_len(first) <= 24:
        return first
    out = ""
    for ch in (first or text):
        if _visual_len(out + ch) > 24:
            break
        out += ch
    return out.strip(" ：:，,。") or fallback


def _structured_quality(parsed_spec: dict, subtype: str, renderer: str) -> tuple[list[str], list[str], str]:
    warnings: list[str] = []
    flags: list[str] = []
    layout = str(parsed_spec.get("layout") or "").upper()
    nodes = [n for n in (parsed_spec.get("nodes") or []) if isinstance(n, dict)]
    edges = [e for e in (parsed_spec.get("edges") or []) if isinstance(e, dict)]
    strategy = "image_api" if renderer == RENDERER_ILLUSTRATION else (layout or "TB")

    if not renderer.startswith("structured."):
        return warnings, flags, strategy

    if not nodes:
        flags.append("missing_nodes")
        warnings.append("结构化图缺少节点")
        return warnings, flags, strategy
    if len(nodes) > 18:
        flags.append("complex_graph")
        warnings.append("节点过多，建议分组或拆成多张图")
        strategy = "grouped"
    if subtype in {"process_flow", "business_workflow", "timeline_roadmap", "timeline", "roadmap"}:
        if len(edges) < max(0, len(nodes) - 1):
            flags.append("edge_gap")
            warnings.append("流程/时间线边数量不足，渲染前会尝试补齐顺序连线")
        strategy = "LR" if len(nodes) <= 8 else "TB_STACKED"
    if subtype in {"decision_tree", "decision_flow"} and len(edges) < max(0, len(nodes) - 1):
        flags.append("decision_edge_gap")
        warnings.append("决策树分支不完整，渲染前会尝试补齐父子连线")
    if parsed_spec.get("title") and _visual_len(str(parsed_spec.get("title"))) > 28:
        flags.append("long_title")
        warnings.append("图内标题过长，已压缩为短标题")
    return warnings, flags, strategy


def _semantic_labels(parsed_spec: dict) -> list[str]:
    labels: list[str] = []
    for node in parsed_spec.get("nodes") or []:
        if isinstance(node, dict) and node.get("label"):
            labels.append(str(node["label"]))
    for stage in parsed_spec.get("stages") or []:
        if isinstance(stage, dict) and stage.get("label"):
            labels.append(str(stage["label"]))
    for layer in parsed_spec.get("layers") or []:
        if isinstance(layer, dict):
            labels.extend(str(x) for x in (layer.get("modules") or []) if str(x).strip())
    labels.extend(str(x) for x in (parsed_spec.get("columns") or []) if str(x).strip())
    labels.extend(str(x) for x in (parsed_spec.get("dimensions") or []) if str(x).strip())
    for block in parsed_spec.get("blocks") or []:
        if isinstance(block, dict) and block.get("label"):
            labels.append(str(block["label"]))
    return labels


def _image_api_safe_for_structured(parsed_spec: dict, subtype: str) -> bool:
    mode = str(parsed_spec.get("render_mode") or "").strip().lower()
    if mode not in {"image_api", "illustration", "illustrative_image"}:
        return False
    if subtype in {"chart", "attention_matrix", "swot"}:
        return False
    labels = _semantic_labels(parsed_spec)
    if not labels or len(labels) > 8:
        return False
    return all(_visual_len(label) <= 10 for label in labels)


def build_classification_record(
    ctx: PipelineContext,
    intent: DiagramIntent,
    parsed: ParsedDiagram,
    *,
    visual_plan: VisualPlan | None = None,
) -> ClassificationRecord:
    subtype = canonical_subtype(intent.diagram_subtype)
    if subtype == "data_visualization":
        subtype = "chart"

    numeric = has_numeric_data_signal(ctx.normalized_input)
    if parsed.parsed_spec.get("values") or parsed.parsed_spec.get("series"):
        numeric = True

    renderer = resolve_renderer_key(subtype, has_numeric_data=numeric)
    if _image_api_safe_for_structured(parsed.parsed_spec, subtype):
        renderer = RENDERER_ILLUSTRATION
        parsed.parsed_spec.setdefault("quality_flags", []).append("image_api_structured_visual")
        parsed.parsed_spec.setdefault("render_warnings", []).append("低文字结构视觉图允许使用 Image API，并保留结构化计划用于审查")
    # Only real scene illustrations go to Image API. Text-heavy information graphics should stay structured.
    if intent.diagram_family == "illustration" and subtype in {"scene_illustration", "case_scene", "future_scene", "human_ai_scene"}:
        renderer = RENDERER_ILLUSTRATION
    if subtype == "chart" and not numeric:
        renderer = RENDERER_NEED_DATA

    image_type = SUBTYPE_TO_LEGACY_IMAGE_TYPE.get(subtype, "concept_diagram")
    if renderer == RENDERER_ILLUSTRATION:
        image_type = "scene_illustration"

    parsed_title = str(parsed.parsed_spec.get("title") or "").strip()
    title_source = intent.title or parsed_title or ctx.chapter_title
    title = _shorten_title(title_source, fallback="示意图")
    if parsed.parsed_spec.get("title"):
        parsed.parsed_spec["title"] = _shorten_title(str(parsed.parsed_spec.get("title")), fallback=title)
    parsed.parsed_spec["diagram_subtype"] = subtype
    render_warnings, quality_flags, layout_strategy = _structured_quality(parsed.parsed_spec, subtype, renderer)
    render_warnings = list(dict.fromkeys(list(parsed.parsed_spec.get("render_warnings") or []) + render_warnings))
    quality_flags = list(dict.fromkeys(list(parsed.parsed_spec.get("quality_flags") or []) + quality_flags))
    must_avoid = ["照片写实", "复杂背景", "营销海报风", "文字堆叠"]
    if renderer == RENDERER_ILLUSTRATION:
        must_avoid.extend(["可读文字", "复杂标签", "UI 截图伪造"])
    else:
        must_avoid.extend(["装饰性插画", "伪 3D", "过多颜色"])

    prompt_spec = {
        "title": title,
        "core_message": ctx.normalized_input[:500],
        "visual_description": parsed.parsed_spec.get("structure_summary") or ctx.normalized_input[:500],
        "output_format": "png+svg" if renderer.startswith("structured.") else "png",
        "style": "book interior diagram, unified blue-gray color blocks, subtle icon badges, generous spacing, clean vector lines",
        "must_avoid": must_avoid,
        "visual_requirements": [
            "节点标签只保留语义短名",
            "统一蓝灰主色，少量青蓝/琥珀强调",
            "图标用于辅助识别，不替代文字",
            "节点间距充足，避免线条穿过文字",
        ],
    }
    visual_json = None
    if visual_plan:
        visual_json = visual_plan.to_prompt_spec()
        prompt_spec.update(visual_json)

    return ClassificationRecord(
        diagram_family=intent.diagram_family,
        diagram_subtype=subtype,
        renderer=renderer,
        confidence=intent.confidence,
        understanding_source=intent.source,
        normalized_input=ctx.normalized_input,
        parsed_spec=parsed.parsed_spec,
        visual_plan=visual_json,
        prompt_spec=prompt_spec,
        image_type=image_type,
        subtype=ctx.subtype_hint or subtype,
        style_profile=style_profile_for_book(ctx.style_type),
        render_warnings=render_warnings,
        quality_flags=quality_flags,
        layout_strategy=layout_strategy,
    )
