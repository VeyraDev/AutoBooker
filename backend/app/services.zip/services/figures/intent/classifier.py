"""Diagram Intent LLM 分类（仅 family + subtype，不抽结构）。"""

from __future__ import annotations

import logging
from typing import Any

from app.config import settings
from app.llm.client import LLMClient
from app.services.figures.intent.taxonomy import FAMILY_DEFAULT_SUBTYPE, canonical_subtype
from app.services.figures.schemas.diagram import DiagramIntent, PipelineContext
from app.utils.json_llm import parse_llm_json

logger = logging.getLogger(__name__)

_INTENT_PROMPT = """你是图书配图的语义意图识别模块。只判断图形族与细分类，不要输出 nodes/edges/prompt。

你必须根据“作者真正想画的图形语法”分类，而不是按领域名词套模板。例如：
- “RAG pipeline：提问→向量化→检索→生成”是 workflow/process_flow，不是 rag 架构。
- “RAG 系统架构：用户、检索器、向量库、LLM 的模块关系”才是 architecture/rag 或 system_architecture。
- “Attention 权重矩阵 / Q-K scores / mask / softmax 可视化”是 matrix/attention_matrix。
- “Transformer 编码器-解码器堆叠结构”才是 transformer。
- “A、B、C 的差异/优劣/维度比较”是 comparison_matrix。
- “章节核心要点、多个信息块、图标化总结”是 infographic。

必须只输出 JSON：
{{
  "diagram_family": "architecture|decision|workflow|matrix|knowledge|timeline|organization|illustration|data",
  "diagram_subtype": "concept_diagram|mechanism_diagram|process_flow|system_architecture|data_visualization|chart|comparison_matrix|taxonomy_map|timeline_roadmap|decision_tree|transformer|rag|agent|swot|attention_matrix|scene_illustration|infographic|org_chart",
  "confidence": 0.0,
  "title": "图题建议，不超过 24 个中文字符"
}}

分类规则：
1. 有真实数值/统计趋势/占比，并且用户要图表 → data / chart。
2. 操作步骤、用户路径、从 A 到 B 的流程 → workflow / process_flow。
3. 系统模块、层级、服务、数据库、Agent/RAG 架构 → architecture / system_architecture；明确 RAG → rag；明确 Transformer 编码器解码器 → transformer。
4. 模型/算法/机制内部如何运作 → knowledge / mechanism_diagram。
5. 两个或多个对象优劣/差异 → matrix / comparison_matrix；SWOT → swot。
6. 分类体系、知识图谱、能力地图、思维导图 → knowledge / taxonomy_map。
7. 时间演进、路线图、学习路径 → timeline / timeline_roadmap。
8. 帮读者判断/选择 → decision / decision_tree。
9. 章节总结、知识总结、多个信息块组合 → knowledge / infographic。
10. 只有具象场景、人物、氛围、封面感时 → illustration / scene_illustration。
11. 抽象关系解释，且不属于以上情况 → knowledge / concept_diagram。

重要：concept_diagram、infographic、comparison_matrix、taxonomy_map 都不是场景插画；不要因为出现“图”字就判为 illustration。
重要：title 只给短图题，不要复制“完整、左侧、右侧、用箭头连接、展示以下”等版式说明。

书型：{book_type} / 风格：{style_type}
章节：{chapter_title}
用户补充：{user_hint}
描述：
{normalized_input}
"""


def classify_diagram_intent(ctx: PipelineContext) -> DiagramIntent | None:
    model = (ctx.model or settings.intent_model).strip()
    if not model or not ctx.normalized_input.strip():
        return None
    prompt = _INTENT_PROMPT.format(
        book_type=ctx.book_type or "nonfiction",
        style_type=ctx.style_type or "general",
        chapter_title=ctx.chapter_title or "（无）",
        user_hint=ctx.user_hint or "（无）",
        normalized_input=ctx.normalized_input[:2500],
    )
    try:
        client = LLMClient()
        out = client.chat_completion(
            [
                {"role": "system", "content": "只输出合法 JSON。"},
                {"role": "user", "content": prompt},
            ],
            model=model,
            max_tokens=512,
            temperature=0.05,
        )
        data = parse_llm_json(out)
        return _sanitize_intent(data)
    except Exception as e:
        logger.warning("diagram intent LLM failed: %s", e)
        return None


def _sanitize_intent(data: dict[str, Any]) -> DiagramIntent | None:
    family = str(data.get("diagram_family") or "").strip().lower()
    subtype = canonical_subtype(str(data.get("diagram_subtype") or "").strip().lower())
    if not family:
        return None
    if not subtype:
        subtype = FAMILY_DEFAULT_SUBTYPE.get(family, "concept_diagram")
    # Convert legacy data_visualization to renderer-supported chart subtype.
    if subtype == "data_visualization":
        subtype = "chart"
    try:
        conf = float(data.get("confidence", 0.7))
    except (TypeError, ValueError):
        conf = 0.7
    title = str(data.get("title") or "").strip()
    if len(title) > 60:
        title = title[:60] + "…"
    return DiagramIntent(family, subtype, max(0.0, min(1.0, conf)), "llm", title)
