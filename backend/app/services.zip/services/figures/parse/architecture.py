"""System architecture parser."""

from __future__ import annotations

import re
from typing import Any

from app.config import settings
from app.llm.client import LLMClient
from app.services.figures.schemas.diagram import DiagramIntent, ParsedDiagram, PipelineContext
from app.utils.json_llm import parse_llm_json

_PROMPT = """解析系统架构 JSON。只输出 JSON：
{
  "title": "短标题",
  "layers": [
    {"label":"前端层", "modules":["React 应用"]},
    {"label":"服务层", "modules":["FastAPI 后端"]},
    {"label":"数据层", "modules":["PostgreSQL"]}
  ],
  "connections": [
    {"from":"React 应用", "to":"FastAPI 后端", "label":"HTTP"},
    {"from":"FastAPI 后端", "to":"PostgreSQL", "label":"SQL"}
  ]
}
规则：
1. layers 表示层级/区域；modules 是该层模块；connections 表示跨层调用/数据流。
2. 根据语义识别模块，不要因为描述里说“左侧/右侧/上方”就把这些词写进模块名。
3. label/modules 只写短名，如“检索器”“向量库”“LLM”；禁止写“完整架构图”“左侧模块”“用箭头连接”等版式说明。
描述：{text}
"""

_LAYER_PATTERNS = [
    ("前端层", r"(?:顶层|前端|客户端)[是为：:]*([^，,。；;]+)"),
    ("服务层", r"(?:中间层|后端|服务层)[是为：:]*([^，,。；;]+)"),
    ("数据层", r"(?:底层|数据库|数据层)[是为：:]*([^，,。；;]+)"),
]


def _short(text: Any, limit: int = 22) -> str:
    raw = re.sub(r"\s+", " ", str(text or "").strip()).strip(" ：:，,。")
    raw = re.sub(r"^(?:微服务架构图|系统架构图|架构图)$", "", raw)
    raw = re.sub(r"(?:\d+|[一二两三四五六七八九十])\s*个(?:模块|服务|组件)$", "", raw)
    return raw[:limit].strip(" ：:，,。")


def _split_modules(text: str) -> list[str]:
    parts = re.split(r"[、,，/]|和|与", str(text or ""))
    modules: list[str] = []
    for part in parts:
        module = _clean_module_name(part)
        if module and module not in modules:
            modules.append(module)
    return modules


def _clean_module_name(text: Any) -> str:
    raw = re.sub(r"\s+", " ", str(text or "").strip()).strip(" ：:，,。")
    raw = re.sub(r"^(?:包含|包括|有|模块|组件)[:：]?\s*", "", raw)
    raw = re.sub(r"^(?:微服务架构图|系统架构图|架构图)$", "", raw)
    raw = re.sub(r"(?:\d+|[一二两三四五六七八九十])\s*个(?:模块|服务|组件)$", "", raw)
    raw = re.split(r"(?:连接|通过|异步|同步|通知|调用|返回|依赖)", raw, 1)[0]
    return _short(raw, 20)


def _declared_modules(text: str) -> list[str]:
    patterns = [
        r"(?:包含|包括|有)[:：]?\s*(.+?)(?:\d+|[一二两三四五六七八九十])\s*个(?:模块|服务|组件)",
        r"(?:包含|包括|有)[:：]?\s*([^。；;]+)",
    ]
    for pattern in patterns:
        m = re.search(pattern, text)
        if not m:
            continue
        modules = _split_modules(m.group(1))
        if modules:
            return modules
    return _split_modules(text)


def _module_layers(modules: list[str]) -> list[dict[str, Any]]:
    gateways = [m for m in modules if "网关" in m or "入口" in m]
    infra = [m for m in modules if re.search(r"队列|数据库|缓存|存储|消息", m)]
    services = [m for m in modules if m not in gateways and m not in infra]
    layers: list[dict[str, Any]] = []
    if gateways:
        layers.append({"label": "入口层", "modules": gateways})
    if services:
        layers.append({"label": "服务层", "modules": services})
    if infra:
        layers.append({"label": "基础设施层", "modules": infra})
    return layers or [{"label": "模块层", "modules": modules[:6] or ["应用模块"]}]


def _rule_connections(text: str, layers: list[dict[str, Any]]) -> list[dict[str, str]]:
    modules = [m for layer in layers for m in layer.get("modules", [])]
    services = [m for m in modules if "服务" in m]
    gateways = [m for m in modules if "网关" in m or "入口" in m]
    connections: list[dict[str, str]] = []

    if gateways and re.search(r"网关[^。；;，,]*连接前(?:三|3)个服务", text):
        for service in services[:3]:
            connections.append({"from": gateways[0], "to": service, "label": ""})

    for m in re.finditer(r"([^，,。；;\s]+?)通过([^，,。；;\s]+?)(?:异步|同步)?通知([^，,。；;\s]+)", text):
        src = _match_module(m.group(1), modules)
        via = _match_module(m.group(2), modules)
        dst = _match_module(m.group(3), modules)
        label = "异步通知" if "异步" in m.group(0) else "通知"
        if src and via:
            connections.append({"from": src, "to": via, "label": label})
        if via and dst:
            connections.append({"from": via, "to": dst, "label": label})

    for m in re.finditer(r"([^，,。；;\s]+?)连接([^，,。；;]+)", text):
        src = _match_module(m.group(1), modules)
        if not src:
            continue
        targets = [_match_module(part, modules) for part in _split_modules(m.group(2))]
        for target in targets:
            if target and src != target:
                connections.append({"from": src, "to": target, "label": ""})

    deduped: list[dict[str, str]] = []
    seen: set[tuple[str, str, str]] = set()
    for conn in connections:
        key = (conn["from"], conn["to"], conn.get("label", ""))
        if key not in seen:
            deduped.append(conn)
            seen.add(key)
    return deduped


def _match_module(fragment: str, modules: list[str]) -> str:
    cleaned = _clean_module_name(fragment)
    if not cleaned:
        return ""
    for module in modules:
        if cleaned == module or cleaned in module or module in cleaned:
            return module
    return cleaned if cleaned in modules else ""


def _normalize_layers(raw: Any) -> list[dict[str, Any]]:
    layers: list[dict[str, Any]] = []
    if not isinstance(raw, list):
        return layers
    for item in raw[:6]:
        if not isinstance(item, dict):
            continue
        label = _short(item.get("label") or item.get("name") or item.get("layer"), 16)
        modules_raw = item.get("modules") or item.get("components") or []
        modules = [_clean_module_name(m) for m in modules_raw if _clean_module_name(m)] if isinstance(modules_raw, list) else _split_modules(str(modules_raw))
        modules = list(dict.fromkeys(modules))
        if label and modules:
            layers.append({"label": label, "modules": modules[:6]})
    return layers


def _rule_layers(text: str) -> list[dict[str, Any]]:
    layers: list[dict[str, Any]] = []
    for label, pattern in _LAYER_PATTERNS:
        m = re.search(pattern, text)
        if m:
            modules = _split_modules(m.group(1))
            if modules:
                layers.append({"label": label, "modules": modules[:4]})
    if layers:
        return layers

    modules = _declared_modules(text)
    return _module_layers(modules)


def _normalize_connections(raw: Any) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    if not isinstance(raw, list):
        return out
    for item in raw[:12]:
        if not isinstance(item, dict):
            continue
        src = _short(item.get("from") or item.get("source"), 20)
        dst = _short(item.get("to") or item.get("target"), 20)
        label = _short(item.get("label") or item.get("type"), 14)
        if src and dst:
            out.append({"from": src, "to": dst, "label": label})
    return out


def _to_graph(title: str, layers: list[dict[str, Any]], connections: list[dict[str, str]] | None = None) -> dict[str, Any]:
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, str]] = []
    module_to_id: dict[str, str] = {}
    for li, layer in enumerate(layers):
        for mi, module in enumerate(layer["modules"]):
            nid = f"l{li}_m{mi}"
            nodes.append({"id": nid, "label": module, "shape": "box", "level": li, "column": mi})
            module_to_id[module] = nid
    if not connections:
        for left, right in zip(layers, layers[1:]):
            for src in left["modules"]:
                for dst in right["modules"][: max(1, min(2, len(right["modules"])))]:
                    edges.append({"from": module_to_id[src], "to": module_to_id[dst], "label": ""})
    for conn in connections or []:
        src = module_to_id.get(conn["from"])
        dst = module_to_id.get(conn["to"])
        if src and dst:
            edge = {"from": src, "to": dst, "label": conn.get("label", "")}
            if edge not in edges:
                edges.append(edge)
    return {
        "diagram_subtype": "system_architecture",
        "layout": "TB",
        "title": title or "系统架构",
        "structure_summary": f"{len(layers)} 层系统架构",
        "layers": layers,
        "connections": connections or [],
        "nodes": nodes,
        "edges": edges,
    }


def parse_architecture(ctx: PipelineContext, intent: DiagramIntent) -> ParsedDiagram:
    model = (ctx.model or settings.intent_model).strip()
    if ctx.use_llm and model:
        try:
            out = LLMClient().chat_completion(
                [{"role": "user", "content": _PROMPT.format(text=ctx.normalized_input[:2500])}],
                model=model,
                max_tokens=2400,
                temperature=0.1,
            )
            data = parse_llm_json(out)
            if isinstance(data, dict):
                layers = _normalize_layers(data.get("layers"))
                if layers:
                    connections = _normalize_connections(data.get("connections"))
                    return ParsedDiagram(_to_graph(_short(data.get("title") or intent.title, 24), layers, connections), "llm_architecture")
        except Exception:
            pass
    layers = _rule_layers(ctx.normalized_input)
    connections = _rule_connections(ctx.normalized_input, layers)
    return ParsedDiagram(_to_graph(_short(intent.title or "系统架构", 24), layers, connections), "rules_architecture")
