"""Unified LLM semantic diagram planner.

This sits before subtype-specific fallbacks. The goal is to let the model read
the user's semantic intent and emit a diagram plan, instead of extracting
structure by punctuation rules or growing noun-specific templates.
"""

from __future__ import annotations

from typing import Any

from app.config import settings
from app.llm.client import LLMClient
from app.services.figures.intent.taxonomy import canonical_subtype
from app.services.figures.parse.hygiene import icon_hint
from app.services.figures.schemas.diagram import DiagramIntent, ParsedDiagram, PipelineContext
from app.utils.json_llm import parse_llm_json

_PROMPT = """你是图书配图的语义规划器。请先理解作者真正想表达的图形语法，再输出可渲染 JSON。

不要按逗号、顿号、箭头机械切割。不要为 RAG、Transformer、Attention 等名词硬套模板。
你要判断：这是流程、架构、对比、矩阵、时间线、分类、关系网络、机制图、信息图，还是场景插画。

只输出 JSON，推荐字段如下：
{
  "title": "短标题",
  "diagram_subtype": "{subtype}",
  "render_mode": "structured_svg|image_api",
  "layout": "LR|TB|GRID|RADIAL|MATRIX",
  "structure_summary": "一句话说明结构",
  "nodes": [
    {"id":"n1","label":"语义短名","shape":"rounded|box|diamond|tag","level":0,"column":0,"icon":"user|data|service|search|output|decision|time|node"}
  ],
  "edges": [{"from":"n1","to":"n2","label":"短关系"}],

  "stages": [{"id":"s1","label":"流程步骤","kind":"step|decision|parallel|output","icon":"node"}],
  "events": [{"time":"2017","label":"事件短名"}],
  "root": "分类根节点",
  "children": [{"label":"一级分类","children":[{"label":"二级分类"}]}],
  "columns": ["对比对象A", "对比对象B"],
  "dimensions": ["维度A", "维度B"],
  "cells": [{"dimension":"维度A","values":{"对比对象A":"短值"}}],
  "layers": [{"label":"层级名","modules":["模块A","模块B"]}],
  "connections": [{"from":"模块A","to":"模块B","label":"调用/数据流"}],
  "center": "中心概念",
  "concepts": ["相关概念A", "相关概念B"],
  "blocks": [{"label":"信息块","items":["短要点"]}]
}

硬性规则：
1. label 只写语义短名或动作短语，禁止出现“完整、左侧、右侧、上方、下方、图中、展示、说明、用箭头连接、布局、放置”等版式说明。
2. 每个节点/块建议 2-8 个中文字或 1-4 个英文词；长解释放 structure_summary。
3. 流程图用 stages 表达真实步骤顺序，并给出 edges；不要把多个真实步骤合并成一个框。
4. 对比图用 columns/dimensions/cells；不要输出中心节点+横向子节点。
5. 信息图用 blocks；不要输出中心节点+横向子节点。
6. 架构图用 layers/modules/connections；不要把“左侧模块/右侧模块”写成模块名。
7. 如果用户描述的是低文字视觉化结构图，可设置 render_mode="image_api"；如果是文字密集、表格、数据、矩阵、需要精确中文标签，设置 render_mode="structured_svg"。
8. 无论使用哪种 render_mode，都必须输出语义结构字段，方便审查和兜底渲染。

书型：{book_type}
章节：{chapter_title}
已识别意图：{family}/{subtype}
描述：
{text}
"""


def parse_semantic_plan(ctx: PipelineContext, intent: DiagramIntent) -> ParsedDiagram | None:
    model = (ctx.model or settings.intent_model).strip()
    if not ctx.use_llm or not model or not ctx.normalized_input.strip():
        return None
    try:
        out = LLMClient().chat_completion(
            [{"role": "user", "content": _PROMPT.format(
                book_type=ctx.book_type or "nonfiction",
                chapter_title=ctx.chapter_title or "（无）",
                family=intent.diagram_family,
                subtype=intent.diagram_subtype,
                text=ctx.normalized_input[:3500],
            )}],
            model=model,
            max_tokens=3600,
            temperature=0.08,
        )
        data = parse_llm_json(out)
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    spec = _normalize_plan(data, intent)
    if not _is_usable(spec, intent.diagram_subtype):
        return None
    return ParsedDiagram(spec, "llm_semantic_plan")


def _normalize_plan(data: dict[str, Any], intent: DiagramIntent) -> dict[str, Any]:
    spec = dict(data.get("spec") if isinstance(data.get("spec"), dict) else data)
    subtype = canonical_subtype(str(spec.get("diagram_subtype") or intent.diagram_subtype))
    spec["diagram_subtype"] = subtype
    spec["title"] = str(spec.get("title") or intent.title or "").strip()
    spec["layout"] = _layout_for(subtype, str(spec.get("layout") or ""))

    _normalize_native_ids(spec)
    if subtype in {"process_flow", "business_workflow"}:
        _nodes_from_stages(spec)
    elif subtype in {"timeline", "timeline_roadmap", "roadmap"}:
        _nodes_from_events(spec)
    elif subtype in {"comparison_matrix"}:
        _nodes_from_comparison(spec)
    elif subtype in {"system_architecture", "microservice_architecture", "rag", "agent"}:
        _nodes_from_layers(spec)
    elif subtype in {"taxonomy_map", "mindmap", "org_chart", "hierarchy_chart"}:
        _nodes_from_tree(spec)
    elif subtype in {"knowledge_graph"}:
        _nodes_from_network(spec)
    elif subtype in {"infographic", "chapter_summary"}:
        _nodes_from_blocks(spec)
    elif subtype in {"mechanism_diagram"}:
        _nodes_from_steps(spec)

    _ensure_node_icons(spec)
    _repair_edges(spec, subtype)
    return spec


def _layout_for(subtype: str, raw: str) -> str:
    layout = raw.strip().upper()
    if layout in {"LR", "TB"}:
        return layout
    if subtype in {"process_flow", "business_workflow", "timeline", "timeline_roadmap", "roadmap"}:
        return "LR"
    if subtype in {"comparison_matrix", "infographic", "chapter_summary"}:
        return "TB"
    return "TB"


def _normalize_native_ids(spec: dict[str, Any]) -> None:
    for key, prefix in (("stages", "s"), ("nodes", "n")):
        items = spec.get(key)
        if not isinstance(items, list):
            continue
        seen: set[str] = set()
        for i, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            item_id = str(item.get("id") or f"{prefix}{i}").strip()
            if item_id in seen:
                item_id = f"{prefix}{i}"
            item["id"] = item_id
            seen.add(item_id)


def _nodes_from_stages(spec: dict[str, Any]) -> None:
    stages = [s for s in spec.get("stages") or [] if isinstance(s, dict) and str(s.get("label") or "").strip()]
    if not stages:
        return
    spec["nodes"] = [
        {
            "id": str(stage.get("id") or f"s{i}"),
            "label": str(stage.get("label") or ""),
            "shape": "diamond" if stage.get("kind") == "decision" else "rounded",
            "level": i,
            "column": 0,
            "icon": stage.get("icon") or icon_hint(str(stage.get("label") or ""), str(stage.get("kind") or "")),
        }
        for i, stage in enumerate(stages)
    ]


def _nodes_from_events(spec: dict[str, Any]) -> None:
    events = [e for e in spec.get("events") or [] if isinstance(e, dict) and str(e.get("label") or "").strip()]
    if not events:
        return
    spec["nodes"] = [
        {"id": f"e{i}", "label": f"{event.get('time') or ''} {event.get('label') or ''}".strip(), "shape": "rounded", "level": i, "column": 0, "icon": "time"}
        for i, event in enumerate(events)
    ]


def _nodes_from_comparison(spec: dict[str, Any]) -> None:
    columns = [str(c).strip() for c in spec.get("columns") or [] if str(c).strip()]
    dimensions = [str(d).strip() for d in spec.get("dimensions") or [] if str(d).strip()]
    if not columns or not dimensions:
        return
    nodes = [{"id": "matrix", "label": spec.get("title") or "对比矩阵", "shape": "rounded", "level": 0, "column": 0, "icon": "node"}]
    for i, dim in enumerate(dimensions):
        nodes.append({"id": f"d{i}", "label": dim, "shape": "box", "level": 1, "column": i, "icon": "node"})
    for i, col in enumerate(columns):
        nodes.append({"id": f"c{i}", "label": col, "shape": "tag", "level": 2, "column": i, "icon": "service"})
    spec["nodes"] = nodes


def _nodes_from_layers(spec: dict[str, Any]) -> None:
    layers = [l for l in spec.get("layers") or [] if isinstance(l, dict)]
    nodes = []
    for li, layer in enumerate(layers):
        modules = [str(m).strip() for m in layer.get("modules") or [] if str(m).strip()]
        for mi, module in enumerate(modules):
            nodes.append({"id": f"l{li}_m{mi}", "label": module, "shape": "box", "level": li, "column": mi, "icon": icon_hint(module)})
    if nodes:
        spec["nodes"] = nodes


def _nodes_from_tree(spec: dict[str, Any]) -> None:
    root = str(spec.get("root") or spec.get("title") or "核心分类").strip()
    children = [c for c in spec.get("children") or [] if isinstance(c, dict)]
    if not children:
        return
    nodes = [{"id": "root", "label": root, "shape": "rounded", "level": 0, "column": 0, "icon": "node"}]
    for i, child in enumerate(children):
        nodes.append({"id": f"c{i}", "label": str(child.get("label") or ""), "shape": "box", "level": 1, "column": i, "parent": "root", "icon": icon_hint(str(child.get("label") or ""))})
        for j, grand in enumerate(child.get("children") or []):
            if isinstance(grand, dict):
                nodes.append({"id": f"c{i}_{j}", "label": str(grand.get("label") or ""), "shape": "tag", "level": 2, "column": i, "parent": f"c{i}", "icon": icon_hint(str(grand.get("label") or ""))})
    spec["nodes"] = nodes


def _nodes_from_network(spec: dict[str, Any]) -> None:
    center = str(spec.get("center") or spec.get("title") or "核心概念").strip()
    concepts = [str(c).strip() for c in spec.get("concepts") or [] if str(c).strip()]
    if not concepts:
        return
    nodes = [{"id": "center", "label": center, "shape": "rounded", "level": 0, "column": max(0, len(concepts) // 2), "icon": icon_hint(center)}]
    for i, concept in enumerate(concepts):
        nodes.append({"id": f"n{i}", "label": concept, "shape": "box", "level": 1, "column": i, "icon": icon_hint(concept)})
    spec["nodes"] = nodes


def _nodes_from_blocks(spec: dict[str, Any]) -> None:
    blocks = [b for b in spec.get("blocks") or [] if isinstance(b, dict) and str(b.get("label") or "").strip()]
    if not blocks:
        return
    nodes = [{"id": "summary", "label": spec.get("title") or "信息图", "shape": "rounded", "level": 0, "column": 0, "icon": "node"}]
    for i, block in enumerate(blocks):
        label = str(block.get("label") or "")
        nodes.append({"id": f"b{i}", "label": label, "shape": "box", "level": 1, "column": i, "icon": block.get("icon") or icon_hint(label)})
    spec["nodes"] = nodes


def _nodes_from_steps(spec: dict[str, Any]) -> None:
    steps = [s for s in spec.get("steps") or [] if isinstance(s, dict) and str(s.get("label") or "").strip()]
    if not steps:
        return
    spec["nodes"] = [
        {"id": str(step.get("id") or f"m{i}"), "label": str(step.get("label") or ""), "shape": "box", "level": i, "column": 0, "icon": icon_hint(str(step.get("label") or ""), str(step.get("kind") or ""))}
        for i, step in enumerate(steps)
    ]


def _ensure_node_icons(spec: dict[str, Any]) -> None:
    for node in spec.get("nodes") or []:
        if isinstance(node, dict):
            node.setdefault("icon", icon_hint(str(node.get("label") or ""), str(node.get("kind") or node.get("shape") or "")))


def _repair_edges(spec: dict[str, Any], subtype: str) -> None:
    nodes = [n for n in spec.get("nodes") or [] if isinstance(n, dict) and n.get("id")]
    ids = {str(n["id"]) for n in nodes}
    edges = []
    seen: set[tuple[str, str]] = set()
    for edge in spec.get("edges") or []:
        if not isinstance(edge, dict):
            continue
        src = str(edge.get("from") or edge.get("source") or "").strip()
        dst = str(edge.get("to") or edge.get("target") or "").strip()
        if src in ids and dst in ids and src != dst and (src, dst) not in seen:
            edges.append({"from": src, "to": dst, "label": str(edge.get("label") or "").strip()})
            seen.add((src, dst))
    if subtype in {"process_flow", "business_workflow", "timeline", "timeline_roadmap", "roadmap"}:
        ordered = sorted(nodes, key=lambda n: (int(n.get("level") or 0), int(n.get("column") or 0), str(n.get("id") or "")))
        for left, right in zip(ordered, ordered[1:]):
            key = (str(left["id"]), str(right["id"]))
            if key not in seen:
                edges.append({"from": key[0], "to": key[1], "label": ""})
                seen.add(key)
    elif subtype in {"taxonomy_map", "mindmap", "org_chart", "hierarchy_chart"}:
        for node in nodes:
            parent = str(node.get("parent") or "").strip()
            key = (parent, str(node["id"]))
            if parent in ids and key not in seen:
                edges.append({"from": key[0], "to": key[1], "label": ""})
                seen.add(key)
    elif subtype in {"knowledge_graph"}:
        for node in nodes:
            if node["id"] == "center":
                continue
            key = ("center", str(node["id"]))
            if "center" in ids and key not in seen:
                edges.append({"from": key[0], "to": key[1], "label": ""})
                seen.add(key)
    spec["edges"] = edges


def _is_usable(spec: dict[str, Any], subtype: str) -> bool:
    subtype = canonical_subtype(subtype)
    if subtype in {"comparison_matrix"}:
        return bool(spec.get("columns") and spec.get("dimensions"))
    if subtype in {"infographic", "chapter_summary"}:
        return bool(spec.get("blocks"))
    if subtype in {"system_architecture", "microservice_architecture", "rag", "agent"}:
        return bool(spec.get("layers") or spec.get("nodes"))
    if subtype in {"taxonomy_map", "mindmap", "org_chart", "hierarchy_chart"}:
        return bool(spec.get("children") or spec.get("nodes"))
    if subtype in {"timeline", "timeline_roadmap", "roadmap"}:
        return bool(spec.get("events") or spec.get("nodes"))
    if subtype in {"knowledge_graph"}:
        return bool(spec.get("concepts") or spec.get("nodes"))
    if subtype in {"process_flow", "business_workflow"}:
        return bool(spec.get("stages") or spec.get("nodes"))
    return bool(spec.get("nodes") or spec.get("steps"))
