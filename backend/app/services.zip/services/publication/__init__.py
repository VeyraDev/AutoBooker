"""Publication export pipeline."""
