"""Semantic IR 结构级校验。"""

from __future__ import annotations

from typing import Any

_OBJECT_RANGES: dict[str, tuple[int, int]] = {
    "flowchart": (2, 12),
    "architecture": (2, 16),
    "comparison": (2, 12),
    "timeline": (2, 14),
    "taxonomy": (2, 20),
    "dataflow": (2, 14),
}

_DEFAULT_RANGE = (2, 16)


def validate_semantic_structure(semantic_ir: dict[str, Any] | None, *, diagram_type: str = "flowchart") -> dict[str, Any]:
    issues: list[str] = []
    if not isinstance(semantic_ir, dict):
        return {"score": 0.0, "issues": ["missing_semantic_ir"], "valid": False}

    objects = [o for o in (semantic_ir.get("objects") or []) if isinstance(o, dict)]
    relations = [r for r in (semantic_ir.get("relations") or []) if isinstance(r, dict)]
    events = [e for e in (semantic_ir.get("events") or []) if isinstance(e, dict)]
    refs = semantic_ir.get("references") or []
    obj_ids = {str(o.get("id") or "") for o in objects if o.get("id")}

    lo, hi = _OBJECT_RANGES.get((diagram_type or "flowchart").lower(), _DEFAULT_RANGE)
    count = len(objects)
    if count < lo:
        issues.append("too_few_objects")
    elif count > hi:
        issues.append("too_many_objects")

    if count >= 2 and not relations and not events:
        issues.append("no_relations_or_events")

    broken = 0
    for rel in relations:
        if str(rel.get("from") or "") not in obj_ids or str(rel.get("to") or "") not in obj_ids:
            broken += 1
    if broken:
        issues.append("broken_relations")

    if refs and not relations and not events:
        issues.append("unexpanded_references")

    penalty = min(1.0, len(issues) * 0.25)
    score = max(0.0, 1.0 - penalty)
    return {
        "score": round(score, 3),
        "issues": issues,
        "valid": score >= 0.5 and "too_few_objects" not in issues and "no_relations_or_events" not in issues,
        "object_count": count,
        "relation_count": len(relations),
        "event_count": len(events),
    }


def combined_semantic_quality(
    text: str,
    semantic_ir: dict[str, Any] | None,
    *,
    diagram_type: str = "flowchart",
    token_coverage_fn,
) -> dict[str, Any]:
    """结构 60% + token 40% 综合语义质量。"""
    from app.services.figures.quality import semantic_coverage_report

    structure = validate_semantic_structure(semantic_ir, diagram_type=diagram_type)
    token = token_coverage_fn(text, semantic_ir)
    combined = round(structure["score"] * 0.6 + float(token.get("score", 0)) * 0.4, 3)
    return {
        "score": combined,
        "structure": structure,
        "token_coverage": token,
        "valid": structure.get("valid", False) and combined >= 0.35,
    }
