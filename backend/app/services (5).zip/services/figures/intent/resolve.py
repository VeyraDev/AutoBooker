"""从 Intent Understanding 结果解析 DiagramIntent 与阻断条件。"""

from __future__ import annotations

from typing import Any

from app.services.figures.intent.evidence_rules import score_candidate_diagrams
from app.services.figures.intent.reconcile import reconcile_intent_with_text
from app.services.figures.intent.rules import default_intent_for_hint, match_diagram_intent
from app.services.figures.intent.taxonomy import (
    FAMILY_DEFAULT_SUBTYPE,
    canonical_subtype,
    subtype_to_diagram_type,
)
from app.services.figures.schemas.diagram import DiagramIntent, PipelineContext

_CANDIDATE_TYPE_MAP: dict[str, tuple[str, str]] = {
    "architecture": ("architecture", "system_architecture"),
    "flowchart": ("workflow", "process_flow"),
    "comparison": ("matrix", "comparison_matrix"),
    "timeline": ("timeline", "timeline_roadmap"),
    "taxonomy": ("knowledge", "taxonomy_map"),
    "transformer": ("architecture", "transformer"),
    "rag": ("architecture", "rag"),
    "agent": ("architecture", "agent"),
}

_GOAL_MAP: dict[str, tuple[str, str]] = {
    "show_system_architecture": ("architecture", "system_architecture"),
    "show_workflow": ("workflow", "process_flow"),
    "show_comparison": ("matrix", "comparison_matrix"),
    "show_timeline": ("timeline", "timeline_roadmap"),
    "show_taxonomy": ("knowledge", "taxonomy_map"),
    "illustrate_concept": ("illustration", "scene_illustration"),
}

_CONFIDENCE_FALLBACK_THRESHOLD = 0.55


def intent_from_legacy_tag(legacy_tag: str | None, ctx: PipelineContext) -> DiagramIntent | None:
    """正文标注类型（FLOWCHART/CHART）直接锚定意图，避免误阻断。"""
    tag = (legacy_tag or "").upper()
    title = (ctx.normalized_input or ctx.description or "")[:80]
    if tag == "FLOWCHART":
        return DiagramIntent(
            "workflow",
            "process_flow",
            0.93,
            "legacy_tag",
            title,
            diagram_type="flowchart",
            reason="FLOWCHART 标注",
            fallback_allowed=True,
        )
    if tag == "CHART":
        return DiagramIntent(
            "data",
            "chart",
            0.93,
            "legacy_tag",
            title,
            diagram_type="chart",
            reason="CHART 标注",
            fallback_allowed=True,
        )
    return None


def intent_from_understanding(
    understanding: dict[str, Any],
    ctx: PipelineContext,
    *,
    ruled: DiagramIntent | None = None,
) -> DiagramIntent | None:
    """将 understand 输出映射为 DiagramIntent；置信不足时返回 None 以触发 rules fallback。"""
    if not understanding:
        return None

    confidence = float(understanding.get("confidence") or 0.5)
    title = str(understanding.get("title") or ctx.normalized_input[:80]).strip()
    candidates = understanding.get("candidate_diagrams") or []
    family, subtype = "", ""

    if candidates and isinstance(candidates[0], dict):
        top_type = str(candidates[0].get("type") or "").lower()
        family, subtype = _CANDIDATE_TYPE_MAP.get(top_type, ("", ""))
        if top_type in {"rag", "agent", "transformer"}:
            subtype = top_type

    if not family:
        goal = str(understanding.get("goal") or "")
        family, subtype = _GOAL_MAP.get(goal, ("", ""))

    if not family:
        domain = str(understanding.get("domain") or "").lower()
        if domain == "rag":
            family, subtype = "architecture", "rag"
        elif domain in {"microservice", "etl"}:
            family, subtype = "architecture", "system_architecture"
        elif domain == "transformer":
            family, subtype = "architecture", "transformer"
        elif domain == "agent":
            family, subtype = "architecture", "agent"

    if not family:
        return None

    subtype = canonical_subtype(subtype or FAMILY_DEFAULT_SUBTYPE.get(family, "concept_diagram"))
    if confidence < _CONFIDENCE_FALLBACK_THRESHOLD and ruled and ruled.confidence >= 0.88:
        return ruled

    if confidence < _CONFIDENCE_FALLBACK_THRESHOLD:
        return None

    intent = DiagramIntent(
        family,
        subtype,
        confidence,
        "intent_understanding",
        title,
        diagram_type=subtype_to_diagram_type(subtype),
        reason=str((candidates[0] if candidates else {}).get("reason") or "intent_understanding"),
        fallback_allowed=True,
    )
    return reconcile_intent_with_text(intent, ctx.normalized_input)


def resolve_intent_unified(ctx: PipelineContext, understanding: dict[str, Any]) -> DiagramIntent:
    """统一意图入口：understanding → rules/hint fallback。"""
    legacy = intent_from_legacy_tag(ctx.legacy_tag, ctx)
    if legacy:
        return reconcile_intent_with_text(legacy, ctx.normalized_input)

    hint_intent = default_intent_for_hint(ctx.subtype_hint)
    ruled = match_diagram_intent(ctx.normalized_input)

    from_understanding = intent_from_understanding(understanding, ctx, ruled=ruled)
    if from_understanding:
        if ruled and ruled.confidence >= 0.95 and from_understanding.confidence < 0.55:
            return reconcile_intent_with_text(ruled, ctx.normalized_input)
        if not from_understanding.diagram_type:
            from_understanding.diagram_type = subtype_to_diagram_type(from_understanding.diagram_subtype)
        return from_understanding

    if hint_intent:
        stale = {"concept_diagram", "taxonomy_map", "knowledge_graph", "mechanism_diagram"}
        if not (
            ruled
            and hint_intent.diagram_subtype in stale
            and ruled.confidence >= 0.88
            and ruled.diagram_subtype != hint_intent.diagram_subtype
        ):
            intent = hint_intent
            if not intent.diagram_type:
                intent.diagram_type = subtype_to_diagram_type(intent.diagram_subtype)
            return intent

    if ruled:
        intent = reconcile_intent_with_text(ruled, ctx.normalized_input)
        if not intent.diagram_type:
            intent.diagram_type = subtype_to_diagram_type(intent.diagram_subtype)
        return intent

    # domain from understanding as last resort before default
    domain = str(understanding.get("domain") or "").lower()
    if domain == "rag":
        subtype = "rag"
        family = "architecture"
    elif domain in {"microservice", "etl"}:
        subtype, family = "system_architecture", "architecture"
    else:
        family = "illustration"
        subtype = FAMILY_DEFAULT_SUBTYPE.get("illustration", "concept_illustration")

    return DiagramIntent(
        family,
        canonical_subtype(subtype),
        0.5,
        "default",
        ctx.normalized_input[:80],
        diagram_type=subtype_to_diagram_type(subtype),
        reason="无明确匹配，默认",
        fallback_allowed=True,
    )
