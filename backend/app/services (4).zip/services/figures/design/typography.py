"""文字测量（简化版）。"""

from __future__ import annotations


def estimate_text_width(text: str, *, font_size: int = 13) -> float:
    w = 0.0
    for ch in str(text or ""):
        if "\u4e00" <= ch <= "\u9fff":
            w += font_size
        else:
            w += font_size * 0.55
    return w + 16


def wrap_label(text: str, max_width: float, *, font_size: int = 13) -> list[str]:
    if estimate_text_width(text, font_size=font_size) <= max_width:
        return [text]
    lines: list[str] = []
    buf = ""
    for ch in text:
        trial = buf + ch
        if estimate_text_width(trial, font_size=font_size) > max_width and buf:
            lines.append(buf)
            buf = ch
        else:
            buf = trial
    if buf:
        lines.append(buf)
    return lines[:2]
