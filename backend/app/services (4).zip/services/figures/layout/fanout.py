"""Hub 扇出布局。"""

from __future__ import annotations

from collections import defaultdict

from app.services.figures.graph.schema import GraphIR
from app.services.figures.layout.schema import LayoutResult, NodePosition

_NODE_W = 116.0
_NODE_H = 46.0


def layout_fanout(graph: GraphIR, hub_id: str) -> LayoutResult:
    out_map: dict[str, list[str]] = defaultdict(list)
    for e in graph.edges:
        out_map[e.source].append(e.target)
    children = out_map.get(hub_id, [])
    positions: dict[str, NodePosition] = {}
    positions[hub_id] = NodePosition(id=hub_id, x=360, y=40, width=_NODE_W + 20, height=_NODE_H)
    span = len(children) * (_NODE_W + 40)
    x = max(40, (800 - span) / 2)
    for cid in children:
        positions[cid] = NodePosition(id=cid, x=x, y=160, width=_NODE_W, height=_NODE_H)
        x += _NODE_W + 40
    for n in graph.nodes:
        if n.id not in positions:
            positions[n.id] = NodePosition(id=n.id, x=40, y=280, width=_NODE_W, height=_NODE_H)
    return LayoutResult(strategy="fanout", direction="TB", node_positions=positions)
