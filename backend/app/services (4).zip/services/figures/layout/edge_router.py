"""边正交路由。"""

from __future__ import annotations

from app.services.figures.layout.schema import EdgeRoute, LayoutResult, NodePosition
from app.services.figures.render.edge_router import orthogonal_route, route_with_side_return


def route_edges(layout: LayoutResult, graph_edges, *, direction: str = "TB") -> None:
    routes: list[EdgeRoute] = []
    for e in graph_edges:
        sp = layout.node_positions.get(e.source)
        tp = layout.node_positions.get(e.target)
        if not sp or not tp:
            continue
        x1, y1 = sp.x + sp.width / 2, sp.y + sp.height
        x2, y2 = tp.x + tp.width / 2, tp.y
        if direction.upper() == "LR":
            x1, y1 = sp.x + sp.width, sp.y + sp.height / 2
            x2, y2 = tp.x, tp.y + tp.height / 2
        label = str(getattr(e, "label", "") or "")
        style = str(getattr(e, "style", "") or "solid")
        if label in {"不达标", "返回", "retry"} or getattr(e, "edge_type", "") == "return":
            pts = list(route_with_side_return(x1, y1, x2, y2, side="right"))
        else:
            pts = list(orthogonal_route(x1, y1, x2, y2, direction=direction))
        routes.append(EdgeRoute(source=e.source, target=e.target, points=pts, label=label, style=style))
    layout.edge_routes = routes


def center_of(pos: NodePosition) -> tuple[float, float]:
    return pos.x + pos.width / 2, pos.y + pos.height / 2
