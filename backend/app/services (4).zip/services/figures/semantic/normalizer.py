"""Semantic IR 规范化。"""

from __future__ import annotations

import re

from app.services.figures.semantic.schema import SemanticIR, SemanticObject

_VERB_IN_NAME = re.compile(r"连接|通知|调用|依赖|写入|读取|通过|包含|触发|异步|同步")
_DECISION_OUTCOME = re.compile(r"^(不达标|未达标|达标|通过|失败)$")


def normalize_semantic_ir(ir: SemanticIR) -> tuple[SemanticIR, list[str]]:
    warnings: list[str] = []
    clean_objects: list[SemanticObject] = []
    for obj in ir.objects:
        name = obj.name.strip()
        if not name:
            warnings.append("empty_object_name")
            continue
        if _VERB_IN_NAME.search(name):
            warnings.append(f"verb_in_object_name:{name}")
            ir.unknowns.append(name)
            continue
        kind = obj.kind
        if _DECISION_OUTCOME.match(name):
            name = "是否达标"
            kind = "decision"
        elif name.startswith("是否") or re.search(r"判断", name):
            kind = "decision"
        clean_objects.append(
            SemanticObject(id=obj.id, name=name[:16], kind=kind, importance=obj.importance, tags=obj.tags)
        )
    ir.objects = clean_objects
    valid_ids = ir.object_ids()
    ir.relations = [
        r for r in ir.relations
        if str(r.get("from") or "") in valid_ids and str(r.get("to") or "") in valid_ids
    ]
    return ir, warnings


def is_usable_semantic_ir(ir: SemanticIR) -> bool:
    return len(ir.objects) >= 2
