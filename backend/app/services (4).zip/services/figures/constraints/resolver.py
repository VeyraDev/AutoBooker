"""references + constraints → 确定 relations/events。"""

from __future__ import annotations

from app.services.figures.constraints.conflict_detector import detect_conflicts
from app.services.figures.constraints.references import expand_references
from app.services.figures.semantic.schema import SemanticIR


def resolve_constraints(ir: SemanticIR) -> tuple[SemanticIR, list[str]]:
    """展开 references，合并 relations，检测冲突。"""
    expanded = expand_references(ir)
    existing = {(str(r.get("from")), str(r.get("to")), str(r.get("label") or "")) for r in ir.relations}
    for rel in expanded:
        key = (str(rel.get("from")), str(rel.get("to")), str(rel.get("label") or ""))
        if key not in existing:
            ir.relations.append(rel)
            existing.add(key)

    for c in ir.constraints:
        if not isinstance(c, dict):
            continue
        if c.get("type") == "edge_style" and c.get("value") == "dashed":
            for rel in ir.relations:
                if c.get("target") == "async" or rel.get("async"):
                    rel["async"] = True
                    rel["style"] = "dashed"

    issues = detect_conflicts(ir)
    ir.relations = [
        r for r in ir.relations
        if str(r.get("from") or "") in ir.object_ids() and str(r.get("to") or "") in ir.object_ids()
    ]
    return ir, issues
