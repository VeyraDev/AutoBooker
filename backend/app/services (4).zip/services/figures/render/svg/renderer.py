"""LayoutResult + DesignTokens → SVG 主路径。"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from app.services.figures.design.tokens import DesignTokens, tokens_for_theme
from app.services.figures.layout.schema import EdgeRoute, LayoutResult, NodePosition
from app.services.figures.render.svg.export_png import export_png_from_svg
from app.services.figures.render.svg.markers import arrow_marker_def
from app.services.figures.render.svg.primitives import diamond, polyline, rect
from app.services.figures.render.svg.text import multiline_text


def render_svg_diagram(
    spec: dict[str, Any],
    out_path: Path,
    *,
    title: str = "",
    layout_result: LayoutResult | dict | None = None,
    theme: str = "modern_saas",
) -> tuple[str, Path]:
    tokens = tokens_for_theme(theme)
    lr = _coerce_layout(layout_result, spec)
    if lr is None:
        raise ValueError("svg renderer requires layout_result or node positions")

    w = lr.canvas.get("width", 800)
    h = lr.canvas.get("height", 600)
    node_meta = {n.get("id"): n for n in (spec.get("nodes") or []) if isinstance(n, dict)}

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{w:.0f}" height="{h:.0f}" viewBox="0 0 {w:.0f} {h:.0f}">',
        f'<rect width="100%" height="100%" fill="{tokens.background}"/>',
        "<defs>",
        arrow_marker_def("arrow", color=tokens.edge_stroke, size=tokens.arrow_size),
        "</defs>",
    ]
    if title:
        parts.append(multiline_text(w / 2, 22, title, fill=tokens.text, max_width=w - 80, font_size=16))

    for edge in lr.edge_routes:
        dashed = edge.style == "dashed"
        parts.append(polyline(edge.points, stroke=tokens.edge_stroke, width=tokens.edge_width, dashed=dashed, marker_end="arrow"))
        if edge.label and len(edge.points) >= 2:
            mid = edge.points[len(edge.points) // 2]
            parts.append(multiline_text(mid[0], mid[1] - 8, edge.label, fill=tokens.text, max_width=80, font_size=11))

    for nid, pos in lr.node_positions.items():
        meta = node_meta.get(nid, {})
        kind = str(meta.get("type") or "process")
        fill = _fill_for_kind(kind, tokens, meta)
        cx, cy = pos.x + pos.width / 2, pos.y + pos.height / 2
        if kind == "decision" or meta.get("shape") == "diamond":
            parts.append(diamond(cx, cy, pos.width, pos.height, fill=fill, stroke=tokens.border))
        else:
            parts.append(rect(pos.x, pos.y, pos.width, pos.height, fill=fill, stroke=tokens.border, rx=tokens.node_radius))
        parts.append(multiline_text(cx, cy, str(meta.get("label") or nid), fill=tokens.text, max_width=pos.width - 8, font_size=tokens.font_size))

    parts.append("</svg>")
    svg_content = "\n".join(parts)
    svg_path = out_path.with_suffix(".svg")
    png_path = out_path.with_suffix(".png")
    svg_path.parent.mkdir(parents=True, exist_ok=True)
    svg_path.write_text(svg_content, encoding="utf-8")
    export_png_from_svg(svg_path, png_path)
    return "image/svg+xml", svg_path if svg_path.is_file() else png_path


def _fill_for_kind(kind: str, tokens: DesignTokens, meta: dict) -> str:
    if meta.get("color"):
        return str(meta["color"])
    if kind == "decision":
        return tokens.decision_fill
    if kind == "gateway":
        return tokens.gateway_fill
    if kind in {"database", "queue"}:
        return tokens.card
    return tokens.node_fill


def _coerce_layout(layout_result: LayoutResult | dict | None, spec: dict) -> LayoutResult | None:
    if isinstance(layout_result, LayoutResult):
        return layout_result
    if isinstance(layout_result, dict) and layout_result.get("node_positions"):
        npos = {}
        for nid, p in layout_result.get("node_positions", {}).items():
            if isinstance(p, dict):
                npos[nid] = NodePosition(id=nid, x=float(p["x"]), y=float(p["y"]), width=float(p.get("width", 120)), height=float(p.get("height", 48)))
        edges = []
        for e in layout_result.get("edge_routes") or []:
            if isinstance(e, dict):
                pts = [(float(x), float(y)) for x, y in e.get("points", [])]
                edges.append(EdgeRoute(source=e.get("source", ""), target=e.get("target", ""), points=pts, label=e.get("label", ""), style=e.get("style", "solid")))
        return LayoutResult(
            strategy=str(layout_result.get("strategy") or "layered"),
            direction=str(layout_result.get("direction") or "TB"),
            node_positions=npos,
            edge_routes=edges,
            canvas=dict(layout_result.get("canvas") or {"width": 800, "height": 600}),
        )
    clf_layout = spec.get("layout_result")
    if isinstance(clf_layout, dict):
        return _coerce_layout(clf_layout, spec)
    return None
