"""SVG 基础图元。"""

from __future__ import annotations

import html


def rect(x: float, y: float, w: float, h: float, *, fill: str, stroke: str, rx: int = 8) -> str:
    return f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="1.5"/>'


def diamond(cx: float, cy: float, w: float, h: float, *, fill: str, stroke: str) -> str:
    x, y = cx - w / 2, cy - h / 2
    pts = f"{cx:.1f},{y:.1f} {x+w:.1f},{cy:.1f} {cx:.1f},{y+h:.1f} {x:.1f},{cy:.1f}"
    return f'<polygon points="{pts}" fill="{fill}" stroke="{stroke}" stroke-width="1.5"/>'


def text_el(x: float, y: float, content: str, *, fill: str, size: int = 13, anchor: str = "middle") -> str:
    safe = html.escape(content)
    return f'<text x="{x:.1f}" y="{y:.1f}" fill="{fill}" font-size="{size}" text-anchor="{anchor}" dominant-baseline="middle">{safe}</text>'


def polyline(points: list[tuple[float, float]], *, stroke: str, width: float = 1.5, dashed: bool = False, marker_end: str = "") -> str:
    pts = " ".join(f"{x:.1f},{y:.1f}" for x, y in points)
    dash = ' stroke-dasharray="6 4"' if dashed else ""
    marker = f' marker-end="url(#{marker_end})"' if marker_end else ""
    return f'<polyline points="{pts}" fill="none" stroke="{stroke}" stroke-width="{width}"{dash}{marker}/>'
